package com.rbs.ignite.business.itus.transformer.dave;

import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.dave.Identifier;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.eq;

@RunWith(SpringJUnit4ClassRunner.class)
public class TotvTradeToDaveReqTransformerTest {

  @InjectMocks
  private TotvTradeToDaveReqTransformer daveTradeTransformerObj;
  @Mock
  ConversionService conversionService;
  @Mock
  private TotvTrade totvTrade;
  private TotvDaveRequest totvDaveRequest;
  private TypeDescriptor sourceType;
  private TypeDescriptor targetType;


  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    totvDaveRequest = new TotvDaveRequest();
    Identifier identifier = new Identifier();
    identifier.setSiteId("GDS GBLO");
    identifier.setContractId(113092118);
    totvDaveRequest.setTarget(identifier);
    totvDaveRequest.setIsin("US75405RAA14");
    sourceType = TypeDescriptor.valueOf(TotvTrade.class);
    targetType = TypeDescriptor.valueOf(TotvDaveRequest.class);
  }

  @After
  public void tearDown() {
    daveTradeTransformerObj = null;
  }

  @Test
  public void testTransform() throws ItusTransformException {

    Mockito.when(conversionService.convert(Mockito.anyObject(), eq(sourceType), eq(targetType))).thenReturn(totvDaveRequest);
    TotvDaveRequest daveRequest = daveTradeTransformerObj.transform(totvTrade);
    assertEquals("US75405RAA14", daveRequest.getIsin());
  }

}
