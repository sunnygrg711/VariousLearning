package org.sk.tutorial.jfamily.concurrency.examples.session1_3;

public interface IData{
    void doAction(Object data);
}