#!/bin/sh

function usage {
    echo "Usage: $0 -a <ACTION> [-f] [-h]"
    echo " "
	echo "        -a : ACTION, where ACTION is one of:"
	echo "             start:  	Start the service in the background"
	echo "             stop:  	Stop the service, using the .pid file created in the current directory by the 'start' command"
	echo "             console: Start the service in the foreground, killing the shell will therefore stop the service"
	echo "             restart:	<stop> followed by <start>"
	echo "             status: 	Return the service's status in terms of running / not running"
	echo " "
	echo "        -f : FORCE START: By default application is started on host mentioned in reportable-manager.<env>.cfg file only."
    echo "             But on passing -f, will start the application on the current host from which script is called."
	echo " "
	echo "        -h : HELP, show usage"
	echo " "
	echo "        -d : DEBUG PORT NUMBER, Enable Remote DEBUG "
	echo "             Using -d will automatically enable remote debug on port number specified as argument value "

	echo "Examples:"
    echo "        $0 -a start"
    echo "        $0 -a stop"
    echo "        $0 -a restart"
    echo "        $0 -a status"
    echo "        $0 -a status -d 8070"
	exit -1
}

arguments_passed=$@
ENV_NAME=%%ENV_VALUE%%
run_on_current_host=false

while getopts a:d:fh opt; do
  case ${opt} in
    a) action=$OPTARG
       ;;
    h) usage
       ;;
    d) debug_port=$OPTARG
       ;;
    f) run_on_current_host=true
       ;;
    ?) echo "ERROR: Unknown options -$OPTARG"
       usage
       ;;
  esac
done

if [[ $action == "" ]]; then
  echo "ERROR: Kindly provide action"
  usage
fi

function deriveAppHome {
	APP_HOME=""
	thisScript=$0
	[[ -h ${thisScript} ]] && thisScript=$(dirname $0)/$(readlink $0)
	cd $(dirname ${thisScript})/..
	APP_HOME=$(pwd)
	cd - > /dev/null
	if [[ $(basename ${APP_HOME}) != "${project.parent.artifactId}" ]]; then
		echo "ERROR : Invalid Application Root! please start/stop from the activated application root"
		exit 1
    fi
}

function setEnv {
	deriveAppHome

	if [[ -f ${APP_HOME}/etc/config/${project.parent.artifactId}.default.cfg ]]; then
			source $APP_HOME/etc/config/${project.parent.artifactId}.default.cfg
	else
		echo "WARN: $APP_HOME/etc/config/${project.parent.artifactId}.default.cfg not found."
	fi

	if [[ -f ${APP_HOME}/etc/config/${project.parent.artifactId}.${ENV_NAME}.cfg ]]; then
		source $APP_HOME/etc/config/${project.parent.artifactId}.${ENV_NAME}.cfg
	else
		echo "ERROR: $APP_HOME/etc/config/${project.parent.artifactId}.${ENV_NAME}.cfg not found."
		exit 1
	fi

	if [[ -f ${APP_HOME}/overrides/config/${project.parent.artifactId}.overrides.cfg ]]; then
			source $APP_HOME/overrides/config/${project.parent.artifactId}.overrides.cfg
	fi

	LOGS_DIR="${APP_HOME}/logs/$(hostname)"
	mkdir -p ${LOGS_DIR}
	# our services, by default, create a pid file, we'll use that to control start/stop
	PID_FILE="${LOGS_DIR}/${project.parent.artifactId}.pid"
	PORT_FILE="${LOGS_DIR}/${project.parent.artifactId}.port"
}

function processIsRunning {
	if [[ ! -z "$(showPid)" ]]
	then
		return 0
	else
		return 1
	fi
}

function showPid {
  pgrep -f "$JAVA_CMD .* $APP_HOME"
}

function showPort {
	echo $(<"$PORT_FILE")
}

function determineHealth {
  if [ ! -f $PORT_FILE ] ; then
    echo 0
  else
	  curl -s --max-time 30 -o /dev/null -w "%{http_code}" "http://localhost:$(showPort)/health"
	fi
}

log_prefix="~>"

function log {
  echo "$(date +"%T") $log_prefix $1"
}

function executeActionOnRemoteHost {
  pids=""
	for remoteHost in $(echo $HOSTS | sed -e 's/ /|/g' -e 's/,/|/g' -e 's/;/|/g' | sed 's/|/\n/g' | awk '{print $1}' | sort -u); do
		ssh -o StrictHostKeyChecking=no ${remoteHost} ${APP_HOME}/bin/control.sh -f ${arguments_passed} 2> /dev/null &
		pids+=" $!"
  done
  returnStatus=0
  for p in $pids; do
    if ! wait $p ; then
      returnStatus=1
    fi
  done

  wait

  exit $returnStatus
}

function stopApplication {
	if (${run_on_current_host}); then
		if ! processIsRunning
		then
			log "Process $(showPid) already stopped"
			exit 0
		fi
		kill -TERM $(showPid)
		NOT_KILLED=1
		for i in {1..20}; do
			if processIsRunning
			then
				log "Waiting for process $(showPid) to stop on $(hostname)"
				sleep 7
			else
				NOT_KILLED=0
			fi
		done
		echo
		if [ $NOT_KILLED = 1 ]
		then
			log "Cannot kill process $(showPid) on $(hostname)"
			exit 1
		fi
		log "Process stopped on Host: $(hostname) for Env: ${ENV_NAME} "
	else
		executeActionOnRemoteHost
	fi
}

function startApplication {
	if (${run_on_current_host}); then
		if [ -f $PID_FILE ] && processIsRunning
		then
		  if [ "$(determineHealth)" -eq 200 ]  ; then
		    log "Process $(showPid) on $(hostname) already running and is healthy"
		  else
		    log "Process $(showPid) on $(hostname) already running and is not healthy. See logs for more info"
		  fi
			exit 1
		fi

		JAVA_OPTS="-server ${HEAP_SIZE_CONFIG} -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=${LOGS_DIR}/"
		JAVA_OPTS="$JAVA_OPTS -Xloggc:${LOGS_DIR}/${project.parent.artifactId}-gc.log"
		JAVA_OPTS="$JAVA_OPTS -Dlogs.dir=${LOGS_DIR}"
		JAVA_OPTS="$JAVA_OPTS -Denv=$ENV_NAME"

		CLASS_PATH="-cp "${APP_HOME}/overrides/:${APP_HOME}/etc:${APP_HOME}/etc/config:${APP_HOME}/opt/lib/*""

		if [[ $debug_port != "" ]]; then
			JAVA_OPTS="$JAVA_OPTS -Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=${debug_port}"
		fi

		# set up a classpath and command line args for the java process
		START_ARGS="$JAVA_OPTS -DserviceName=${project.parent.artifactId}"

		(nohup $JAVA_CMD $START_ARGS $CLASS_PATH ${application.starter.class} > $LOGS_DIR/nohup.log 2>&1) &
		log "Process starting on Host: $(hostname) for Env: ${ENV_NAME}"

		for i in {1..20}; do
    	if [ "$(determineHealth)" -eq 000 ] ; then
    	  if processIsRunning ; then
    		  log "Process is still starting on Host: $(hostname)"
    		  sleep 5
    		else
		      log "Process has failed on host: $(hostname)"
          exit 1
    		fi
      elif [ "$(determineHealth)" -eq 200 ] ; then
        log "Process is up and healthy on host: $(hostname)"
        exit 0
      else
    	log "Process is up but not healthy host: $(hostname)"
        exit 1
    	fi
    done
    log "Unable to determine health of the process on host $(hostname)"
    exit 1
	else
		executeActionOnRemoteHost
	fi
}

setEnv

case "$action" in
	status)
		if (${run_on_current_host}); then
		  log "Getting ${project.parent.artifactId} status on $(hostname)"
		  EXIT_STATUS=0
		  if [ "$(determineHealth)" -eq 200 ]  ; then
		    log "${project.parent.artifactId} process on $(hostname) is running and healthy"
			elif processIsRunning ; then
				log "${project.parent.artifactId} process on $(hostname) is running but not healthy. PID: $(showPid)"
				EXIT_STATUS=1
			else
				log "${project.parent.artifactId} process is not running on $(hostname)"
				EXIT_STATUS=1
			fi
			exit $EXIT_STATUS
		else
			executeActionOnRemoteHost
		fi
		;;
	stop)
		stopApplication
		;;
	start)
		startApplication
		;;
	restart)
		if (${run_on_current_host}); then
			stopApplication
			if [ $? = 1 ]
			then
				exit 1
			fi
			startApplication
		else
			executeActionOnRemoteHost
		fi
		;;
	*)
		usage
	exit 1
esac
exit 0
