package org.sk.tutorial.jfamily.concurrency.examples.session1_2;


import org.sk.tutorial.jfamily.concurrency.annotation.GuardedBy;
import org.sk.tutorial.jfamily.concurrency.annotation.ThreadSafe;

import java.math.BigInteger;
import java.util.concurrent.atomic.AtomicReference;

@ThreadSafe
public class CachingFactorizerByIntrinsicLock {
    @GuardedBy(name = "this")
    private final AtomicReference<BigInteger> lastNumber = new AtomicReference<>();
    @GuardedBy(name = "this")
    private final AtomicReference<BigInteger[]> lastFactors = new AtomicReference<>();

    public synchronized void service(int data, Object object) {
        BigInteger i = extractFromInput(object);
        if (i.equals(lastNumber.get())) {
            process(data);
        } else {
            BigInteger[] factors = factor(i);
            lastNumber.set(i);
            lastFactors.set(factors);
            process(data);
        }

    }

    private BigInteger[] factor(BigInteger i) {
        return new BigInteger[i.intValue()];
    }

    private BigInteger extractFromInput(Object object) {
        return new BigInteger(object.toString());
    }

    public BigInteger getLastNumber() {
        return lastNumber.get();
    }

    public BigInteger[] getLastFactors() {
        return lastFactors.get();
    }

    private void process(Object object) {
    }

}
