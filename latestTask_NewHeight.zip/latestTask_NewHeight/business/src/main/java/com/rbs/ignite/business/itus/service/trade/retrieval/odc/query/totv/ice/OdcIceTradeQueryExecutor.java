package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.ice;

import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.AbstractOdcTradeQueryExecutor;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.domain.RegimeImpactType;
import com.rbs.odc.access.domain.SecurityInstrumentIdentifierClassificationScheme;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionState;
import com.rbs.odc.access.domain.TransactionStateScheme;
import com.rbs.odc.dynamicquery.lang.FilterLanguage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDate;
import java.util.Set;

import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.business;
import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.collection;
import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.transaction;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.and;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.valueOf;

/**
 * Created by upadkti on 08/12/2017.
 */
public class OdcIceTradeQueryExecutor extends AbstractOdcTradeQueryExecutor {
  private static final Logger logger = LoggerFactory.getLogger(OdcIceTradeQueryExecutor.class);
  private static final ItusTradeSourceSystem SOURCE_SYSTEM = ItusTradeSourceSystem.ICE;
  private @Value("${totv.odc.ice.system.instance.ids}") String systemInstanceIds;
  private @Value("${totv.odc.ice.include.trade.status}") String tradeStatusStr;

  @Override
  public Set<Transaction> executeQuery(Set<String> isinSet, LocalDate businessDate, String requestId) {
    Set<SystemInstanceId> systemInstanceIdSet = getSystemInstanceIdsFromString(systemInstanceIds, SOURCE_SYSTEM,requestId);
    Set<TransactionState> tradeStatuses = getTransactionStatesFromString(tradeStatusStr, SOURCE_SYSTEM, requestId);

    FilterLanguage whereClause = and
      (
        valueOf(transaction().getId().getSourceSystemId()).in(systemInstanceIdSet),
        valueOf(collection(transaction().getTransactionStatus()).getTransactionStateScheme()).equalTo(TransactionStateScheme.Workflow_State),
        valueOf(collection(transaction().getTransactionStatus()).getTransactionState()).in(tradeStatuses),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Post_Trade_Transparency),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Transaction_Reporting),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Transaction Reporting"),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Post Trade Transparency"),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getReportableInstruments()).getInstrumentScheme()).equalTo
          (SecurityInstrumentIdentifierClassificationScheme.ISIN),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getReportableInstruments()).getInstrumentId()).in(isinSet));
    if(logger.isDebugEnabled())logger.debug(requestId+":"+" ODC Query Criteria for ICE: " + whereClause.toString() );
    return executeQuery(whereClause,businessDate,requestId);
  }
}
