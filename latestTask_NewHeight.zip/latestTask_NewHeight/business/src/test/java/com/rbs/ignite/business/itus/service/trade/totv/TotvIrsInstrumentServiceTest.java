package com.rbs.ignite.business.itus.service.trade.totv;

import com.rbs.gbm.rates.core.auth.security.SsoTokenProviderService;
import com.rbs.ignite.business.itus.service.instrument.totv.irs.TotvIrsInstrumentService;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentDateInput;
import com.rbs.ignite.domain.itus.irs.TotvIrsInstrumentIdentifier;
import com.rbs.ignite.domain.itus.irs.TotvIrsResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;


/**
 * Created by kumaunn on 01/04/2018.
 */

@RunWith(SpringJUnit4ClassRunner.class)

public class TotvIrsInstrumentServiceTest {

  @Mock
  private SsoTokenProviderService ssoTokenProviderService;

  @InjectMocks
  private TotvIrsInstrumentService irsInstrumentService = new TotvIrsInstrumentService("totv", TotvIrsResponse.class, ssoTokenProviderService) ;


  @Mock RestTemplate restTemplate;

  @Mock ResponseEntity responseEntity;

  @Mock Logger logger;

  @Test(expected = ItusException.class)
  public void testGetInstrumentDataExceptionWhenErrorEmpty() throws ItusException{
    TotvIrsResponse response = new TotvIrsResponse(new HashSet<TotvIrsInstrumentIdentifier>(), Arrays.asList("Illegal Identifier"));
    Mockito.when(responseEntity.getBody()).thenReturn(response);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),Mockito.any(),Mockito.any(Class.class), Mockito.anyMap())).thenReturn(responseEntity);
    TotvInstrumentDateInput data = new TotvInstrumentDateInput(LocalDate.now());
    irsInstrumentService.getInstrumentData(data, "12344",true);
  }

  @Test(expected = ItusException.class)
  public void testGetInstrumentDataExceptionWhenIsinEmplty() throws ItusException{
    TotvIrsResponse response = new TotvIrsResponse(new HashSet<TotvIrsInstrumentIdentifier>(), Arrays.asList());
    Mockito.when(responseEntity.getBody()).thenReturn(response);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),Mockito.any(),Mockito.any(Class.class), Mockito.anyMap())).thenReturn(responseEntity);
    TotvInstrumentDateInput data = new TotvInstrumentDateInput(LocalDate.now());
    irsInstrumentService.getInstrumentData(data, "12344",false);
  }

  @Test(expected = ItusException.class)
  public void testGetInstrumentDataWhenDebuggerEnabled() throws ItusException, NoSuchFieldException, IllegalAccessException{
    ReflectionUtil.setPrivateField(TotvIrsInstrumentService.class,"logger",logger);
    Mockito.when(logger.isDebugEnabled()).thenReturn(true);
    TotvIrsResponse response = new TotvIrsResponse(new HashSet<TotvIrsInstrumentIdentifier>(), Arrays.asList());
    Mockito.when(responseEntity.getBody()).thenReturn(response);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(),Mockito.any(),Mockito.any(Class.class), Mockito.anyMap())).thenReturn(responseEntity);
    TotvInstrumentDateInput data = new TotvInstrumentDateInput(LocalDate.now());
    irsInstrumentService.getInstrumentData(data, "12344",false);
  }
}
