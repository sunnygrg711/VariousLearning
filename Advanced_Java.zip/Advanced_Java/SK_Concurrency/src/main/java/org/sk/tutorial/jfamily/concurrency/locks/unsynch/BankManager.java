package org.sk.tutorial.jfamily.concurrency.locks.unsynch;

import org.sk.tutorial.jfamily.concurrency.locks.BalanceViewable;
import org.sk.tutorial.jfamily.concurrency.locks.Bank;
import org.sk.tutorial.jfamily.concurrency.locks.IBankManager;
import org.sk.tutorial.jfamily.concurrency.locks.Transferable;


/**
 * Created by kshekar on 22/03/2018.
 */
public class BankManager  implements IBankManager{
    private Bank bank;
    private BalanceViewable balanceViewable;
    private Transferable transferable;
    private BankLockingImpl bankLocking = new BankLockingImpl();
    public BankManager(int n, double initialBalance) {
         bank = new Bank(n, initialBalance);
         transferable=new TransactionHandler(bank,bankLocking);
         balanceViewable=new BankBalanceViewer(bank);
    }

    public Bank getBank() {
        return bank;
    }

    public BalanceViewable getBalanceViewable() {
        return balanceViewable;
    }

    public Transferable getTransferable() {
        return transferable;
    }
}
