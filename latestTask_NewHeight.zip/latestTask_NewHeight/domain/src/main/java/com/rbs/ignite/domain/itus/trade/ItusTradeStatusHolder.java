package com.rbs.ignite.domain.itus.trade;



import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import java.util.Set;

public interface ItusTradeStatusHolder<Status extends ItusTradeStatus> {
    ItusTradeSourceSystem getTradeSourceSystem();
    Set<Status> getTradeStatusSet();
}
