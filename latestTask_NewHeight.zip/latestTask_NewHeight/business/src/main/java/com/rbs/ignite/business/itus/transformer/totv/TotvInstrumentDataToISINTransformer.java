package com.rbs.ignite.business.itus.transformer.totv;


import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;

import java.util.Set;

public class TotvInstrumentDataToISINTransformer implements ItusTransformer<Set<TotvInstrumentData>, Set<String>> {

    @Autowired
    ConversionService conversionService;

    @Override
    public Set<String> transform(Set<TotvInstrumentData> instrumentDataSet) throws ItusTransformException {
        TypeDescriptor sourceType = TypeDescriptor.collection(Set.class, TypeDescriptor.valueOf(TotvInstrumentData.class));
        TypeDescriptor targetType = TypeDescriptor.collection(Set.class, TypeDescriptor.valueOf(String.class));
        Set<String> totvISINSet = (Set<String>) conversionService.convert(instrumentDataSet, sourceType, targetType);
        return totvISINSet;
    }
}
