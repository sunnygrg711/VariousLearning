package com.rbs.ignite.business.itus.mgmt;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.HealthEndpoint;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.rbs.rates.foundation.mgmt.FoundationServiceCreationListener;

/**
 * Hooks into the 'container created' lifecycle event to invoke any service health checks configured for this service. Can be 
 * extended to run whatever else a given service needs 'on startup'.
 */
@Component
public class IgniteTradeUpdateServiceCreationListener extends FoundationServiceCreationListener {

  @Autowired
  public IgniteTradeUpdateServiceCreationListener(HealthEndpoint healthEndpoint) {
    super(healthEndpoint);
  }
}     