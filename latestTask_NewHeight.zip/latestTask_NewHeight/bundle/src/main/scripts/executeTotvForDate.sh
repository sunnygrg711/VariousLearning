#!/bin/bash
function usage {
        echo "Usage: $0 -u <URL> -d <date> "
        echo " "
        echo "        -u : URL"
        echo " "
        echo "        -d : date in dd/mm/yyyy format"
        echo "             where "
        echo "             dd   - day of the month in numeric format "
        echo "             mm   - month of the year in numeric format "
        echo "             yyyy - year in numeric format "
        echo "Examples:"
        echo "        $0 -u 'http://lonrs10851:18551/totv/updateTradesForDate?isDelta=true&byPassThreshold=false' -d '26/03/2018'"
        echo "        $0 -u 'http://lonrs10851:18551/totv/updateTradesForDate?isDelta=false&byPassThreshold=false' -d '26/03/2018'"
        exit -1
}

arguments_passed=$@

while getopts u:d: arg; do
    case ${arg} in
        u) URL=${OPTARG};;
        d) DATE=${OPTARG};;
        ?) echo "ERROR: Unknown options -${OPTARG}"
           usage;;
    esac
done
if [ -z "${URL}" ]; then
    echo "URL not set! Please set the Ignite Trade Update Service URL with the '-u' switch."
    usage
    exit 1
fi

if [ -z "${DATE}" ]; then
    echo "DATE not set! Please set the date with the '-d' switch."
    usage
    exit 1
fi

PASSWORD=`/apps/IRDtools/script/sp_login -S sso -U app-ignite -m P`
echo "Executing Ignite Trade Update Service for Traded On Trading Venues(TOTV) on url '${URL}' for date '${DATE}' ..."

/usr/bin/curl   -u app-ignite\:${PASSWORD} --request POST "${URL}" --data "{\"date\": \"${DATE}\"}" --header "Content-Type: application/json" --header "Accept: application/json"

