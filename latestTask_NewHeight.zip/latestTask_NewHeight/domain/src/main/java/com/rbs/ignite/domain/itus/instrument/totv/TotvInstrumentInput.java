package com.rbs.ignite.domain.itus.instrument.totv;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Set;

public class TotvInstrumentInput {

  @NotNull
  private Set<TotvInstrumentData> isinDataSet;

  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
  private LocalDate date;

  public TotvInstrumentInput(@JsonProperty("isinDataSet") Set<TotvInstrumentData> isinDataSet, @JsonProperty("date")LocalDate date) {
    this.isinDataSet = isinDataSet;
    this.date = date;
  }
  public Set<TotvInstrumentData> getIsinDataSet() {
    return isinDataSet;
  }
  public LocalDate getDate() {
    return date;
  }
  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvInstrumentInput that = (TotvInstrumentInput) o;

    if (!isinDataSet.equals(that.isinDataSet)) return false;
    return date.equals(that.date);
  }
  @Override
  public int hashCode() {
    int result = isinDataSet.hashCode();
    result = 31 * result + date.hashCode();
    return result;
  }
  @Override
  public String toString() {
    return "TotvInstrumentInput{" +
            "isinDataSet=" + isinDataSet +
            ", date=" + date +
            '}';
  }
}
