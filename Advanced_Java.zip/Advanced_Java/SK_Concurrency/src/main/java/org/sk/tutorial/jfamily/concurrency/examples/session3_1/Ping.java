package org.sk.tutorial.jfamily.concurrency.examples.session3_1;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Exchanger;
import java.util.concurrent.TimeUnit;

public class Ping implements Runnable {

    private Exchanger<String> exchanger;

    public Ping(Exchanger<String> exchanger) {
        this.exchanger = exchanger;
    }

    @Override
    public void run() {
        try {
            int counter=5;
            while (--counter>0) {
                System.out.println(Thread.currentThread().getName() + "::"  + exchanger.exchange("Ping-"+counter));
                TimeUnit.MILLISECONDS.sleep(2000);
            }
         } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
