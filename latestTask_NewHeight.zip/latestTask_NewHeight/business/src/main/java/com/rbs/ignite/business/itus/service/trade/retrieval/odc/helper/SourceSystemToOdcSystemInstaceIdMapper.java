package com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper;

import com.google.common.collect.Sets;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.domain.SystemInstanceId;

import java.util.Set;

/**
 * Created by upadkti on 07/11/2017.
 */
public enum SourceSystemToOdcSystemInstaceIdMapper {

  DAVE(ItusTradeSourceSystem.DAVE, Sets.newHashSet(SystemInstanceId.GDS,SystemInstanceId.GDS_GBLO,SystemInstanceId.GDS_USNY)),
  IGNITE(ItusTradeSourceSystem.IGNITE,Sets.newHashSet(SystemInstanceId.Ignite)),
  SYSTEMX(ItusTradeSourceSystem.SYSTEMX,Sets.newHashSet(SystemInstanceId.SystemX)),
  GFX(ItusTradeSourceSystem.GFX,Sets.newHashSet(SystemInstanceId.PabFX)),
  ICE(ItusTradeSourceSystem.ICE,Sets.newHashSet(SystemInstanceId.ICE));

  private ItusTradeSourceSystem itusTradeSourceSystem;
  private Set<SystemInstanceId> systemInstanceIds;

  SourceSystemToOdcSystemInstaceIdMapper(ItusTradeSourceSystem sourceSystem, Set<SystemInstanceId> systemInstanceIds) {
    this.itusTradeSourceSystem = sourceSystem;
    this.systemInstanceIds = systemInstanceIds;
  }

  public ItusTradeSourceSystem getSourceSystem() {
    return itusTradeSourceSystem;
  }

  public Set<SystemInstanceId> getSystemInstanceIds() {
    return systemInstanceIds;
  }

}
