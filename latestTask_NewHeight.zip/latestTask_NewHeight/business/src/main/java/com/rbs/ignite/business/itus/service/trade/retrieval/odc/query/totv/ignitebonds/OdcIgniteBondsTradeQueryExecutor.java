package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.ignitebonds;

import com.google.common.collect.Sets;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.OdcQueryExecutorHelper;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.AbstractOdcTradeQueryExecutor;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.ODC;
import com.rbs.odc.access.domain.AlternateInstrumentId;
import com.rbs.odc.access.domain.InstrumentId;
import com.rbs.odc.access.domain.RegimeImpactType;
import com.rbs.odc.access.domain.SecurityInstrumentIdentifierClassificationScheme;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionState;
import com.rbs.odc.dynamicquery.lang.FilterLanguage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDate;
import java.util.*;

import static com.rbs.odc.access.domain.SecurityInstrumentIdentifierClassificationScheme.ISIN;
import static com.rbs.odc.access.domain.SecurityInstrumentIdentifierClassificationScheme.Rdx_Series_Id;
import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.collection;
import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.instrument;
import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.transaction;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.and;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.or;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.valueOf;

/**
 * Created by upadkti on 08/12/2017.
 */
public class OdcIgniteBondsTradeQueryExecutor extends AbstractOdcTradeQueryExecutor {
  private static final Logger logger = LoggerFactory.getLogger(OdcIgniteBondsTradeQueryExecutor.class);
  private static final ItusTradeSourceSystem SOURCE_SYSTEM = ItusTradeSourceSystem.IGNITE;
  private @Value("${totv.odc.ignite.system.instance.ids}") String systemInstanceIds;
  private @Value("${totv.odc.ignite.exclude.trade.status}") String tradeStatusStr;

  @Override
  public Set<Transaction> executeQuery(Set<String> isinSet, LocalDate businessDate,String requestId) {
    Set<Transaction> transactions = new HashSet<>();
    Set<SystemInstanceId> systemInstanceIdSet = getSystemInstanceIdsFromString(systemInstanceIds, SOURCE_SYSTEM,requestId);
    Set<TransactionState> tradeStatuses = getTransactionStatesFromString(tradeStatusStr, SOURCE_SYSTEM,requestId);

    // As Ignite trades may not be mapped with ISIN, need to fetch then based on rdxSeriesId, Firstly fetch all rdxSeriesId for given isins
    Set<String> rdxSeriesIds = getRdxSeriesIdForGivenIsins(isinSet,requestId);

    FilterLanguage whereClause;

    if (rdxSeriesIds.size() > 0) {
      whereClause = and
        (
          valueOf(transaction().getId().getSourceSystemId()).in(systemInstanceIdSet),
          valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Post_Trade_Transparency),
          valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Transaction_Reporting),
          valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
            getRegimeImpactType()).notEqualTo("Transaction Reporting"),
          valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
            getRegimeImpactType()).notEqualTo("Post Trade Transparency"),
          valueOf(collection(transaction().getTransactionLegs()).getInstrumentId().getInstrumentScheme())
            .equalTo(SecurityInstrumentIdentifierClassificationScheme.Rdx_Series_Id),
          valueOf(collection(transaction().getTransactionLegs()).getInstrumentId().getInstrumentId()).in(rdxSeriesIds)
        );

      Set<Transaction> transactionsForRdxSeriesId = executeQuery(whereClause, businessDate,requestId);
      if(transactionsForRdxSeriesId!=null) {
        transactions.addAll(transactionsForRdxSeriesId);
      }
      logger.debug(requestId+":"+" ODC Query Criteria for IgniteBonds with rdxSeriesIds: " + whereClause.toString() );
    }

    whereClause  = and
      (
        valueOf(transaction().getId().getSourceSystemId()).in(systemInstanceIdSet),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Post_Trade_Transparency),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Transaction_Reporting),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Transaction Reporting"),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Post Trade Transparency"),
        valueOf(collection(transaction().getTransactionLegs()).getInstrumentId().getInstrumentScheme())
          .equalTo(SecurityInstrumentIdentifierClassificationScheme.ISIN),
        valueOf(collection(transaction().getTransactionLegs()).getInstrumentId().getInstrumentId()).in(isinSet)
      );
    logger.debug(requestId+":"+" ODC Query Criteria for IgniteBonds with isins: " + whereClause.toString() );
    Set<Transaction> transactionsForIsins = executeQuery(whereClause, businessDate,requestId);
    if(transactionsForIsins != null) {
      transactions.addAll(transactionsForIsins);
    }
    Map<String, Transaction> latestTransactionVersion = new HashMap<>();
    transactions.stream().forEach(transactionObj -> {
      String sourceTradeId = transactionObj.getId().getSourceSystemTransactionId();
      Long newVersion = transactionObj.getODCId().getOdcVersion();
      if (latestTransactionVersion.containsKey(sourceTradeId)) {
        Long oldVersion = latestTransactionVersion.get(transactionObj.getId().getSourceSystemTransactionId()).getODCId().getOdcVersion();
        if (newVersion > oldVersion) {
          logger.info(requestId+":"+"Found latest version for {}. Old version:{}, New Version:{}",sourceTradeId,oldVersion, newVersion);
          latestTransactionVersion.put(transactionObj.getId().getSourceSystemTransactionId(), transactionObj);
        }
      } else {
        logger.debug(requestId+":"+"New version for IgniteBond Trade[{}]. version:{}",sourceTradeId, newVersion);
        latestTransactionVersion.put(transactionObj.getId().getSourceSystemTransactionId(), transactionObj);
      }
    });


    Iterator<Transaction> iterator = latestTransactionVersion.values().iterator();
    while (iterator.hasNext()) {
      Transaction transaction = iterator.next();
      if (tradeStatuses.contains(transaction.getTransactionState())) {
        iterator.remove();
      }
    }

    return (Sets.newHashSet(latestTransactionVersion.values()));
  }

  private Set<String> getRdxSeriesIdForGivenIsins(Set<String> isinSet,String requestId) {
    Iterator<String> rdxSeriesIdIterator = odc.from().instrument().complexWhere(and(
      valueOf(instrument().getId().getInstrumentScheme()).equalTo(SecurityInstrumentIdentifierClassificationScheme.Rdx_Series_Id),
      valueOf(collection(instrument().getAlternativeIdentifiers()).getAlternateScheme()).equalTo(SecurityInstrumentIdentifierClassificationScheme.ISIN),
      valueOf(collection(instrument().getAlternativeIdentifiers()).getAlternateId()).in(isinSet)))
      .select(instrument().getId().getInstrumentId()).execute();;

    Set<String> rdxSeriesId = new HashSet<>();
    while(rdxSeriesIdIterator.hasNext()){
      rdxSeriesId.add(rdxSeriesIdIterator.next());
    }

    logger.info(requestId+":"+"RDX series IDs {} for ISINs {}", rdxSeriesId, isinSet);
    return rdxSeriesId;
  }
}
