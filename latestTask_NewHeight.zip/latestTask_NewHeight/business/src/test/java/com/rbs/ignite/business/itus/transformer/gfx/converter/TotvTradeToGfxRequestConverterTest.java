package com.rbs.ignite.business.itus.transformer.gfx.converter;

import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by upadkti on 20/12/2017.
 */
public class TotvTradeToGfxRequestConverterTest {

  private TotvTradeToGfxReqConverter testObj;

  @Before
  public void setup() {
    testObj = new TotvTradeToGfxReqConverter();
  }

  @Test
  public void testConvert() {
    TotvTrade inputTrade = new TotvTrade("ISIN12345","tradeId12345", ItusTradeSourceSystem.GFX,"LDN");
    TotvGfxRequest outputRequet = testObj.convert(inputTrade);

    Assert.assertEquals(outputRequet.getTransactionIdentifier(),"tradeId12345");
  }

  @Test
  public void testConvert_NoIdentifier() {
    TotvTrade inputTrade = new TotvTrade("ISIN12345",null, ItusTradeSourceSystem.GFX,"LDN");
    TotvGfxRequest outputRequet = testObj.convert(inputTrade);

    Assert.assertEquals(outputRequet.getTransactionIdentifier(),"");
  }
}
