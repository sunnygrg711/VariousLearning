package com.rbs.ignite.domain.itus.trade;

import java.util.Set;

public class ItusTradeUpdateSummary<Status extends ItusTradeStatus> {
    private Set<Status> tradeStatusSet;
    private Set<String> summary;

    public ItusTradeUpdateSummary(Set<Status> tradeStatusSet, Set<String> summary) {
        this.tradeStatusSet = tradeStatusSet;
        this.summary = summary;
    }

    public Set<Status> getTradeStatusSet() {
        return tradeStatusSet;
    }

    public Set<String> getSummary() {
        return summary;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ItusTradeUpdateSummary)) return false;

        ItusTradeUpdateSummary that = (ItusTradeUpdateSummary) o;

        if (!tradeStatusSet.equals(that.tradeStatusSet)) return false;
        return summary.equals(that.summary);
    }

    @Override
    public int hashCode() {
        int result = tradeStatusSet.hashCode();
        result = 31 * result + summary.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "ItusTradeUpdateSummary{" +
                "tradeStatusSet=" + tradeStatusSet +
                ", summary=" + summary +
                '}';
    }
}
