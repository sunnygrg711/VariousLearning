package com.rbs.ignite.business.itus.web.controller.totv.util;

import com.google.common.collect.Sets;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentDateInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvIsinRetrievalResponse;
import com.rbs.ignite.domain.itus.instrument.totv.TotvResponse;
import com.rbs.ignite.domain.itus.instrument.totv.TotvTradesInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvTradeRetrievalResponse;
import com.rbs.ignite.domain.itus.request.totv.TotvTradeAmendRequest;
import com.rbs.ignite.domain.itus.request.totv.TotvTradeRetrievalRequest;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Set;

/**
 * Created by upadkti on 18/01/2018.
 */
public class TotvControllerUtilTest {

  private  String date = "08/02/2018";
  private  LocalDate localDate;

  @Before
  public void setup () {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    localDate = LocalDate.parse(date, formatter);
  }

  @Test
  public void testGetTotvRequestIfRequestIdIsNotProvided() {

    TotvTradeAmendRequest request = TotvControllerUtil.getTotvRequest(null,true ,
            new TotvInstrumentDateInput(LocalDate.now()), Sets.newHashSet("ISIN12345"), Sets.newHashSet(ItusTradeSourceSystem.DAVE), false);
    Assert.assertFalse(request.getRequestId()==null);
    Assert.assertEquals(request.getDate().getDate(),LocalDate.now());
    Assert.assertTrue(request.getIsins().containsAll(Sets.newHashSet("ISIN12345")));
    Assert.assertTrue(request.getSourceSystems().contains(ItusTradeSourceSystem.DAVE));
  }

  @Test
  public void testGetTotvRequestIfRequestIdIsProvided() {
    TotvTradeAmendRequest request = TotvControllerUtil.getTotvRequest(null,true ,
            new TotvInstrumentDateInput(LocalDate.now()), Sets.newHashSet("ISIN12345"), Sets.newHashSet(ItusTradeSourceSystem.DAVE), false);
    Assert.assertEquals(request.getDate().getDate(),LocalDate.now());
    Assert.assertTrue(request.getIsins().containsAll(Sets.newHashSet("ISIN12345")));
    Assert.assertTrue(request.getSourceSystems().contains(ItusTradeSourceSystem.DAVE));
  }

  @Test
  public void testGetTotvRequestIfRequestIdAndTradesProvided() {
    TotvTradeAmendRequest request = TotvControllerUtil.getTotvRequest("<EMPTY>",
      Sets.newHashSet(new TotvTradesInput(Sets.newHashSet("1234","4567"),ItusTradeSourceSystem.DAVE,"GBLO")), false);
    Assert.assertEquals(request.getRequestId(),"<EMPTY>");
    Assert.assertEquals(request.getDate(),null);
    Assert.assertTrue(request.getIsins()==null);
    Assert.assertTrue(request.getSourceSystems()==null);
  }

  @Test
  public void testGetTotvRequestIfRequestIdNotAndTradesProvided() {

    TotvTradeAmendRequest request = TotvControllerUtil.getTotvRequest(null,
      Sets.newHashSet(new TotvTradesInput(Sets.newHashSet("1234","4567"),ItusTradeSourceSystem.DAVE,"GBLO")), false);
    Assert.assertFalse(request.getRequestId()==null);
    Assert.assertEquals(request.getDate(),null);
    Assert.assertTrue(request.getIsins() == null);
    Assert.assertTrue(request.getSourceSystems()==null);
    Assert.assertTrue(request.getTrades().size()==2);
  }

  @Test
  public void testCreateResponse() {
    Set<TotvTradeStatus> itusTradeStatuses = Sets.newHashSet();
    itusTradeStatuses.add(new TotvTradeStatus.TotvTradeStatusBuilder(new TotvTrade("ISIN1","ID12341",ItusTradeSourceSystem.GFX,"GBLO"), ItusStatus.ACCEPTED,"200").build());
    itusTradeStatuses.add(new TotvTradeStatus.TotvTradeStatusBuilder(new TotvTrade("ISIN2","ID12342",ItusTradeSourceSystem.GFX,"GBLO"), ItusStatus.REJECTED,"404").build());
    itusTradeStatuses.add(new TotvTradeStatus.TotvTradeStatusBuilder(new TotvTrade("ISIN3","ID12343",ItusTradeSourceSystem.GFX,"GBLO"), ItusStatus.TRADE_AMEND_SKIPPED,"500").build());
    itusTradeStatuses.add(new TotvTradeStatus.TotvTradeStatusBuilder(new TotvTrade("ISIN4","ID12344",ItusTradeSourceSystem.DAVE,"GBLO"), ItusStatus.ACCEPTED,"200").build());
    itusTradeStatuses.add(new TotvTradeStatus.TotvTradeStatusBuilder(new TotvTrade("ISIN5","ID12345",ItusTradeSourceSystem.DAVE,"GBLO"), ItusStatus.REJECTED,"404").build());
    TotvResponse response = TotvControllerUtil.createTotvResponse(itusTradeStatuses);

    Assert.assertEquals(response.getStatusCode(), "OK");
    Assert.assertEquals(response.getStatusMessage(), "Success");
    Assert.assertEquals(response.getResult().size(),2);
    Assert.assertEquals(response.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiers().size(),2);
    Assert.assertEquals(new Integer(1),response.getResult().get(ItusTradeSourceSystem.DAVE).getAcceptedCount());
    Assert.assertEquals(new Integer(1),response.getResult().get(ItusTradeSourceSystem.DAVE).getRejectedCount());
    Assert.assertEquals(response.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiers().size(),3);
    Assert.assertEquals(new Integer(1),response.getResult().get(ItusTradeSourceSystem.GFX).getAcceptedCount());
    Assert.assertEquals(new Integer(1),response.getResult().get(ItusTradeSourceSystem.GFX).getRejectedCount());
    Assert.assertEquals(new Integer(1),response.getResult().get(ItusTradeSourceSystem.GFX).getAmendSkippedCount());
  }

  @Test
  public void testCreateResponseThrowsException() {
    TotvResponse response = TotvControllerUtil.createTotvResponse(Sets.newHashSet(Mockito.mock(TotvTradeStatus.class)));

    Assert.assertEquals(response.getStatusCode(), "INTERNAL_SERVER_ERROR");
    Assert.assertEquals(response.getStatusMessage(), "Failure");
    Assert.assertEquals(response.getResult().size(), 0);
  }

  @Test
  public void testGetTotvTradeRetrivalIfRequestIdNotProvided() {
    TotvTradeRetrievalRequest request = TotvControllerUtil.getTotvTradeRetrivalRequest(null,true,date,
            Sets.newHashSet("12345"),Sets.newHashSet(ItusTradeSourceSystem.DAVE));
    Assert.assertTrue(request.getIsins().containsAll(Sets.newHashSet("12345")));
    Assert.assertFalse(request.getRequestId() == null);
    Assert.assertEquals(request.getDate(),localDate);
    Assert.assertTrue(request.getSourceSystems().contains(ItusTradeSourceSystem.DAVE));
  }

  @Test
  public void testGetTotvTradeRetrivalIfRequestIdProvided() {
    TotvTradeRetrievalRequest request = TotvControllerUtil.getTotvTradeRetrivalRequest("34567",true,date,
            Sets.newHashSet("12345"),Sets.newHashSet(ItusTradeSourceSystem.DAVE));
    Assert.assertTrue(request.getIsins().containsAll(Sets.newHashSet("12345")));
    Assert.assertTrue(request.getRequestId().equals("34567"));
    Assert.assertEquals(request.getDate(),localDate);
    Assert.assertTrue(request.getSourceSystems().contains(ItusTradeSourceSystem.DAVE));
  }

  @Test
  public void testcreateTotvISINRetrivalResponse() {
    TotvIsinRetrievalResponse response = TotvControllerUtil.createTotvISINRetrivalResponse(Sets.newHashSet("12345"));
    Assert.assertTrue(response.getResult().containsAll(Sets.newHashSet("12345")));
    Assert.assertTrue(response.getTotalCount() == 1);
    Assert.assertTrue(response.getStatusMessage().equals("Success"));
    Assert.assertTrue(response.getStatusCode().equals(HttpStatus.OK.name()));
  }

  @Test
  public void testcreateTotvTradeRetrivalResponse() {
    TotvTrade trade = new TotvTrade("12345","123",ItusTradeSourceSystem.DAVE
    ,"GDS");
    TotvTradeRetrievalResponse response = TotvControllerUtil.createTotvTradeRetrivalResponse(Sets.newHashSet(trade));

    Assert.assertTrue(response.getResult().containsAll(Sets.newHashSet(trade)));
    Assert.assertTrue(response.getTotalCount() == 1);
    Assert.assertTrue(response.getStatusMessage().equals("Success"));
    Assert.assertTrue(response.getStatusCode().equals(HttpStatus.OK.name()));
  }

  @Test
  public void testConvertDatetoLocalDate() {
    Assert.assertTrue(TotvControllerUtil.convertDatetoLocalDate("08/02/2018","dd/MM/yyyy") != null);
  }
}
