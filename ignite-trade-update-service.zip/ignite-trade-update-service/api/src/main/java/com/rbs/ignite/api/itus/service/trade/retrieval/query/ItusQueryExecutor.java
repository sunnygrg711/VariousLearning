package com.rbs.ignite.api.itus.service.trade.retrieval.query;



import com.rbs.ignite.domain.itus.enums.QueryParamName;

import java.util.concurrent.ConcurrentMap;

/**
 * Created by puronaa on 03/10/2017.
 */
public interface ItusQueryExecutor<Output> {

    Output executeQuery(ConcurrentMap<QueryParamName, Object> parameterMap);
}
