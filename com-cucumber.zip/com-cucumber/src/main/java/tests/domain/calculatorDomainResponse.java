package tests.domain;

/**
 * Created by kumaunn on 22/11/2017.
 */
public class calculatorDomainResponse {

  private String result;

  public calculatorDomainResponse(String result) {
    this.result = result;

     }

  public String getResult() {
    return result;
  }

  @Override
  public int hashCode() {
    return Integer.parseInt(result)*31;
  }
}
