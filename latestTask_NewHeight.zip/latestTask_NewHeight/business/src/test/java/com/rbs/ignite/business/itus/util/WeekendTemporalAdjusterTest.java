package com.rbs.ignite.business.itus.util;

import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import static org.junit.Assert.*;

public class WeekendTemporalAdjusterTest {
  @Test
  public void adjustInto_For_Sunday_minus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,4,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,7,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Monday_minus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,4,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,8,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }

  @Test
  public void adjustInto_For_tuesday_minus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,5,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,9,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Wednesday_minus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,8,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,10,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);

  }
  @Test
  public void adjustInto_For_Thursday_minus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,9,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,11,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Frriday_minus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,10,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,12,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Saturday_minus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,11,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,13,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Sunday_minus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,5,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,7,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Monday_minus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,5,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,8,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }

  @Test
  public void adjustInto_For_tuesday_minus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,8,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,9,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Wednesday_minus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,9,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,10,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);

  }
  @Test
  public void adjustInto_For_Thursday_minus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,10,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,11,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Frriday_minus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,11,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,12,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Saturday_minus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,12,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,13,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Sunday_plus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,9,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,7,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Monday_plus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,10,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,8,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }

  @Test
  public void adjustInto_For_tuesday_plus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,11,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,9,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Wednesday_plus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,12,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,10,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);

  }
  @Test
  public void adjustInto_For_Thursday_plus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,15,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,11,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Frriday_plus_two_days_london_timezone() throws Exception {
    int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,16,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,12,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Saturday_plus_two_days_london_timezone() throws Exception {
      int fromDays = 2;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,16,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,13,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Sunday_plus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,8,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,7,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Monday_plus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,9,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,8,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }

  @Test
  public void adjustInto_For_tuesday_plus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,10,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,9,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Wednesday_plus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,11,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,10,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);

  }
  @Test
  public void adjustInto_For_Thursday_plus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,12,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,11,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Frriday_plus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,15,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,12,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }
  @Test
  public void adjustInto_For_Saturday_plus_one_days_london_timezone() throws Exception {
    int fromDays = 1;
    String timeZone = "Europe/London";
    LocalDateTime localDateTime = LocalDateTime.of(2018,1,15,0,0,0);
    ZonedDateTime expectedLocalDateTime = localDateTime.atZone(ZoneId.of("Europe/London"));

    LocalDateTime localDateWithWeekendConsideration = LocalDateTime.of(2018, 1,13,0,0,0).with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.FORWARD));
    ZonedDateTime actualZonedDateTime = localDateWithWeekendConsideration.atZone(ZoneId.of("Europe/London"));
    Assert.assertEquals(expectedLocalDateTime,actualZonedDateTime);
  }

}