package com.rbs.ignite.business.itus.service.trade.totv;

import com.google.common.base.Stopwatch;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.rbs.ignite.api.itus.service.trade.IgniteTradeUpdateService;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentDateInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentInput;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.*;

/**
 * Created by upadkti on 13/11/2017.
 */
public abstract class AbstractTradeUpdateService<Status> implements IgniteTradeUpdateService<TotvInstrumentData, TotvTrade,TotvTradeStatus> {

  public static final Logger logger = LoggerFactory.getLogger(AbstractTradeUpdateService.class);

  @Value("${totv.fetch.batch.size}")
  private int batchSize;

  @Autowired
  private ExecutorService executorService;

  @Override
  public Set<TotvTradeStatus> updateForInstrumentInput(ItusInstrumentInput instrumentInput) throws ItusException {
    Stopwatch stopwatch = Stopwatch.createStarted();
    logger.info("Starting update of Instrument process.");
    final Set<TotvTradeStatus> itusTradeStatuses = ConcurrentHashMap.newKeySet();

    try {
      Set<TotvInstrumentData> instrumentData = getInstrumentData(instrumentInput);

      logger.info("Total ISINs {} ", instrumentData.size());
      if(logger.isDebugEnabled())
        logger.debug("ISINs received: " + instrumentData);

      if(batchSize <= 0)
        batchSize = 1000;

      Iterable<List<TotvInstrumentData>> partitionedInstrumentData = Iterables.partition(instrumentData, batchSize);
      List<Future<Set<TotvTradeStatus>>> futures = Lists.newArrayList();

      for (final List<TotvInstrumentData> totvInstrumentDataList : partitionedInstrumentData) {
        futures.add(executorService.submit(() -> {
          Set<TotvTrade> odcTrades = getTradeFromODC(Sets.newHashSet(totvInstrumentDataList), ((TotvInstrumentDateInput)instrumentInput).getDate());

          if (odcTrades != null && !odcTrades.isEmpty()) {
            if(logger.isDebugEnabled())
              logger.debug("Trades from ODC : " + odcTrades == null ? "null" : odcTrades.toString());
            return processTrades(odcTrades);
          }
          return null;
        }));
      }

      for(Future<Set<TotvTradeStatus>> future : futures)
      {
        try {
          Set<TotvTradeStatus>  partitionedItusTradeStatuses = future.get();
          if (partitionedItusTradeStatuses != null && !partitionedItusTradeStatuses.isEmpty()) {
            itusTradeStatuses.addAll(partitionedItusTradeStatuses);
          }
        } catch (ExecutionException | InterruptedException e) {
          logger.error("Exception ", e);
        }
      }
      if(logger.isDebugEnabled())
        logger.debug("itusTradeStatuses : " + itusTradeStatuses);
    } catch (RuntimeException e) {
      logger.error("Exception while processing updateForInstrumentInput ", e);
    }
    logger.info("Took {} ms. in updateForInstrumentInput" , stopwatch.elapsed(TimeUnit.MILLISECONDS));
    return itusTradeStatuses;
  }



  @Override
  public Set<TotvTradeStatus> updateForTrades(Set<TotvTrade> tradeSet){
    Set<TotvTradeStatus> tradeStatusSet = new LinkedHashSet<>();
    try {
      if (!tradeSet.isEmpty()) {
        logger.info("tradeSet:" + tradeSet == null ? "null" : tradeSet.toString());
        tradeStatusSet = processTrades(tradeSet);
      }
      logger.debug("tradeStatusSet:" + tradeStatusSet == null ? "null" : tradeStatusSet.toString());
    } catch (RuntimeException e) {
      logger.error(e.getMessage(), e);
    }

    return tradeStatusSet;
  }

  @Override
  public Set<TotvTradeStatus> updateForInstrumentsData(Set<TotvInstrumentData> instrumentDataSet, LocalDate date ){
    Set<TotvTradeStatus> tradeStatusSet = new LinkedHashSet<>();
    try {
      logger.info("Total ISINs {}, ISINs Received : {} for {} date", instrumentDataSet.size(), instrumentDataSet,date);
      Set<TotvTrade> tradeSet = getTradeFromODC(instrumentDataSet,date);
      String messageSummaryFromOdc = (tradeSet == null || tradeSet.isEmpty()) ? "No Trades Found in ODC" : "Trades Found in ODC: " + tradeSet.size();
      logger.info(messageSummaryFromOdc);

      if (!tradeSet.isEmpty()) {
        logger.info("tradeSet:" + tradeSet == null ? "null" : tradeSet.toString());
        tradeStatusSet = processTrades(tradeSet);
      }

      logger.debug("tradeStatusSet:" + tradeStatusSet == null ? "null" : tradeStatusSet.toString());
    } catch (RuntimeException e) {
      logger.error(e.getMessage(), e);
    }

    return tradeStatusSet;
  }

  protected abstract Set<TotvInstrumentData> getInstrumentData(ItusInstrumentInput instrumentInput);

  protected abstract Set<TotvTrade> getTradeFromODC(Set<TotvInstrumentData> dataSet, LocalDate date);

  protected abstract Set<TotvTradeStatus> processTrades(Set<TotvTrade> tradeSet);
}
