package org.sk.tutorial.jfamily.concurrency.examples.session2_2;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.LongAccumulator;
import java.util.concurrent.atomic.LongAdder;
import java.util.stream.IntStream;

/**
 * Created by kshekar on 08/05/2018.
 */
public class LongAccumulatorMain {

    static class MyThreadFactory implements ThreadFactory{

        @Override
        public Thread newThread(Runnable r) {
            return new Thread(r);
        }
    }
    public static void main(String[] args) throws InterruptedException {
        LongAccumulator longAccumulator=new LongAccumulator(Long::sum,0L);
        int numberOfThreads = 8;
        int numberOfIncrements = 100;
        Runnable longAccumulatorAction= () -> {
            IntStream.rangeClosed(0,numberOfIncrements).forEach(longAccumulator::accumulate);
            System.out.println(Thread.currentThread());
        };
        MyThreadFactory myThreadFactory=new MyThreadFactory();
        for(int i=0;i<numberOfThreads;i++){
            myThreadFactory.newThread(longAccumulatorAction).start();
        }
        Thread.sleep(1000);
        System.out.println("Expected count:"+(numberOfThreads*numberOfIncrements*(1+numberOfIncrements)/2)+" and actual count:"+longAccumulator.get());
        System.out.println(longAccumulator.getThenReset()+"::"+longAccumulator.getThenReset());
    }
}
