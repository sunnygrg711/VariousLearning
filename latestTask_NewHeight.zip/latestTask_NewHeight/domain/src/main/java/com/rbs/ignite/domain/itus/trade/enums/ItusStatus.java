package com.rbs.ignite.domain.itus.trade.enums;

/**
 * Created by puronaa on 26/09/2017.
 */
public enum ItusStatus {
    ACCEPTED("ACCEPTED"), REJECTED("REJECTED"), TRADE_AMEND_SKIPPED("TRADE_AMEND_SKIPPED") , THRESHOLD_BREACHED("THRESHOLD_BREACHED");

    ItusStatus(String status) {
        this.status = status;
    }

    private String status;

    public String getStatus() {
        return status;
    }


}
