package com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds;

import com.rbs.ignite.domain.itus.request.RequestEntity;

/**
 * Created by upadkti on 10/11/2017.
 */
public class IgniteRequestEntity implements RequestEntity {
  private Identifier identifier;
  private Event event;

  public IgniteRequestEntity(Identifier identifier, Event event) {
    this.identifier = identifier;
    this.event = event;
  }

  public Identifier getIdentifier() {
    return identifier;
  }

  public void setIdentifier(Identifier identifier) {
    this.identifier = identifier;
  }

  public Event getEvent() {
    return event;
  }

  public void setEvent(Event event) {
    this.event = event;
  }

  @Override
  public boolean equals(Object o) {
    if(this==o) return true;
    if(o==null||getClass()!=o.getClass()) return false;

    IgniteRequestEntity that = (IgniteRequestEntity) o;

    if(identifier!=null ? !identifier.equals(that.identifier) : that.identifier!=null) return false;
    return event!=null ? event.equals(that.event) : that.event==null;
  }

  @Override
  public int hashCode() {
    int result = identifier!=null ? identifier.hashCode() : 0;
    result = 31*result+(event!=null ? event.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "IgniteRequestEntity{"+
      "identifier="+identifier+
      ", event="+event+
      '}';
  }
}
