package org.sk.tutorial.jfamily.concurrency.examples.session3_1;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class Task implements Runnable {

    private CountDownLatch countDownLatch;

    public Task(CountDownLatch countDownLatch) {
        this.countDownLatch = countDownLatch;
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+":: processing is started on "+new Date());
        long startTime=System.currentTimeMillis();
        try {

            TimeUnit.SECONDS.sleep(new Random().nextInt(5));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        finally {
            countDownLatch.countDown();
            System.out.println(Thread.currentThread().getName()+":: processing is completed on "+new Date()+" . Processing time taken in second:"+(System.currentTimeMillis()-startTime)/1000);
        }
    }
}
