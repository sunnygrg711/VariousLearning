package org.sk.tutorial.jfamily.devopsutility.service;

import org.sk.tutorial.jfamily.devopsutility.model.*;

import java.lang.management.ThreadInfo;
import java.util.List;

/**
 * Created by kshekar on 03/04/2018.
 */
public interface ApplicationService {

    /**
     * Initialising application with details
      */
    void initApplicationDetail();

    /**
     * It Return all threads which are running on process
     * @return List of ThreadInfo
     */
    List<ThreadInfo> getThreadDump();

    /**
     * Download heap dump with .hprof file format and return file name
     * @return String
     */
    String downloadHeapDump(String processId);

    /**
     * get Memory detail for running process
     * @return MemoryDetail
     */
    MemoryDetail getMemoryDetail();

    /**
     * Get GC detail for running process
     * @return Gc
     */
    Gc getGcDetail();

    /**
     * Get JVM details for running process
     * @return JVMInfo
     */
    JVMInfo getJvmInfo();

    /**
     * Get Operating system details for running process
     * @return OsInfo
     */
    OsInfo getOsInfo();
}
