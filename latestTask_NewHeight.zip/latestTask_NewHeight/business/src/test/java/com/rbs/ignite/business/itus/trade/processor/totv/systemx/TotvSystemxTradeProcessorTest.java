package com.rbs.ignite.business.itus.trade.processor.totv.systemx;

import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTask;
import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTaskCallable;
import com.rbs.ignite.business.itus.jmx.TotvJmxProvider;
import com.rbs.ignite.business.itus.service.trade.processor.totv.gfx.TotvGfxSingleTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.systemx.TotvSystemXSingleTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.systemx.TotvSystemXTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.task.totv.TotvTradeTask;
import com.rbs.ignite.business.itus.totv.TotvStarter;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import com.rbs.ignite.business.itus.util.configurer.totv.TotvTestConfigurer;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatusHolder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.junit.Assert.assertEquals;

/**
 * Created by kumaunn on 15/11/2017.
 */
@SpringBootTest(classes = { TotvStarter.class, TotvTestConfigurer.class })
public class TotvSystemxTradeProcessorTest {

  @InjectMocks
  private TotvSystemXTradeProcessor systemXTradeProcessorObj = new TotvSystemXTradeProcessor(Executors.newWorkStealingPool(), Mockito.mock(TotvSystemXSingleTradeProcessor.class));
  @Mock
  private Future<ItusTradeStatus> future;
  @Mock
  private ApplicationContext context;
  @Mock
  private TotvSystemXSingleTradeProcessor totvSystemxSingleTradeProcessor;
  @Mock
  private TotvJmxProvider totvJmxProvider;
  private TotvTradeHolder tradeHolder;

  @Mock
  private TotvTrade trade;
  private Set tradeSet = new HashSet<TotvTrade>();

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    tradeHolder = new TotvTradeHolder(ItusTradeSourceSystem.SYSTEMX, tradeSet);
  }

  @Test
  public void testProcessTrade() throws Exception {
    ItusTradeTask itusTradeTask = new TotvTradeTask(trade, totvSystemxSingleTradeProcessor, Long.valueOf(1),"<EMPTY>");
    tradeSet.add(trade);
    Mockito.when(totvJmxProvider.getSystemXThresholdLimit()).thenReturn((long) 10);
    Mockito.when(context.getBean(Mockito.anyString(), Mockito.any(TotvTrade.class), Mockito.any(TotvSystemXSingleTradeProcessor.class), Mockito.any(Long.class))).thenReturn(itusTradeTask);
    TotvTradeStatus status = new TotvTradeStatus.TotvTradeStatusBuilder(trade, ItusStatus.ACCEPTED, "0").build();
    ItusTradeTaskCallable callable = new ItusTradeTaskCallable(itusTradeTask,"<EMPTY>");
    Mockito.when(context.getBean(Mockito.eq("itusTradeTaskCallable"), Mockito.any(TotvTradeTask.class),Mockito.anyString())).thenReturn(callable);
    Mockito.when(totvSystemxSingleTradeProcessor.processTrade(Mockito.any(TotvTrade.class),Mockito.anyString())).thenReturn(status);
    TotvTradeStatusHolder tradeStatusHolder = systemXTradeProcessorObj.processTrades(tradeHolder,"<EMPTY>", true);
    assertEquals("SystemX", tradeStatusHolder.getTradeSourceSystem().getName());
    assertEquals(1, tradeStatusHolder.getTradeStatusSet().size());
  }

  @Test
  public void testProcessTradeWhenThrReached() throws Exception {
    ItusTradeTask itusTradeTask = new TotvTradeTask(trade, totvSystemxSingleTradeProcessor, Long.valueOf(1),"<EMPTY>");
    tradeSet.add(trade);
    Mockito.when(totvJmxProvider.getSystemXThresholdLimit()).thenReturn((long) 0);
    Mockito.when(context.getBean(Mockito.anyString(), Mockito.any(TotvTrade.class), Mockito.any(TotvSystemXSingleTradeProcessor.class), Mockito.any(Long.class))).thenReturn(itusTradeTask);
    TotvTradeStatus status = new TotvTradeStatus.TotvTradeStatusBuilder(trade, ItusStatus.THRESHOLD_BREACHED, "-1").build();
    ItusTradeTaskCallable callable = new ItusTradeTaskCallable(itusTradeTask,"<EMPTY>");
    Mockito.when(context.getBean(Mockito.eq("itusTradeTaskCallable"), Mockito.any(TotvTradeTask.class),Mockito.anyString())).thenReturn(callable);
    TotvTradeStatusHolder tradeStatusHolder = systemXTradeProcessorObj.processTrades(tradeHolder,"<EMPTY>", false);
    assertEquals("SystemX", tradeStatusHolder.getTradeSourceSystem().getName());
    assertEquals(1, tradeStatusHolder.getTradeStatusSet().size());
  }

  @Test(expected = ItusFatalErrorException.class)
  public void testProcessTradeWhenException() throws Exception {
    tradeHolder = new TotvTradeHolder(ItusTradeSourceSystem.DAVE, tradeSet);
    systemXTradeProcessorObj.processTrades(tradeHolder,"<EMPTY>", false);
  }

  @Test
  public void testProcessTradeFailure() throws Exception {
    TotvTradeStatusHolder tradeStatusHolder = systemXTradeProcessorObj.processTrades(tradeHolder,"<EMPTY>", false);
    assertEquals("SystemX", tradeStatusHolder.getTradeSourceSystem().getName());
    assertEquals(0, tradeStatusHolder.getTradeStatusSet().size());
  }

  @After
  public void tearDown() {
    systemXTradeProcessorObj = null;
  }
}
