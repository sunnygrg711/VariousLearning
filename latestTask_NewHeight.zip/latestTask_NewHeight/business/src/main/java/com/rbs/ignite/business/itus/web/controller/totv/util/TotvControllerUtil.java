package com.rbs.ignite.business.itus.web.controller.totv.util;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentDateInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvResponse;
import com.rbs.ignite.domain.itus.instrument.totv.TotvTradesInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvTradeRetrievalResponse;
import com.rbs.ignite.domain.itus.instrument.totv.TotvIsinRetrievalResponse;
import com.rbs.ignite.domain.itus.request.totv.TotvTradeAmendRequest;
import com.rbs.ignite.domain.itus.request.totv.TotvTradeRetrievalRequest;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Created by upadkti on 12/01/2018.
 */
public class TotvControllerUtil {

  private static final String SUCCESS_MESSAGE = "Success";
  private static final String FAILED_MESSAGE = "Failure";

  public static TotvTradeAmendRequest getTotvRequest(String requestId, Boolean isDelta, TotvInstrumentDateInput date, Set<String> isins, Set<ItusTradeSourceSystem> sourceSystems, Boolean byPassThreshold) {
    TotvTradeAmendRequest request;
    if (StringUtils.isNotEmpty(requestId)) {
      request = new TotvTradeAmendRequest(requestId,isDelta,date,isins,sourceSystems,null,byPassThreshold);
    } else {
      request = new TotvTradeAmendRequest(UUID.randomUUID().toString(), isDelta,date, isins, sourceSystems, null,byPassThreshold);
    }
    return request;
  }

  public static TotvTradeRetrievalRequest getTotvTradeRetrivalRequest(String requestId, Boolean isDelta, String date, Set<String> isins, Set<ItusTradeSourceSystem> sourceSystems) {
    TotvTradeRetrievalRequest request;
    LocalDate localDate = TotvControllerUtil.convertDatetoLocalDate(date, "dd/MM/yyyy");

    if (StringUtils.isNotEmpty(requestId)) {
      request = new TotvTradeRetrievalRequest(requestId,isDelta,localDate,isins,sourceSystems,null);
    } else {
      request = new TotvTradeRetrievalRequest(UUID.randomUUID().toString(),isDelta, localDate, isins, sourceSystems, null);
    }
    return request;
  }

  public static TotvTradeAmendRequest getTotvRequest(String requestId, Set<TotvTradesInput> tradesSetInput, Boolean byPassThreshold) {
    Set<TotvTrade> totvTrades = new HashSet<>();
    tradesSetInput.forEach((tradeInput)->{
      tradeInput.getTradeIdentifiers().forEach((tradeId)->{
        totvTrades.add(new TotvTrade("",tradeId,tradeInput.getSourceSystem(),tradeInput.getLocation()));
      });
    });

    TotvTradeAmendRequest request;
    if (StringUtils.isNotEmpty(requestId)) {
      request = new TotvTradeAmendRequest(requestId,false,null,null,null,totvTrades,byPassThreshold);
    } else {
      request = new TotvTradeAmendRequest(UUID.randomUUID().toString(),false,null,null,null,totvTrades,byPassThreshold);
    }
    return request;
  }

  public static TotvResponse createTotvResponse(Set<TotvTradeStatus> tradeStatusSet) {
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = Maps.newHashMap();
    TotvResponse response;
    try {
      for(TotvTradeStatus totvTradeStatus : tradeStatusSet) {
        TotvResponse.SystemSpecificResponse systemSpecificResponse;
        if((systemSpecificResponse = result.get(totvTradeStatus.getTrade().getItusTradeSourceSystem()))==null) {
          systemSpecificResponse = new TotvResponse.SystemSpecificResponse();
          result.put(totvTradeStatus.getTrade().getItusTradeSourceSystem(), systemSpecificResponse);
        }
        List<String> tradeIdentifiers;
        if((tradeIdentifiers = systemSpecificResponse.getTradeIdentifiersForStatus(totvTradeStatus.getStatus()))==null) {
          tradeIdentifiers = Lists.newArrayList();
          systemSpecificResponse.getTradeIdentifiers().put(totvTradeStatus.getStatus(), tradeIdentifiers);
        }

        tradeIdentifiers.add(totvTradeStatus.getTrade().getTradeIdentifier());
      }
      response = new TotvResponse(HttpStatus.OK.name(), SUCCESS_MESSAGE, tradeStatusSet.size(), result);
    } catch(RuntimeException ex) {
      response = new TotvResponse(HttpStatus.INTERNAL_SERVER_ERROR.name(), FAILED_MESSAGE, tradeStatusSet.size(), result);
    }
    return response;
  }

  public static TotvIsinRetrievalResponse createTotvISINRetrivalResponse(Set<String> isinSet) {
      return new TotvIsinRetrievalResponse(HttpStatus.OK.name(), SUCCESS_MESSAGE, isinSet.size(), isinSet);
  }

  public static TotvTradeRetrievalResponse createTotvTradeRetrivalResponse(Set<TotvTrade> tradeSet) {
      return new TotvTradeRetrievalResponse(HttpStatus.OK.name(), SUCCESS_MESSAGE, tradeSet.size(), tradeSet);
  }

  public static LocalDate convertDatetoLocalDate(String date, String patteren) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(patteren);
    LocalDate localDate = LocalDate.parse(date, formatter);
    return  localDate;
  }
}
