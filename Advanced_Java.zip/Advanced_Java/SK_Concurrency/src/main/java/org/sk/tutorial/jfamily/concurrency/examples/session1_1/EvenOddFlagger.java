package org.sk.tutorial.jfamily.concurrency.examples.session1_1;

/**
 * Created by kshekar on 07/05/2018.
 */
public class EvenOddFlagger {
    private volatile boolean flag=true;
    private int counter=40;
    private int waitingTimeInMS=100;
    public boolean isEvenTerm() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public int getCounter() {
        return counter;
    }

    public int getWaitingTimeInMS() {
        return waitingTimeInMS;
    }
}
