package com.rbs.ignite.domain.itus.trade.totv;



import com.rbs.ignite.domain.itus.trade.ItusTradeStatusHolder;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import java.util.Collections;
import java.util.Set;

public class TotvTradeStatusHolder implements ItusTradeStatusHolder<TotvTradeStatus> {

    private ItusTradeSourceSystem tradeSourceSystem;

    private Set<TotvTradeStatus> tradeStatusSet;

    @Override
    public ItusTradeSourceSystem getTradeSourceSystem() {
        return tradeSourceSystem;
    }

    @Override
    public Set<TotvTradeStatus> getTradeStatusSet() {
        return tradeStatusSet;
    }

    public TotvTradeStatusHolder(ItusTradeSourceSystem tradeSourceSystem, Set<TotvTradeStatus> tradeStatusSet) {
        this.tradeSourceSystem = tradeSourceSystem;
        this.tradeStatusSet = Collections.unmodifiableSet(tradeStatusSet);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TotvTradeStatusHolder)) return false;

        TotvTradeStatusHolder that = (TotvTradeStatusHolder) o;

        if (tradeSourceSystem != that.tradeSourceSystem) return false;
        return tradeStatusSet.equals(that.tradeStatusSet);
    }

    @Override
    public int hashCode() {
        int result = tradeSourceSystem.hashCode();
        result = 31 * result + tradeStatusSet.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "TotvTradeStatusHolder{" +
                "tradeSourceSystem=" + tradeSourceSystem +
                ", tradeStatusSet=" + tradeStatusSet +
                '}';
    }
}
