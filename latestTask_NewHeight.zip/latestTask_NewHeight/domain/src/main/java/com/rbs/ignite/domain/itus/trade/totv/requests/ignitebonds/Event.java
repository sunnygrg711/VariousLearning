package com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds;

/**
 * Created by upadkti on 10/11/2017.
 */
public class Event {
  private String type;
  private String isin;


  public Event(String type, String isin) {
    this.type = type;
    this.isin = isin;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getIsin() {
    return isin;
  }

  public void setIsin(String isin) {
    this.isin = isin;
  }

  @Override
  public boolean equals(Object o) {
    if(this==o) return true;
    if(o==null||getClass()!=o.getClass()) return false;

    Event event = (Event) o;

    if(type!=null ? !type.equals(event.type) : event.type!=null) return false;
    return isin!=null ? isin.equals(event.isin) : event.isin==null;
  }

  @Override
  public int hashCode() {
    int result = type!=null ? type.hashCode() : 0;
    result = 31*result+(isin!=null ? isin.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "Event{"+
      "type='"+type+'\''+
      ", isin='"+isin+'\''+
      '}';
  }
}
