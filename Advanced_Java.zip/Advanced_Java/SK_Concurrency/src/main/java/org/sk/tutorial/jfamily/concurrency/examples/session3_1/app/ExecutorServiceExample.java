package org.sk.tutorial.jfamily.concurrency.examples.session3_1.app;

import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.*;

public class ExecutorServiceExample {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        System.out.println("###########################\nsimpleExample()");
        simpleExample();
        System.out.println("###########################\ninvokeAny()");
        invokeAny();
        System.out.println("###########################\nsubmit()");
        submit();
        System.out.println("###########################\ninvokeAll()");
        invokeAllTask();
    }

    private static void invokeAllTask() throws InterruptedException, ExecutionException {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<Callable<String>> callables = new HashSet<Callable<String>>();
        callables.add(()->"Task 1");
        callables.add(()->"Task 2");
        callables.add(()->"Task 3");
       List<Future<String>> futureList= executorService.invokeAll(callables);
       for(Future f:futureList) {
           System.out.println(f.isDone());
       }
        executorService.shutdown();
    }

    private static void submit() throws ExecutionException, InterruptedException {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future future = executorService.submit(()-> {
                System.out.println("Asynchronous Callable");
                return "Callable Result";
            }
        );

        System.out.println("future.get() = " + future.get());
    }

    private static void invokeAny() throws ExecutionException, InterruptedException {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Set<Callable<String>> callables = new HashSet<Callable<String>>();
        callables.add(()->"Task 1");
        callables.add(()->"Task 2");
        callables.add(()->{
            if(new Random().nextBoolean())
                throw new RuntimeException("IgnoreMe");
            return "Task";
        });
        String result = executorService.invokeAny(callables);

        System.out.println("result = " + result);

        executorService.shutdown();
    }

    private static void simpleExample() {
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        executorService.execute(() -> System.out.println("Asynchronous task"));
        executorService.shutdown();
    }
}
