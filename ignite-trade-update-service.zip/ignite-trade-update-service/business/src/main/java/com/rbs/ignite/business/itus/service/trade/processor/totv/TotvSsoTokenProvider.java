package com.rbs.ignite.business.itus.service.trade.processor.totv;

import com.rbs.gbm.rates.core.auth.security.SsoTokenProviderService;
import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import com.rbs.ignite.domain.itus.exception.ItusException;
import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

/**
 * Created by kumaunn on 14/11/2017.
 */
public class TotvSsoTokenProvider {

  private TokenProviderService service;

  public TotvSsoTokenProvider(SsoTokenProviderService ssoTokenProviderService) {

    this.service = ssoTokenProviderService;
  }

  public HttpHeaders getHttpHeaders() throws ItusException {
    HttpHeaders headers = new HttpHeaders();
    String authHeaderValue = getAuthorizationHeader();
    headers.add("Authorization", authHeaderValue);
    headers.setContentType(MediaType.APPLICATION_JSON);
    return headers;
  }

  private String getAuthorizationHeader() throws ItusException {
    return new String("SSO " + new String(Base64.encodeBase64(("ssoToken:" + service.getToken()).getBytes())));
  }
}
