package com.rbs.ignite.domain.itus.instrument.totv;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import javax.validation.constraints.NotNull;
import java.util.Set;

public class TotvTradesInput {

  @NotNull
  private Set<String> tradeIdentifiers;
  @NotNull
  private ItusTradeSourceSystem sourceSystem;
  @NotNull
  private String location;

  public TotvTradesInput(@JsonProperty("tradeIdentifiers") Set<String> tradeIdentifiers, @JsonProperty("sourceSystem") ItusTradeSourceSystem sourceSystem, @JsonProperty("location") String location) {
    this.tradeIdentifiers = tradeIdentifiers;
    this.sourceSystem = sourceSystem;
    this.location = location;
  }
  public Set<String> getTradeIdentifiers() {
    return tradeIdentifiers;
  }
  public ItusTradeSourceSystem getSourceSystem() {
    return sourceSystem;
  }
  public String getLocation() {
    return location;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvTradesInput that = (TotvTradesInput) o;

    if (!tradeIdentifiers.equals(that.tradeIdentifiers)) return false;
    if (sourceSystem != that.sourceSystem) return false;
    return location.equals(that.location);
  }
  @Override
  public int hashCode() {
    int result = tradeIdentifiers.hashCode();
    result = 31 * result + sourceSystem.hashCode();
    result = 31 * result + location.hashCode();
    return result;
  }
  @Override
  public String toString() {
    return "TotvTradesInput{" +
            "tradeIdentifiers=" + tradeIdentifiers +
            ", sourceSystem=" + sourceSystem +
            ", location='" + location + '\'' +
            '}';
  }
}
