package org.sk.tutorial.jfamily.adminui.service;

import org.sk.tutorial.jfamily.adminui.model.Application;
import org.sk.tutorial.jfamily.adminui.repository.ServiceDiscoveryRepository;

/**
 * Created by kshekar on 02/04/2018.
 */
public interface ServiceDiscoveryService extends ServiceDiscoveryRepository {
     String runningMemoryStatus(String applicationName) ;
     boolean updateState(String applicationName);

}
