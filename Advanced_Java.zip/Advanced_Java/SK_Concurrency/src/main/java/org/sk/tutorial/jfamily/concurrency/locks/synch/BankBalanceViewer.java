package org.sk.tutorial.jfamily.concurrency.locks.synch;

import org.sk.tutorial.jfamily.concurrency.locks.Account;
import org.sk.tutorial.jfamily.concurrency.locks.BalanceViewable;
import org.sk.tutorial.jfamily.concurrency.locks.Bank;

/**
 * Created by kshekar on 22/03/2018.
 */
public class BankBalanceViewer implements BalanceViewable {
    private Bank bank;
    private BankLockingImpl bankLocking;

    public BankBalanceViewer(Bank bank, BankLockingImpl bankLocking) {
        this.bank = bank;
        this.bankLocking = bankLocking;
    }

    public double getTotalBalance() {
        bankLocking.getBankLock().lock();
        try
        {
            double sum = 0;

            for (Account account : bank.getAccounts())
                sum += account.getBalanceAmount();

            return sum;
        }
        finally
        {
            bankLocking.getBankLock().unlock();
        }
    }

}
