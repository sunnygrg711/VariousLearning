package com.rbs.ignite.business.itus.configurer.totv;

import com.rbs.gbm.rates.core.auth.security.SSOAuthenticationService;
import com.rbs.gbm.rates.core.auth.security.SsoTokenProviderService;
import com.rbs.ignite.api.itus.service.instrument.ItusInstrumentService;
import com.rbs.ignite.api.itus.service.trade.IgniteTradeUpdateService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessingService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.retrieval.ItusTradeRetrievalService;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusQueryExecutor;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusTradeQueryExecutor;
import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTask;
import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTaskCallable;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.service.instrument.totv.irs.TotvIRSInstrumentService;
import com.rbs.ignite.business.itus.service.trade.processor.totv.TotvTradeProcessingService;
import com.rbs.ignite.business.itus.service.trade.processor.totv.dave.TotvDaveSingleTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.dave.TotvDaveTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.gfx.TotvGfxSingleTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.gfx.TotvGfxTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.ice.TotvIceSingleTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.ice.TotvIceTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.ignitebonds.TotvIgniteBondsSingleTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.ignitebonds.TotvIgniteBondsTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.systemx.TotvSystemXSingleTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.totv.systemx.TotvSystemXTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.OdcQueryExecutor;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.dave.OdcDaveTradeQueryExecutor;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.gfx.OdcGfxTradeQueryExecutor;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.ice.OdcIceTradeQueryExecutor;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.ignitebonds.OdcIgniteBondsTradeQueryExecutor;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.systemx.OdcSystemXTradeQueryExecutor;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.totv.OdcTradeRetrievalService;
import com.rbs.ignite.business.itus.service.trade.task.totv.TotvTradeTask;
import com.rbs.ignite.business.itus.service.trade.totv.TotvTradeUpdateService;
import com.rbs.ignite.business.itus.transformer.dave.TotvTradeToDaveReqTransformer;
import com.rbs.ignite.business.itus.transformer.dave.converter.TotvTradeToDaveReqConverter;
import com.rbs.ignite.business.itus.transformer.gfx.TotvTradeToGfxReqTransformer;
import com.rbs.ignite.business.itus.transformer.gfx.converter.TotvTradeToGfxReqConverter;
import com.rbs.ignite.business.itus.transformer.ice.TotvTradeToIceRequestTransformer;
import com.rbs.ignite.business.itus.transformer.ice.converter.TotvTradeToIceRequestConverter;
import com.rbs.ignite.business.itus.transformer.systemx.TotvTradeToSystemXReqTransformer;
import com.rbs.ignite.business.itus.transformer.systemx.converter.TotvTradeToSystemXReqConverter;
import com.rbs.ignite.business.itus.transformer.totv.TransactionToTotvTradeTransformer;
import com.rbs.ignite.business.itus.transformer.totv.converter.TransactionToTotvTradeConverter;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvFileBasedInstrumentInput;
import com.rbs.ignite.domain.itus.irs.TotvIRSResponse;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveResponse;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxResponse;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceResponse;
import com.rbs.ignite.domain.itus.trade.totv.systemx.TotvSystemXResponse;
import com.rbs.odc.access.ODC;
import com.rbs.odc.access.start.ODCSimpleStart;
import com.rbs.odc.core.util.ODCProperties;
import com.tibco.tibjms.TibjmsTopicConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Configuration
public class TotvConfigurer {
  private static final Logger logger = LoggerFactory.getLogger(TotvConfigurer.class);

  private static final String CYCLE_RETRIES = "com.rbs.odc.retries";

  private @Value("${sso.url}") String ssoUrl;

  private @Value("${totv.data.filename}") String totvDataFileName;

  private @Value("${odc.environment}") String odcEnvironment;
  private @Value("${odc.user.id}") String odcUser;
  private @Value("${odc.password}") String odcPassword;
  private @Value("${odc.initialisationTimeoutMillis}") String odcInitialisationTimeoutMillis;
  private @Value("${odc.retryCount}") String odcRetryCount;
  private @Value("${odc.executionTimeoutMillis}") String odcExecutionTimeoutMillis;
  private @Value("${odc.blender.enabled}") String odcBlenderEnabled;

  private @Value("${client.sso.user}") String clientSsoUser;
  private @Value("${client.sso.password}") String clientSsoPassword;

  private @Value("${client.dave.sso.user}") String daveSsoUser;
  private @Value("${client.dave.sso.password}") String daveSsoPassword;

  private @Value("${irs.service.url}") String irsServiceUrl;
  private @Value("${irs.sso.application}") String irsSSoApplication;

  private @Value("${dave.service.url}") String daveServiceUrl;
  private @Value("${dave.sso.application}") String daveSsoApplication;

  private @Value("${gfx.service.url}") String gfxServiceUrl;
  private @Value("${gfx.sso.application}") String gfxSSoApplication;

  private @Value("${systemX.service.url}") String systemXServiceUrl;
  private @Value("${systemX.sso.application}") String systemXSSoApplication;

  private @Value("${ice.service.url}") String iceWebServiceUrl;
  private @Value("${ice.sso.application}") String iceSSoApplication;

  private @Value("${totv.ignitebonds.messaging.server.url}") String messagingServerURL;
  private @Value("${totv.ignitebonds.messaging.username}") String messagingUsername;
  private @Value("${totv.ignitebonds.messaging.password}") String messagingPassword;
  private @Value("${totv.ignitebonds.messaging.header.key}") String messagingHeaderKey;
  private @Value("${totv.ignitebonds.messaging.header.value}") String messagingHeaderValue;
  private @Value("${totv.ignitebonds.messaging.event.topic}") String messagingEventTopic;

  @Bean
  public IgniteTradeUpdateService igniteTradeUpdateService() {
    logger.debug("Instantiating igniteTradeUpdateService");
    IgniteTradeUpdateService igniteTradeUpdateService = new TotvTradeUpdateService();
    logger.debug("Instantiated igniteTradeUpdateService");
    return igniteTradeUpdateService;
  }


  @Bean
  public ItusInstrumentService instrumentService() {
    ItusInstrumentService irsInstrumentService = new TotvIRSInstrumentService(irsServiceUrl, TotvIRSResponse.class,
      ssoTokenProviderService(clientSsoUser, clientSsoPassword, irsSSoApplication));
    return irsInstrumentService;
  }

  @Bean
  public ItusTradeRetrievalService tradeRetrievalService() {
    logger.debug("Instantiating tradeRetrievalService");
    ItusTradeRetrievalService tradeRetrievalService = new OdcTradeRetrievalService();
    logger.debug("Instantiated tradeRetrievalService");
    return tradeRetrievalService;
  }

  @Bean
  public ItusTransformer transactionToTotvTradeTransformer() {
    logger.debug("Instantiating tradeRetrievalService");
    TransactionToTotvTradeTransformer itusTransformer = new TransactionToTotvTradeTransformer();
    logger.debug("Instantiated tradeRetrievalService");
    return itusTransformer;
  }

  @Bean
  public ItusTransformer totvTradeToGfxReqTransformer() {
    logger.debug("Instantiating totvTradeToGfxReqTransformer");
    TotvTradeToGfxReqTransformer itusGfxTransformer = new TotvTradeToGfxReqTransformer();
    logger.debug("Instantiated totvTradeToGfxReqTransformer");
    return itusGfxTransformer;
  }

  @Bean
  public TotvTradeToGfxReqConverter totvTradeToGfxReqConverter() {
    logger.debug("Instantiating totvTradeToGfxReqConverter");
    TotvTradeToGfxReqConverter totvTradeToGfxReqConverter = new TotvTradeToGfxReqConverter();
    logger.debug("Instantiated totvTradeToGfxReqConverter");
    return totvTradeToGfxReqConverter;
  }

  @Bean
  public ItusTransformer totvTradeToSystemXReqTransformer() {
    logger.debug("Instantiating totvTradeToSystemXReqTransformer");
    TotvTradeToSystemXReqTransformer itusSystemxTransformer = new TotvTradeToSystemXReqTransformer();
    logger.debug("Instantiated totvTradeToSystemXReqTransformer");
    return itusSystemxTransformer;
  }

  @Bean
  public TotvTradeToSystemXReqConverter totvTradeToSystemXReqConverter() {
    logger.debug("Instantiating totvTradeToSystemXReqConverter");
    TotvTradeToSystemXReqConverter totvTradeToSystemxReqConverter = new TotvTradeToSystemXReqConverter();
    logger.debug("Instantiated totvTradeToSystemxReqConverter");
    return totvTradeToSystemxReqConverter;
  }

  @Bean
  public TransactionToTotvTradeConverter transactionToTotvTradeConverter() {
    logger.debug("Instantiating transactionToTotvTradeConverter");
    TransactionToTotvTradeConverter transactionToTotvTradeConverter = new TransactionToTotvTradeConverter();
    logger.debug("Instantiated transactionToTotvTradeConverter");
    return transactionToTotvTradeConverter;
  }

  @Bean
  public ItusQueryExecutor itusQueryExecutor() {
    logger.debug("Instantiating itusQueryExecutor");
    ItusQueryExecutor itusQueryExecutor = new OdcQueryExecutor();
    logger.debug("Instantiated itusQueryExecutor");
    return itusQueryExecutor;
  }

  @Bean
  public ODC odc() {
    logger.debug("Instantiating odc");
    logger.debug("odcEnvironment:" + odcEnvironment);
    logger.debug("odcUser:" + odcUser);
    System.setProperty(ODCProperties.ENVIRONMENT, odcEnvironment);
    System.setProperty("odc.blender.enabled", odcBlenderEnabled);
/*            Note that the retry count is for each possible server connection – it tries each possible connection up to the retry limit
            and only once all have failed will it throw. This means that for ODC configuration with 46 servers (the current prod
            configuration) a retry count of 2 will actually try each of 46 servers twice, so 92 connection attempts will be logged
             before the exception is thrown.*/
    System.setProperty(CYCLE_RETRIES, String.valueOf(odcRetryCount));
    ODC odc = ODCSimpleStart.getODCFactory().getAccessLayerInstance(odcUser, odcPassword);
    logger.debug("Instantiated odc");
    return odc;
  }

  @Bean
  public SourceSystemToOdcTradeExecutorMapper sourceSystemToOdcExecutorMapper() {
    logger.debug("Instantiating sourceSystemToOdcExecutorMapper");
    ConcurrentMap<ItusTradeSourceSystem, ItusTradeQueryExecutor> map = new ConcurrentHashMap<>();
    map.put(ItusTradeSourceSystem.DAVE, odcDaveTradeQueryExecutor());
    map.put(ItusTradeSourceSystem.GFX, odcGfxTradeQueryExecutor());
    map.put(ItusTradeSourceSystem.SYSTEMX, odcSystemXTradeQueryExecutor());
    map.put(ItusTradeSourceSystem.ICE, odcIceTradeQueryExecutor());
    map.put(ItusTradeSourceSystem.IGNITE, odcIgniteBondsTradeQueryExecutor());
    SourceSystemToOdcTradeExecutorMapper sourceSystemToOdcTradeExecutorMapper = new SourceSystemToOdcTradeExecutorMapper(map);
    logger.debug("Instantiated sourceSystemToOdcExecutorMapper");
    return sourceSystemToOdcTradeExecutorMapper;
  }

  @Bean
  public ItusTradeQueryExecutor odcDaveTradeQueryExecutor() {
    logger.debug("Instantiating ItusTradeQueryExecutor");
    OdcDaveTradeQueryExecutor odcDaveTradeQueryExecutor = new OdcDaveTradeQueryExecutor();
    logger.debug("Instantiated ItusTradeQueryExecutor");
    return odcDaveTradeQueryExecutor;
  }

  @Bean
  public ItusTradeQueryExecutor odcSystemXTradeQueryExecutor() {
    logger.debug("Instantiating OdcSystemXTradeQueryExecutor");
    ItusTradeQueryExecutor queryExecutor = new OdcSystemXTradeQueryExecutor();
    logger.debug("Instantiated OdcSystemXTradeQueryExecutor");
    return queryExecutor;
  }

  @Bean
  public ItusTradeQueryExecutor odcGfxTradeQueryExecutor() {
    logger.debug("Instantiating OdcGfxTradeQueryExecutor");
    OdcGfxTradeQueryExecutor queryExecutor = new OdcGfxTradeQueryExecutor();
    logger.debug("Instantiated OdcGfxTradeQueryExecutor");
    return queryExecutor;
  }

  @Bean
  public ItusTradeQueryExecutor odcIceTradeQueryExecutor() {
    logger.debug("Instantiating OdcIceTradeQueryExecutor");
    OdcIceTradeQueryExecutor queryExecutor = new OdcIceTradeQueryExecutor();
    logger.debug("Instantiated OdcIceTradeQueryExecutor");
    return queryExecutor;
  }

  @Bean
  public ItusTradeQueryExecutor odcIgniteBondsTradeQueryExecutor() {
    logger.debug("Instantiating OdcIgniteBondsTradeQueryExecutor");
    OdcIgniteBondsTradeQueryExecutor queryExecutor = new OdcIgniteBondsTradeQueryExecutor();
    logger.debug("Instantiated OdcIgniteBondsTradeQueryExecutor");
    return queryExecutor;
  }

  @Bean
  public ItusTradeProcessingService tradeProcessingService() {
    ItusTradeProcessingService tradeProcessingService = new TotvTradeProcessingService();
    return tradeProcessingService;
  }

  @Bean
  public ItusTradeProcessor daveTradeProcessor(){
    ItusTradeProcessor itusTradeProcessor = new TotvDaveTradeProcessor(executorService(), daveTradeWebService());
    return itusTradeProcessor;
  }

  @Bean
  public ItusSingleTradeProcessor daveTradeWebService() {
    logger.info("Instantiating daveTradeWebService");
    TotvDaveSingleTradeProcessor refTradeAmendWebService = new TotvDaveSingleTradeProcessor(daveServiceUrl, TotvDaveResponse.class,
      ssoTokenProviderService(daveSsoUser, daveSsoPassword, daveSsoApplication));
    logger.info("Instantiated daveTradeWebService");
    return refTradeAmendWebService;
  }

  @Bean
  public ItusTransformer totvTradeToDaveReqTransformer() {
    logger.info("Instantiating totvTradeToDaveReqTransformer");
    TotvTradeToDaveReqTransformer itusTransformer = new TotvTradeToDaveReqTransformer();
    logger.info("Instantiated totvTradeToDaveReqTransformer");
    return itusTransformer;
  }

  @Bean
  public TotvTradeToDaveReqConverter totvTradeToDaveReqConverter() {
    logger.info("Instantiating totvTradeToDaveReqConverter");
    TotvTradeToDaveReqConverter totvTradeToDaveReqConverter = new TotvTradeToDaveReqConverter();
    logger.info("Instantiated transactionToTotvTradeConverter");
    return totvTradeToDaveReqConverter;
  }

  @Bean
  public ItusTradeProcessor bondsTradeProcessor(){
    ItusTradeProcessor itusTradeProcessor = new TotvIgniteBondsTradeProcessor(igniteBondsSingleTradeProcessor());
    return itusTradeProcessor;
  }

  @Bean
  public ItusTradeProcessor gfxTradeProcessor() {
    ItusTradeProcessor itusTradeProcessor = new TotvGfxTradeProcessor(executorService(), gfxTradeWebService());
    return itusTradeProcessor;
  }

  @Bean
  public ItusTradeProcessor systemXTradeProcessor() {
    ItusTradeProcessor itusTradeProcessor = new TotvSystemXTradeProcessor(executorService(), systemXTradeWebService());
    return itusTradeProcessor;
  }

  @Bean
  public ItusTradeProcessor iceTradeProcessor() {
    ItusTradeProcessor itusTradeProcessor = new TotvIceTradeProcessor(executorService(), iceTradeWebService());
    return itusTradeProcessor;
  }

  @Bean
  @Scope("prototype")
  public ExecutorService executorService() {
    return Executors.newWorkStealingPool();
  }

  @Bean
  public TradeSystemToProcessorMapper tradeSystemToProcessorMapper() {
    logger.debug("Instantiating tradeSystemToProcessorMapper");
    ConcurrentMap<ItusTradeSourceSystem, ItusTradeProcessor> map = new ConcurrentHashMap<>();
    map.put(ItusTradeSourceSystem.DAVE, daveTradeProcessor());
    map.put(ItusTradeSourceSystem.GFX, gfxTradeProcessor());
    map.put(ItusTradeSourceSystem.SYSTEMX, systemXTradeProcessor());
    map.put(ItusTradeSourceSystem.ICE, iceTradeProcessor());
    map.put(ItusTradeSourceSystem.IGNITE, bondsTradeProcessor());
    TradeSystemToProcessorMapper tradeSystemToProcessorMapper = new TradeSystemToProcessorMapper(map);
    logger.debug("Instantiated tradeSystemToProcessorMapper");
    return tradeSystemToProcessorMapper;
  }

  @Bean
  public ItusSingleTradeProcessor igniteBondsSingleTradeProcessor(){
    logger.debug("Instantiating totvIgniteBondsSingleTradeProcessor");
    TotvIgniteBondsSingleTradeProcessor totvIgniteBondsSingleTradeProcessor = new TotvIgniteBondsSingleTradeProcessor(
      jmsTemplate(messagingServerURL,messagingUsername,messagingPassword),
      messagingHeaderKey, messagingHeaderValue,messagingEventTopic);
    logger.debug("Instantiated totvIgniteBondsSingleTradeProcessor");
    return totvIgniteBondsSingleTradeProcessor;
  }

  @Bean
  public JmsTemplate jmsTemplate(String messagingServerURL, String messagingUsername, String messagingPassword){
    TibjmsTopicConnectionFactory connectionFactory = new TibjmsTopicConnectionFactory(messagingServerURL);
    connectionFactory.setUserName(messagingUsername);
    connectionFactory.setUserPassword(messagingPassword);
    return new JmsTemplate(connectionFactory);
  }

  @Bean
  public RestTemplate restTemplate(){
    logger.debug("Instantiating restTemplate");
    RestTemplate restTemplate = new RestTemplate();
    logger.debug("Instantiated restTemplate");
    return restTemplate;
  }

  @Bean
  public ItusInstrumentInput instrumentInput() {
    String fileName = totvDataFileName;
    TotvFileBasedInstrumentInput input = new TotvFileBasedInstrumentInput(fileName);
    return input;
  }

  @Bean
  @Scope("prototype")
  public TotvTradeTask itusTradeTask(TotvTrade trade, ItusSingleTradeProcessor singleTradeProcessor, Long taskSequence) {
    logger.debug("Instantiating itusTradeTask");
    TotvTradeTask itusTradeTask = new TotvTradeTask(trade, singleTradeProcessor, taskSequence);
    logger.debug("Instantiated itusTradeTask");
    return itusTradeTask;
  }

  @Bean
  @Scope("prototype")
  public ItusTradeTaskCallable itusTradeTaskCallable(ItusTradeTask tradeTask) {
    logger.debug("Instantiating itusTradeTaskCallable");
    ItusTradeTaskCallable itusTradeTaskCallable = new ItusTradeTaskCallable(tradeTask);
    logger.debug("Instantiated itusTradeTaskCallable");
    return itusTradeTaskCallable;
  }

  @Bean
  public ItusSingleTradeProcessor gfxTradeWebService() {
    logger.info("Instantiating gfxTradeWebService");
    TotvGfxSingleTradeProcessor gfxTradeWebService = new TotvGfxSingleTradeProcessor(gfxServiceUrl,
            TotvGfxResponse.class,ssoTokenProviderService(clientSsoUser, clientSsoPassword, daveSsoApplication));
    logger.info("Instantiated gfxTradeWebService");
    return gfxTradeWebService;
  }

  @Bean
  public ItusSingleTradeProcessor systemXTradeWebService() {
    logger.info("Instantiating systemXTradeWebService");
    TotvSystemXSingleTradeProcessor systemXTradeWebService = new TotvSystemXSingleTradeProcessor(systemXServiceUrl,
            TotvSystemXResponse.class,ssoTokenProviderService(clientSsoUser,clientSsoPassword,systemXSSoApplication));
    logger.info("Instantiated systemXTradeWebService");
    return systemXTradeWebService;
  }

  @Bean
  public ItusSingleTradeProcessor iceTradeWebService() {
    logger.info("Instantiating iceTradeWebService");
    TotvIceSingleTradeProcessor systemXTradeWebService = new TotvIceSingleTradeProcessor(iceWebServiceUrl,
      TotvIceResponse.class,ssoTokenProviderService(clientSsoUser,clientSsoPassword,iceSSoApplication));
    logger.info("Instantiated iceTradeWebService");
    return systemXTradeWebService;
  }

  @Bean
  public ItusTransformer totvTradeToIceRequestTransformer() {
    logger.debug("Instantiating TotvTradeToIceRequestTransformer");
    TotvTradeToIceRequestTransformer totvTradeToIceRequestTransformer = new TotvTradeToIceRequestTransformer();
    logger.debug("Instantiated TotvTradeToIceRequestTransformer");
    return totvTradeToIceRequestTransformer;
  }

  @Bean
  public TotvTradeToIceRequestConverter totvTradeToIceRequestConverter() {
    logger.info("Instantiating TotvTradeToIceRequestConverter");
    TotvTradeToIceRequestConverter totvTradeToIceRequestConverter = new TotvTradeToIceRequestConverter();
    logger.info("Instantiated TotvTradeToIceRequestConverter");
    return totvTradeToIceRequestConverter;
  }

  @Bean
  @Scope("prototype")
  public SsoTokenProviderService ssoTokenProviderService(String user, String password, String application) {
    return new SsoTokenProviderService(user, password, application, new SSOAuthenticationService(ssoUrl));
  }
}
