package com.rbs.ignite.business.itus;

import com.rbs.ignite.business.itus.totv.TotvStarter;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TotvStarter.class)
@WebAppConfiguration
public class IgniteTradeUpdateServiceFT {

  @Autowired private WebApplicationContext context;
  private MockMvc mvc;

  @Test
  public void testHealthEnpoint() throws Exception {
    this.mvc = MockMvcBuilders.webAppContextSetup(this.context).build();
    mvc.perform(MockMvcRequestBuilders.get("/health")).andExpect(MockMvcResultMatchers.status().isOk());
  }
}