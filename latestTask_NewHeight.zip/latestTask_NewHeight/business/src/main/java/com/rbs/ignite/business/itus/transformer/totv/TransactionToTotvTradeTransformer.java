package com.rbs.ignite.business.itus.transformer.totv;


import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.odc.access.domain.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;

import java.util.Set;

public class TransactionToTotvTradeTransformer implements ItusTransformer<Set<Transaction>, Set<TotvTrade>> {

    @Autowired
    ConversionService conversionService;

    @Override
    public Set<TotvTrade> transform(Set<Transaction> transactionSet) throws ItusTransformException {
        TypeDescriptor sourceType = TypeDescriptor.collection(Set.class, TypeDescriptor.valueOf(Transaction.class));
        TypeDescriptor targetType = TypeDescriptor.collection(Set.class, TypeDescriptor.valueOf(TotvTrade.class));
        Set<TotvTrade> totvTradeSet = (Set<TotvTrade>) conversionService.convert(transactionSet, sourceType, targetType);
        return totvTradeSet;
    }
}
