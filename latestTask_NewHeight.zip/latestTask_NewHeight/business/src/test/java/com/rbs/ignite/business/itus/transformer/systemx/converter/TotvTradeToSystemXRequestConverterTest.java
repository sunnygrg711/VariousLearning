package com.rbs.ignite.business.itus.transformer.systemx.converter;

import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.systemx.TotvSystemXRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by upadkti on 20/12/2017.
 */
public class TotvTradeToSystemXRequestConverterTest {

  private TotvTradeToSystemXReqConverter testObj;

  @Before
  public void setup() {
    testObj = new TotvTradeToSystemXReqConverter();
  }

  @Test
  public void testConvert() {
    TotvTrade inputTrade = new TotvTrade("ISIN12345","tradeId12345", ItusTradeSourceSystem.SYSTEMX,"LDN");
    TotvSystemXRequest outputRequet = testObj.convert(inputTrade);

    Assert.assertEquals(outputRequet.getTransactionIdentifier(),"tradeId12345");
  }

  @Test
  public void testConvert_NoTradeIdentifier() {
    TotvTrade inputTrade = new TotvTrade("ISIN12345", null, ItusTradeSourceSystem.SYSTEMX,"LDN");
    TotvSystemXRequest outputRequet = testObj.convert(inputTrade);

    Assert.assertEquals(outputRequet.getTransactionIdentifier(),"");
  }
}
