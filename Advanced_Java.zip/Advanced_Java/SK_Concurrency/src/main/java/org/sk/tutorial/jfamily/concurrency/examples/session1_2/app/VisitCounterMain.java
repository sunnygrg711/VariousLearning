package org.sk.tutorial.jfamily.concurrency.examples.session1_2.app;


import org.sk.tutorial.jfamily.concurrency.examples.session1_2.VisitCounter;


import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


/**
 * Created by kshekar on 23/04/2018.
 */
public class VisitCounterMain {

    public static void main(String[] args) throws InterruptedException {

        System.out.println(Runtime.getRuntime().availableProcessors());
       final VisitCounter visitCounter=new VisitCounter();
       long expectedVisitCounter=100000L;
       int visitorThreads=10;
        CountDownLatch countDownLatch=new CountDownLatch((int)expectedVisitCounter);
        ExecutorService executors= Executors.newFixedThreadPool(visitorThreads);
        int counter=0;
        while(counter++<(int)expectedVisitCounter) {
            executors.submit(()->{
                    // System.out.println(Thread.currentThread()+":"+visitCounter.getCounter());
                try {
                    visitCounter.service(0,null);
                }
                catch (Exception e){
                   e.printStackTrace();
                }
                finally {
                    countDownLatch.countDown();
                }

            });
        }
        countDownLatch.await();
        executors.shutdown();
        System.out.printf("`\nResult :: expectedVisitCounter %d, actualVisitCounter %d\n",expectedVisitCounter,visitCounter.getCounter());
        org.junit.Assert.assertEquals(Long.valueOf( expectedVisitCounter),visitCounter.getCounter());

    }

}
