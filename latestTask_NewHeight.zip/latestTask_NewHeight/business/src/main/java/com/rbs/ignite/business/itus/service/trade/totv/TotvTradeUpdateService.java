package com.rbs.ignite.business.itus.service.trade.totv;

import com.google.common.collect.Sets;
import com.rbs.ignite.api.itus.service.instrument.ItusInstrumentService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessingService;
import com.rbs.ignite.api.itus.service.trade.retrieval.ItusTradeRetrievalService;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.util.Set;

public class TotvTradeUpdateService extends AbstractTradeUpdateService {

  private static final Logger logger = LoggerFactory.getLogger(TotvTradeUpdateService.class);

  @Autowired
  private ItusInstrumentService instrumentService;

  @Autowired
  private ItusTradeRetrievalService tradeRetrievalService;

  @Autowired
  private ItusTradeProcessingService tradeProcessingService;


  @Override
  public Set<TotvInstrumentData> getInstrumentData(ItusInstrumentInput instrumentInput, String requestId, Boolean isDelta) throws ItusException {
    Set<TotvInstrumentData> dataSet = null;
    dataSet = instrumentService.getInstrumentData(instrumentInput, requestId,isDelta );
    return dataSet;
  }

  @Override
  public Set<TotvTrade> retrieveTrades(Set<String> dataSet, LocalDate date, Set<ItusTradeSourceSystem> sourceSystems, String requestId) throws ItusException {
    Set<TotvTrade> tradeSet = null;
    tradeSet = tradeRetrievalService.retrieveTrades(dataSet, date, sourceSystems, requestId);
    return tradeSet;
  }

  @Override
  public Set<TotvTradeStatus> processTrades(Set<TotvTrade> tradeSet, String requestId, Boolean byPassThreshold) {
    Set<TotvTradeStatus> tradeStatusSet = Sets.newHashSet();
    try {
      tradeStatusSet = tradeProcessingService.processTrades(tradeSet, requestId,byPassThreshold);
    } catch (ItusException ex) {
      logger.error(requestId + ":" + "Error occurred while processing trades {}", tradeSet);
    }
    return tradeStatusSet;
  }
}