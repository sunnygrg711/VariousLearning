package org.sk.tutorial.jfamily.concurrency.examples.session1_3;


import org.sk.tutorial.jfamily.concurrency.annotation.ThreadSafeOnCondition;

/**
 * Created by kshekar on 23/04/2018.
 */
@ThreadSafeOnCondition
public class VolatileIntegerPojo {
    private volatile int value;
    private int random;
    public  int getValue() {
        System.out.println(Thread.currentThread()+"::"+random);
        return value;
    }

    public  void setValue(int value) {
        random++;
        this.value = value;
    }
}
