package org.sk.tutorial.jfamily.concurrency.examples.session1_2;

/**
 * Created by kshekar on 23/04/2018.
 */
public class Employee {
    public synchronized int  getDefaultBonus(){
        System.out.println(Thread.currentThread().getName()+" ->Inside getDefaultBonus::"+this);
        return 10000;
    }
}
