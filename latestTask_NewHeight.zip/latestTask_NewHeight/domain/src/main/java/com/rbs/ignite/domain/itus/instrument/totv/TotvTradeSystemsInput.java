package com.rbs.ignite.domain.itus.instrument.totv;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import javax.validation.constraints.NotNull;
import java.util.Set;

public class TotvTradeSystemsInput {

  @NotNull
  private TotvInstrumentDateInput dateInput;
  @NotNull
  private Set<ItusTradeSourceSystem> sourceSystems;

  public TotvTradeSystemsInput(@JsonProperty("dateInput") TotvInstrumentDateInput dateInput, @JsonProperty("sourceSystems") Set<ItusTradeSourceSystem> sourceSystems) {
    this.dateInput = dateInput;
    this.sourceSystems = sourceSystems;
  }
  public TotvInstrumentDateInput getDateInput() {
    return dateInput;
  }
  public Set<ItusTradeSourceSystem> getSourceSystems() {
    return sourceSystems;
  }
  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvTradeSystemsInput that = (TotvTradeSystemsInput) o;

    if (!dateInput.equals(that.dateInput)) return false;
    return sourceSystems.equals(that.sourceSystems);
  }
  @Override
  public int hashCode() {
    int result = dateInput.hashCode();
    result = 31 * result + sourceSystems.hashCode();
    return result;
  }
  @Override
  public String toString() {
    return "TotvTradeSystemsInput{" +
            "dateInput=" + dateInput +
            ", sourceSystems=" + sourceSystems +
            '}';
  }
}
