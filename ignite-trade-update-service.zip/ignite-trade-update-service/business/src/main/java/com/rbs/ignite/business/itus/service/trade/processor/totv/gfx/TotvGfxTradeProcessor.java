package com.rbs.ignite.business.itus.service.trade.processor.totv.gfx;


import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.processor.AbstractTradeProcessor;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatusHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;

public class TotvGfxTradeProcessor extends AbstractTradeProcessor {

  public static final Logger logger = LoggerFactory.getLogger(TotvGfxTradeProcessor.class);

  public TotvGfxTradeProcessor(ExecutorService executorService, ItusSingleTradeProcessor itusSingleTradeProcessor) {
    super(executorService, itusSingleTradeProcessor);
  }

  @Override
  public TotvTradeStatusHolder processTrades(TotvTradeHolder tradeHolder) throws ItusException {
    ItusTradeSourceSystem tradeSourceSystem = tradeHolder.getTradeSourceSystem();
    logger.info("Processing Trades for " + tradeSourceSystem);
    Set<TotvTrade> tradeSet = tradeHolder.getTradeSet();

    if (!tradeSourceSystem.equals(ItusTradeSourceSystem.GFX)) {
      throw new ItusFatalErrorException("Trades were routed to wrong Service " + tradeSourceSystem);
    }

    TotvTradeStatusHolder totvTradeStatusHolder = null;
    if (tradeSet.isEmpty()) {
      logger.info("No trades to process for: " + tradeSourceSystem);
      Set<TotvTradeStatus> tradeStatusSet = new HashSet<TotvTradeStatus>();
      totvTradeStatusHolder = new TotvTradeStatusHolder(tradeSourceSystem, tradeStatusSet);
    } else {
      Set<TotvTradeStatus> tradeStatusSet = call(tradeHolder.getTradeSet());
      totvTradeStatusHolder = new TotvTradeStatusHolder(tradeSourceSystem, tradeStatusSet);
    }

    logger.info("totvTradeStatusHolder: " + totvTradeStatusHolder);
    return totvTradeStatusHolder;
  }

}
