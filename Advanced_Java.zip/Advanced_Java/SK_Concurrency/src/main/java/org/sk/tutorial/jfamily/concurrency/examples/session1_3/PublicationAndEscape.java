package org.sk.tutorial.jfamily.concurrency.examples.session1_3;

import java.util.*;

/**
 * Created by kshekar on 24/04/2018.
 */
public class PublicationAndEscape {

    public  Set<IntegerPojo> integerPojoSet;

    public void init(){
        integerPojoSet=new HashSet<>();
    }

    private List<String> stateList= Arrays.asList("UP","MP","MAHARASHTRA");
    public List<String> getStateList(){
        return stateList;
    }

    private Object mydata="Secret";

public PublicationAndEscape(DataRegistry dataRegistry){
    dataRegistry.register(new IData() {
        @Override
        public void doAction(Object data) {
           if(data instanceof ALoop){
               ((ALoop)data).setData(mydata);
           }
            System.out.println("Done!");
        }
    });
}


}



