package com.rbs.ignite.business.itus.mgmt;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * Created by kumaunn on 12/12/2017.
 */
@Component
public class IRSHealthIndicator extends AbstractHealthIndicator {

  @Autowired
  private RestTemplate restTemplate;

  @Value("${irs.health.url}")
  private String irsUrl;

  @Override
  protected void doHealthCheck(Health.Builder builder) throws Exception {

    JsonNode resp = restTemplate.getForObject(irsUrl, JsonNode.class);
    if (resp.get("status").asText().equalsIgnoreCase("UP")) {
      builder.withDetail("Env " ,irsUrl).status(Status.UP);
    } else {
      builder.status(Status.DOWN);
    }
  }
}
