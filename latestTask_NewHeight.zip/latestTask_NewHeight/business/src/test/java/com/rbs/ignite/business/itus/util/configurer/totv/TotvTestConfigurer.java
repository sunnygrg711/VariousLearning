package com.rbs.ignite.business.itus.util.configurer.totv;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbs.ignite.business.itus.web.controller.totv.mock.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.ConnectorServerFactoryBean;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.remoting.rmi.RmiRegistryFactoryBean;

import static org.mockito.Mockito.mock;

/**
 * Test classes can reference this configurer like so:
 * <pre>
 * @SpringBootTest(classes = { TotvStarter.class, TotvTestConfigurer.class })
 * </pre>
 * We use this class to override any default bean definitions e.g. replace an EMS broker with an in-memory broker etc, use a more
 * test-friendly registration policy for JMX beans etc.
 */
@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
public class TotvTestConfigurer {

  @Autowired
  private ObjectMapper objectMapper;


  protected @Value("${irs.service.url}")
  String irsServiceUrl;

  protected @Value("${dave.service.url}")
  String daveServiceUrl;
  protected @Value("${ice.service.url}")
  String iceServiceUrl;
  protected @Value("${systemX.service.url}")
  String systemXServiceUrl;
  protected @Value("${gfx.service.url}")
  String gfxServiceUrl;
  private static final Logger logger = LoggerFactory.getLogger(TotvTestConfigurer.class);

  @Bean
  public RmiRegistryFactoryBean rmiRegistry() {
    return mock(RmiRegistryFactoryBean.class);
  }

  @Bean
  @DependsOn("rmiRegistry")
  public ConnectorServerFactoryBean connectorServerFactoryBean() throws Exception {
    return mock(ConnectorServerFactoryBean.class);
  }

  @Bean
  public IrsMockServer irsMockServer(){
    return new IrsMockServer(irsServiceUrl);
  }
  @Bean
  public DaveMockServer daveMockServer(){
    return new DaveMockServer(daveServiceUrl);
  }
  @Bean
  public IceMockServer iceMockServer(){
    return new IceMockServer(iceServiceUrl);
  } @Bean
  public GfxMockServer gfxMockServer(){
    return new GfxMockServer(gfxServiceUrl);
  }

  @Bean
  public SystemXMockServer systemXMockServer(){
    return new SystemXMockServer(systemXServiceUrl);
  }


}
