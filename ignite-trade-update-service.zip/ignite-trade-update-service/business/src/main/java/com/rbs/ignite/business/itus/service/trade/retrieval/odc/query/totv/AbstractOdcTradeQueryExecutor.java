package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv;

import com.google.common.collect.Sets;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusTradeQueryExecutor;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.OdcQueryExecutorHelper;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.ODC;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionState;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;
import com.rbs.odc.access.query.Query;
import com.rbs.odc.core.domain.SnapshotImpl;
import com.rbs.odc.dynamicquery.lang.FilterLanguage;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Created by upadkti on 08/12/2017.
 */
public abstract class AbstractOdcTradeQueryExecutor implements ItusTradeQueryExecutor<Transaction> {

  private static final Logger logger = LoggerFactory.getLogger(AbstractOdcTradeQueryExecutor.class);

  @Autowired
  protected ODC odc;

  @Value("${totv.fetch.trade.from.days:2}")
  private int fromDays;

  @Value("${totv.fetch.trade.start.hour:18}")
  private int startHourOfTheDay;

  @Value("${totv.fetch.trade.for.hours:24}")
  private int hoursOfData;

  @Value("${totv.fetch.trade.timezone:Europe/London}")
  private String timeZone;

  @Override
  public Set<Transaction> executeQuery(Set<String> isins,LocalDate businessDate) {
    FilterLanguage whereClause = createQuery(isins);
    if(whereClause!=null) {
      ZonedDateTime fromDate = OdcQueryExecutorHelper.getZonedDateTime(businessDate,fromDays , startHourOfTheDay, timeZone);
      ZonedDateTime toDate = fromDate.plusHours(hoursOfData);
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM/dd/yyyy HH:mm:ss");
      logger.info("Time range :: [" + fromDate.format(formatter) + " (" + fromDate.toInstant().toEpochMilli() + ")] " +
        "to [" + toDate.format(formatter) + " (" + toDate.toInstant().toEpochMilli() +  ")]");

      Query<Transaction> query = odc.from().transaction().complexWhere(whereClause)
        .arrivedBetween(new SnapshotImpl(fromDate.toInstant().toEpochMilli()), new SnapshotImpl(toDate.toInstant().toEpochMilli())).driveFromLatest();

      Iterator<Transaction> transactionIterator = query.execute();
      return OdcQueryExecutorHelper.getTransactionSetFromIteartor(transactionIterator);
    }
    return Sets.newHashSet();
  }

  protected abstract FilterLanguage createQuery(Set<String> isins);

  protected Set<SystemInstanceId> getSystemInstanceIdsFromString(String systemInstanceIds, ItusTradeSourceSystem sourceSystem) {
    Set<SystemInstanceId> systemInstanceIdSet = new HashSet<>();
    try {
      if(StringUtils.isNotEmpty(systemInstanceIds)) {
        String[] systemInstanceIdArray = systemInstanceIds.split(",");
        if (systemInstanceIdArray != null && systemInstanceIdArray.length > 0) {
          for(String systemInstanceId : systemInstanceIdArray) {
            systemInstanceIdSet.add(SystemInstanceId.valueOf(systemInstanceId));
          }
        }
      }
    } catch (UnknownEnumerationValueException ex) {
      logger.error("Wrong property value passed for property {}, only {} SystemInstanceIds will be used to query trades from ODC",
        "totv.odc."+sourceSystem.getName().toLowerCase()+".system.instance.ids",systemInstanceIdSet);
    }

    logger.info("SystemInstanceIds for source System {}:",systemInstanceIdSet, sourceSystem.getName());
    return systemInstanceIdSet;
  }

  protected Set<TransactionState> getTransactionStatesFromString(String tradeStatuses, ItusTradeSourceSystem sourceSystem) {
    Set<TransactionState> transactionStates = new HashSet<>();
    try {
      if(StringUtils.isNotEmpty(tradeStatuses)) {
        String[] transactionStatesArray = tradeStatuses.split(",");
        if (transactionStatesArray != null && transactionStatesArray.length > 0) {
          for(String systemInstanceId : transactionStatesArray) {
            transactionStates.add(TransactionState.valueOf(systemInstanceId));
          }
        }
      }
    } catch (UnknownEnumerationValueException ex) {
      logger.error("Wrong property value passed for property {}, only {} TransactionStates will be used to query trades from ODC",
        "totv.odc."+sourceSystem.getName().toLowerCase()+".trade.status",transactionStates);
    }

    logger.info("SystemInstanceIds for source System {}:",transactionStates, sourceSystem.getName());
    return transactionStates;
  }
}
