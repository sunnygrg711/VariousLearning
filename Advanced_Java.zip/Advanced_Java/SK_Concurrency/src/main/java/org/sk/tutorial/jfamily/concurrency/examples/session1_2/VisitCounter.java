package org.sk.tutorial.jfamily.concurrency.examples.session1_2;


import org.sk.tutorial.jfamily.concurrency.annotation.NotThreadSafe;

@NotThreadSafe(reason = "read-modify-write")
public class VisitCounter {
    private Long counter = 0L;

    public void service(int data, Object object) {
        counter = counter + 1;
        validate(data, object);
        doAction(data);
        endProcess(object);

    }

    public Long getCounter() {
        return counter;
    }

    private void endProcess(Object object) {
    }

    private void doAction(int data) {

    }

    private void validate(int data, Object object) {

    }
}
