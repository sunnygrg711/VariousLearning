package com.rbs.ignite.business.itus.service.trade.processor.totv.dave;

import com.rbs.gbm.rates.core.auth.security.SsoTokenProviderService;
import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.processor.ItusWebServiceInterface;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.util.WebServiceUtil;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveRequest;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveResponse;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;

import static com.rbs.ignite.business.itus.util.CommonConstantsUtil.CORRELATION.DAVE;

/**
 * Class which process single Dave trade
 */
public class TotvDaveSingleTradeProcessor implements ItusWebServiceInterface<TotvDaveRequest, TotvDaveResponse>, ItusSingleTradeProcessor<TotvTrade> {

  private static final Logger logger = LoggerFactory.getLogger(TotvDaveSingleTradeProcessor.class);

  private String tradeServiceUrl;

  private Class<TotvDaveResponse> responseClass;

  private TokenProviderService ssoTokenProviderService;

  @Autowired
  private ItusTransformer totvTradeToDaveReqTransformer;

  @Autowired
  private RestTemplate restTemplate;

  public TotvDaveSingleTradeProcessor(String tradeServiceUrl, Class<TotvDaveResponse> responseClass, SsoTokenProviderService ssoTokenProviderService) {
    this.tradeServiceUrl = tradeServiceUrl;
    this.responseClass = responseClass;
    this.ssoTokenProviderService = ssoTokenProviderService;
  }

  @Override
  public String getTradeServiceUrl() {
    return tradeServiceUrl;
  }

  @Override
  public Class<TotvDaveResponse> getResponseClass() {
    return responseClass;
  }

  @Override
  public TotvTradeStatus processTrade(TotvTrade totvTrade,String requestId) throws ItusException {
    logger.debug(requestId+":"+"Processing Dave Trade. {} ", totvTrade);
    TotvDaveRequest totvDaveRequest = (TotvDaveRequest) totvTradeToDaveReqTransformer.transform(totvTrade);
    TotvTradeStatus status = null;
    try {
      TotvDaveResponse response = getResponse(totvDaveRequest, requestId);
      status = getItusTradeStatus(totvTrade, response);
      logger.debug(requestId+":"+"Dave Trade and status: Trade[{}], TradeStatus[{}]", totvTrade,status);
    } catch (Exception e) {
      logger.warn(requestId+":"+"Error occurred while processing request {}: {}",totvDaveRequest, e);
      status = new TotvTradeStatus.TotvTradeStatusBuilder(totvTrade, ItusStatus.REJECTED, HttpStatus.SERVICE_UNAVAILABLE.toString()).exceptions(e.getMessage()).build();
    }
    return status;
  }

  @Override
  public TotvDaveResponse getResponse(TotvDaveRequest totvDaveRequest, String requestId) {
    HttpEntity<TotvDaveRequest> httpEntity = new HttpEntity(totvDaveRequest, WebServiceUtil.getHttpHeaders(ssoTokenProviderService, DAVE));
    logger.info(requestId+":"+"Calling Dave Service {} : {} , Target {} ", DAVE.getKey(), httpEntity.getHeaders().get(DAVE.getKey()), totvDaveRequest != null ? totvDaveRequest.toString() : " ");
    TotvDaveResponse response = (restTemplate.postForObject(tradeServiceUrl, httpEntity, getResponseClass()));
    logger.info(requestId+":"+"{} : {}, Response {} ", DAVE.getKey(), httpEntity.getHeaders().get(DAVE.getKey()), response);
    return response;
  }

  private TotvTradeStatus getItusTradeStatus(TotvTrade trade, TotvDaveResponse totvDaveResponse) throws ItusException, ParseException {
    if (totvDaveResponse == null) {
      throw new ItusException("Invalid Response from trade system");
    }
    int code = totvDaveResponse.getResponseDto().getCode();

    ItusStatus itusStatus = null;
    switch (code) {
      case 0:
        itusStatus = ItusStatus.ACCEPTED;
        break;
      default:
        itusStatus = ItusStatus.REJECTED;
    }
    TotvTradeStatus.TotvTradeStatusBuilder totvTradeStatus = new TotvTradeStatus.TotvTradeStatusBuilder(trade, itusStatus, String.valueOf(code));
    if (totvDaveResponse.getResponseDto().getInformation() != null && totvDaveResponse.getResponseDto().getInformation().length!=0)
      totvTradeStatus.message(totvDaveResponse.getResponseDto().getInformation().toString());
    if (totvDaveResponse.getResponseDto().getExceptions() != null && totvDaveResponse.getResponseDto().getExceptions().length!=0)
      totvTradeStatus.exceptions(totvDaveResponse.getResponseDto().getExceptions()[0].getMessage());
    return totvTradeStatus.build();
  }
}
