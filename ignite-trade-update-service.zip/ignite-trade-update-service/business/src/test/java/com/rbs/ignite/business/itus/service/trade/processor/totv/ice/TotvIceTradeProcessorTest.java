package com.rbs.ignite.business.itus.service.trade.processor.totv.ice;

import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTask;
import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTaskCallable;
import com.rbs.ignite.business.itus.service.trade.processor.totv.ignitebonds.TotvIgniteBondsTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.task.totv.TotvTradeTask;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatusHolder;
import org.junit.*;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.junit.Assert.assertEquals;


@RunWith(MockitoJUnitRunner.class)
public class TotvIceTradeProcessorTest {
  @Mock
  private ExecutorService executorService;
  @Mock
  private ItusSingleTradeProcessor itusSingleTradeProcessor;
  @Mock
  private TotvTradeHolder totvTradeHolder;
  @Mock
  private TotvTrade totvTrade;
  @Mock
  private TotvTradeStatus totvTradeStatus;
  @Mock
  private ApplicationContext context;
  @Mock
  private TotvTradeTask itusTradeTask;
  @Mock
  private ItusTradeTaskCallable itusTradeTaskCallable;
  @Mock
  private Future future;
  @Rule
  public ExpectedException thrown = ExpectedException.none();
  @InjectMocks
  private TotvIceTradeProcessor testObj=new TotvIceTradeProcessor(executorService, itusSingleTradeProcessor);

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @After
  public void tearDown() {
    testObj = null;
  }

  @Test
  public void testProcessingOneTrade() throws Exception {
    Mockito.when(totvTradeHolder.getTradeSourceSystem()).thenReturn(ItusTradeSourceSystem.ICE);
    Mockito.when(totvTradeHolder.getTradeSet()).thenReturn(Sets.newSet(totvTrade));
    Mockito.when(itusSingleTradeProcessor.processTrade(totvTrade)).thenReturn(totvTradeStatus);
    Mockito.when(context.getBean(Mockito.eq("itusTradeTask"), Mockito.anyObject(), Mockito.anyObject(), Mockito.anyObject())).thenReturn(itusTradeTask);
    TotvTradeStatus tradeStatus = new TotvTradeStatus.TotvTradeStatusBuilder(totvTrade, ItusStatus.ACCEPTED,"200").build();
    Mockito.when(context.getBean(Mockito.eq("itusTradeTaskCallable"), Mockito.any(TotvTradeTask.class))).thenReturn(itusTradeTaskCallable);
    Mockito.when(executorService.submit((Callable<? extends Object>) Mockito.any())).thenReturn(future);
    Mockito.when(future.get()).thenReturn(tradeStatus);
    TotvTradeStatusHolder tradestatusHolder= testObj.processTrades(totvTradeHolder);
    Assert.assertEquals(tradestatusHolder.getTradeSourceSystem(), ItusTradeSourceSystem.ICE);
    Assert.assertTrue(tradestatusHolder.getTradeStatusSet().contains(tradeStatus));
  }

  @Test
  public void testProcessingNoTrade() throws Exception {
    Mockito.when(totvTradeHolder.getTradeSourceSystem()).thenReturn(ItusTradeSourceSystem.ICE);
    Mockito.when(totvTradeHolder.getTradeSet()).thenReturn(Sets.newSet());
    TotvTradeStatusHolder tradeStatus = testObj.processTrades(totvTradeHolder);
    Assert.assertTrue(tradeStatus.getTradeStatusSet().size() == 0);
  }

  @Test
  public void testProcessorThrowsExceptionIfSourceSystemIsNotIgniteBonds() throws Exception {
    Mockito.when(totvTradeHolder.getTradeSourceSystem()).thenReturn(ItusTradeSourceSystem.SYSTEMX);
    Mockito.when(totvTradeHolder.getTradeSet()).thenReturn(Sets.newSet());
    thrown.expect(ItusFatalErrorException.class);
    thrown.expectMessage("Trades were routed to wrong Service ItusTradeSourceSystem{name='SystemX'}");
    TotvTradeStatusHolder tradeStatus = testObj.processTrades(totvTradeHolder);
  }
}
