package com.rbs.ignite.api.itus.service.instrument;



import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentData;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;

import java.util.Set;

/**
 * Created by puronaa on 14/09/2017.
 */
public interface ItusInstrumentService<Input extends ItusInstrumentInput, Output extends ItusInstrumentData> {

    Set<Output> getInstrumentData(Input instrumentInput, String requestId, Boolean isDelta) throws ItusException;
}
