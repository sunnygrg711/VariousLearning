package com.rbs.ignite.business.itus.transformer.totv.converter;


import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.SourceSystemToOdcSystemInstaceIdMapper;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.odc.access.domain.InstrumentId;
import com.rbs.odc.access.domain.InstrumentUnderlier;
import com.rbs.odc.access.domain.SecurityInstrumentIdentifierClassificationScheme;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import com.rbs.odc.access.domain.Underlier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

import java.util.Collection;

/**
 * Created by puronaa on 19/09/2017.
 */
public class TransactionToTotvTradeConverter implements Converter<Transaction, TotvTrade> {
    private static Logger logger = LoggerFactory.getLogger(TransactionToTotvTradeConverter.class);

    @Override
    public TotvTrade convert(Transaction transaction) {
        String isin = null;
        Collection<TransactionLeg> txnLegSet = transaction.getTransactionLegs();
        for(TransactionLeg txnLeg: txnLegSet){
            Collection<Underlier> underlierSet = txnLeg.getUnderliers();
            if(underlierSet == null){
                continue;
            }
            for(Underlier underlier: underlierSet){
                if(underlier == null){
                    continue;
                }
                InstrumentUnderlier instrumentUnderLier = underlier.getInstrumentUnderlier();
                if(instrumentUnderLier == null){
                    continue;
                }
                InstrumentId instrumentId = instrumentUnderLier.getInstrumentId();
                if(instrumentId == null){
                    continue;
                }
                if(instrumentId.getInstrumentScheme().equals(SecurityInstrumentIdentifierClassificationScheme.ISIN)){
                    isin = underlier.getInstrumentUnderlier().getInstrumentId().getInstrumentId();
                    break;
                }
            }
        }
        String tradeId = transaction.getId().getSourceSystemTransactionId();
        SystemInstanceId actualSourceSystem = transaction.getId().getSourceSystemId();
        String version = transaction.getVersion();
        String location = transaction.getLocation().javaName();
        ItusTradeSourceSystem itusTradeSourceSystem;

        if (SourceSystemToOdcSystemInstaceIdMapper.DAVE.getSystemInstanceIds().contains(actualSourceSystem)) {
          itusTradeSourceSystem = ItusTradeSourceSystem.DAVE;
        } else if (SourceSystemToOdcSystemInstaceIdMapper.GFX.getSystemInstanceIds().contains(actualSourceSystem)) {
          itusTradeSourceSystem = ItusTradeSourceSystem.GFX;
        } else if (SourceSystemToOdcSystemInstaceIdMapper.SYSTEMX.getSystemInstanceIds().contains(actualSourceSystem)) {
          itusTradeSourceSystem = ItusTradeSourceSystem.SYSTEMX;
        } else if (SourceSystemToOdcSystemInstaceIdMapper.ICE.getSystemInstanceIds().contains(actualSourceSystem)) {
          itusTradeSourceSystem = ItusTradeSourceSystem.ICE;
        } else if (SourceSystemToOdcSystemInstaceIdMapper.IGNITE.getSystemInstanceIds().contains(actualSourceSystem)) {
          itusTradeSourceSystem = ItusTradeSourceSystem.IGNITE;
        } else {
          throw new RuntimeException(actualSourceSystem + " is not supported.");
        }

        return new TotvTrade(isin,tradeId, itusTradeSourceSystem, version,actualSourceSystem.name(),location);
    }
}
