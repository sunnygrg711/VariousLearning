package org.sk.tutorial.jfamily.concurrency.locks;

/**
 * Created by kshekar on 22/03/2018.
 */
public interface BalanceViewable {

    /**
     Gets the sum of all account balances.
     @return the total balance
     */
     double getTotalBalance();
}
