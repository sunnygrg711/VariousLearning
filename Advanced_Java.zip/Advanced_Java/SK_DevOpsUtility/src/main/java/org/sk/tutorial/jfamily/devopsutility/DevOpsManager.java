package org.sk.tutorial.jfamily.devopsutility;

import com.codahale.metrics.Counter;
import com.codahale.metrics.Gauge;
import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.google.gson.Gson;
import org.apache.commons.lang3.tuple.Pair;
import org.sk.tutorial.jfamily.devopsutility.matrics.DevOpsLogger;
import org.sk.tutorial.jfamily.devopsutility.matrics.DevOpsScheduledReporter;
import org.sk.tutorial.jfamily.devopsutility.matrics.HealthCheckGauge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * It orchestrates things around operational architecture that includes initialisation of localMetrics manager and core beans.
 * Created by sharmra on 28/03/2017.
 */
public class DevOpsManager {
    protected static final Logger LOGGER = LoggerFactory.getLogger(DevOpsManager.class);
    private static final Integer MAX_DEV_OPS_DATA_COUNT = 100;
    private static final String DEV_OPS_LOGGING_FREQUENCY = "DevOps.Logging.Frequency";

    private static final DevOpsManager DEV_OPS_MANAGER = new DevOpsManager();

    private MetricRegistry metrics = new MetricRegistry();

    private String processId;
    private boolean devOpsEnabled = true;
    private boolean initialised = false;

    private DevOpsScheduledReporter scheduledReporter;

    private DevOpsLogger devOpsLogger = DevOpsLogger.get();

    private DevOpsManager() {
    }

    public boolean isDevOpsEnabled() {
        return devOpsEnabled;
    }

    /**
     * Returns the singleton instance of the manager
     *
     * @return
     */
    public static DevOpsManager get() {
        return DEV_OPS_MANAGER;
    }

    /**
     * Initialises the health check gauge , scheduled reporter if not already
     */
    public synchronized void initialise() {
        determineIfDevOpsEnabled();
        if (devOpsEnabled && !initialised) {
            processId = System.getProperty("PlatformName");
            devOpsLogger.initialise(processId);

            HealthCheckGauge memoryHealthCheck = new HealthCheckGauge();
            memoryHealthCheck.init();
            register("GC", memoryHealthCheck);

            scheduledReporter = new DevOpsScheduledReporter(metrics, "", MetricFilter.ALL, TimeUnit.SECONDS, TimeUnit.MILLISECONDS,MAX_DEV_OPS_DATA_COUNT);
            scheduledReporter.start(Long.parseLong(System.getProperty(DEV_OPS_LOGGING_FREQUENCY, "5")), TimeUnit.SECONDS);
            initialised = true;
            LOGGER.info("DevOps manager initialised successfully");
        } else {
            LOGGER.info("DevOps manager already initialised so ignoring the call");
        }
    }

    /**
     * Checks whether devs ops is enabled
     */
    public void determineIfDevOpsEnabled() {
        devOpsEnabled = System.getProperty("devOpsDisabled") == null;
    }

    /**
     * Registers custom gauge.
     *
     * @param name
     * @param gauge
     * @param <T>
     */
    public <T> void register(String name, Gauge<T> gauge) {
        metrics.remove(name);
        metrics.register(name, gauge);
    }

    public String getAllDevOpsData(){
        Map<String ,List<String>> mapData= new HashMap<>();
        /*StringJoiner stringJoiner=new StringJoiner(",");
        scheduledReporter.getAllDevOpsData().forEach(s -> stringJoiner.add(s));
        mapData.put(processId,"["+stringJoiner.toString()+"]");*/

        mapData.put("GCDetails",Collections.synchronizedList(scheduledReporter.getAllDevOpsData()));
        return new Gson().toJson(mapData);
    }
    public void register(Consumer<Pair[]> consumer) {
        scheduledReporter.register(consumer);
    }

    public Counter counter(String name){
        return metrics.counter(name);
    }
}
