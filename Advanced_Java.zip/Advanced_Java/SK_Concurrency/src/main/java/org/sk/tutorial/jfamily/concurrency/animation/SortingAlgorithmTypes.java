package org.sk.tutorial.jfamily.concurrency.animation;

/**
 * Created by kshekar on 23/03/2018.
 */
public enum SortingAlgorithmTypes {
    JAVA_DEFAULT_API(0),
    BUBBLE(1),
    SELECTION(2),
    QUICK(3),
    HEAP(4);
    private int id;
    private SortingAlgorithmTypes(int id) {
        this.id=id;
    }
}
