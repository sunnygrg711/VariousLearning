package com.rbs.ignite.domain.itus.trade.enums;

/**
 * Created by puronaa on 26/09/2017.
 */
public enum ItusStatus {
    ACCEPTED("ACCEPTED"), REJECTED("REJECTED");

    ItusStatus(String status) {
        this.status = status;
    }

    private String status;

    public String getStatus() {
        return status;
    }


}
