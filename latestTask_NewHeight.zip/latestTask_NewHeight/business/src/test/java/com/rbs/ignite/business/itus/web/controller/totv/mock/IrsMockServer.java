package com.rbs.ignite.business.itus.web.controller.totv.mock;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.rbs.ignite.domain.itus.irs.TotvIrsRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.TestComponent;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.time.format.DateTimeFormatter;
import java.util.Set;

public class IrsMockServer {

  private int mockServerPort;

  private WireMockServer server;

  protected @Value("${irs.service.url}")
  String irsServiceUrl;

  public IrsMockServer(String irsServiceUrl) {
    this.mockServerPort = MockServerUtil.getPortNumber(irsServiceUrl);
    server = new WireMockServer(mockServerPort);
  }

  public WireMockServer ensureIrsServerIsDown() {
    server.stop();
    MockServerUtil.waitTillServerStops(server, mockServerPort);
    return server;
  }

  public WireMockServer ensureIrsServerReturnsValidIsins(TotvIrsRequest request, String response) {

    if (server.isRunning()) {
      server.resetAll();
    } else {
      server.start();
      MockServerUtil.waitTillServerStarts(server, mockServerPort);
    }



    try {
      server.stubFor(
              WireMock.get(WireMock.urlEqualTo("/irs/v1/totv/isins/feedType/"+request.getFeedType().getType()+"/feedDate/"+request.getFeedDate().format(DateTimeFormatter.ofPattern("yyyyMMdd"))))
                      .willReturn(
                              WireMock.aResponse()
                                      .withStatus(HttpStatus.OK.value())
                                      .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                      .withBody(response)
                      )
      );
      return server;
    } catch (Exception e) {
      throw new RuntimeException(e);
    }

  }
  }
