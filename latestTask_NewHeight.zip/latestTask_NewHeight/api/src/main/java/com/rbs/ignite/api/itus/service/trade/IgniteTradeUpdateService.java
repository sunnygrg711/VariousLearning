package com.rbs.ignite.api.itus.service.trade;

import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentData;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;
import com.rbs.ignite.domain.itus.request.totv.TotvTradeAmendRequest;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import java.time.LocalDate;
import java.util.Set;

public interface IgniteTradeUpdateService<Status extends ItusTradeStatus,Data extends ItusInstrumentData, Trade extends ItusTrade> {

  Set<Status> updateTrades(TotvTradeAmendRequest request) throws ItusException;

  Set<Data> getInstrumentData(ItusInstrumentInput instrumentInput, String requestId, Boolean isDelta) throws ItusException;

  Set<Trade> retrieveTrades(Set<String> dataSet, LocalDate date, Set<ItusTradeSourceSystem> sourceSystems, String requestId) throws ItusException;

}