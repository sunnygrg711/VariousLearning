package com.rbs.ignite.business.itus.configurer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import static com.google.common.base.Predicates.and;
import static springfox.documentation.builders.RequestHandlerSelectors.basePackage;
import static springfox.documentation.builders.RequestHandlerSelectors.withClassAnnotation;

@Configuration
@EnableSwagger2
public class IgniteTradeUpdateServiceSwaggerConfigurer {

  @Value("${info.app.name}")
  private String appName;
  @Value("${info.app.description}")
  private String appDescription;
  @Value("${info.build.version}")
  private String appVersion;
  @Value("${swagger.documentation.base.package}")
  private String swaggerBasePackage;

  @Bean
  public Docket docket() {
    return new Docket(DocumentationType.SWAGGER_2)
        .apiInfo(apiInfo())
        .select()
        .apis(
            and(withClassAnnotation(org.springframework.web.bind.annotation.RestController.class), basePackage(swaggerBasePackage)))
        .paths(PathSelectors.any()).build();
  }

  public ApiInfo apiInfo() {
    return new ApiInfoBuilder().title(appName).description(appDescription).version(appVersion).build();
  }
}