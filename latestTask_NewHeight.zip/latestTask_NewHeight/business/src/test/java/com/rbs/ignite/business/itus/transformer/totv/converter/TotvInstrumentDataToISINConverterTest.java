package com.rbs.ignite.business.itus.transformer.totv.converter;

import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by kumaunn on 09/02/2018.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class TotvInstrumentDataToISINConverterTest {

  TotvInstrumentDataToISINConverter testObj = new TotvInstrumentDataToISINConverter();

  @Mock
  TotvInstrumentData instrumentData;

  @Test
  public void testConvert() {

    Mockito.when(instrumentData.getIsin()).thenReturn(null);
    String output = testObj.convert(instrumentData);
    assertTrue(output == null);
    Mockito.when(instrumentData.getIsin()).thenReturn("12345");
    output = testObj.convert(instrumentData);
    assertEquals("12345",output);
  }
}
