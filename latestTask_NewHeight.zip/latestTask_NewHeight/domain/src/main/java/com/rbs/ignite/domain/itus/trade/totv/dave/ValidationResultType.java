package com.rbs.ignite.domain.itus.trade.totv.dave;

public enum ValidationResultType {

  Information, Warning, Fatal;

  @Override
  public String toString() {
    return "ValidationResultType{}";
  }

}
