package com.rbs.ignite.business.itus.web.controller.totv;

import com.rbs.ignite.api.itus.service.trade.IgniteTradeUpdateService;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.web.controller.totv.util.TotvControllerUtil;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.*;
import com.rbs.ignite.domain.itus.request.totv.TotvTradeAmendRequest;
import com.rbs.ignite.domain.itus.instrument.totv.TotvTradeRetrievalResponse;
import com.rbs.ignite.domain.itus.request.totv.TotvTradeRetrievalRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Set;

/**
 * Created by puronaa on 14/09/2017.
 */
@RestController
public class TotvController implements ItusClientController {

  private static final Logger logger = LoggerFactory.getLogger(TotvController.class);
  public static final String ROOT_PATH = "/totv";
  @Autowired
  private IgniteTradeUpdateService igniteTradeUpdateService;
  @Autowired
  private ItusInstrumentInput instrumentInput;
  @Autowired
  private ItusTransformer totvInstrumentDataToISINTransformer;


  @RequestMapping(value = ROOT_PATH + "/updateTradesForDate", method = RequestMethod.POST)
  public ResponseEntity<TotvResponse> updateTradesForDate(@RequestParam(value="requestId", required=false) String requestId,@RequestParam(value="isDelta", required=true) Boolean isDelta,@RequestParam(value = "byPassThreshold", defaultValue ="false") Boolean byPassThreshold,
                                                         @Valid @RequestBody TotvInstrumentDateInput date) throws ItusException {
    logger.info("Request[{}] received to run ToTv service for input: {}",requestId, date);
    TotvTradeAmendRequest request = TotvControllerUtil.getTotvRequest(requestId,isDelta,date,null,null,byPassThreshold);
    Set<TotvTradeStatus> tradeStatusSet= igniteTradeUpdateService.updateTrades(request);
    TotvResponse response = TotvControllerUtil.createTotvResponse(tradeStatusSet);
    logger.info("Request[{}] completed. Total trades processed: {}", requestId, response.getResult());

    return ResponseEntity.status(HttpStatus.OK).body(response);
  }

  @RequestMapping(value = ROOT_PATH + "/updateTradesSet", method = RequestMethod.POST)
  public ResponseEntity<TotvResponse> updateTotvTradeSet(@RequestParam(value="requestId", required=false) String requestId,@RequestParam(value = "byPassThreshold", defaultValue ="false") Boolean byPassThreshold,
                                                         @Valid @RequestBody Set<TotvTradesInput> tradesSetInput) throws ItusException {
    logger.info("Request[{}] received to run ToTv service for input: {}",requestId, tradesSetInput);
    TotvTradeAmendRequest request = TotvControllerUtil.getTotvRequest(requestId, tradesSetInput,byPassThreshold);
    Set<TotvTradeStatus> tradeStatusSet = igniteTradeUpdateService.updateTrades(request);
    TotvResponse response = TotvControllerUtil.createTotvResponse(tradeStatusSet);
    logger.info("Request[{}] completed. Total trades processed: {}", requestId, response.getResult());

    return ResponseEntity.status(HttpStatus.OK).body(response);
  }

  @RequestMapping(value = ROOT_PATH + "/updateTradesForDateNIsins", method = RequestMethod.POST)
  public ResponseEntity<TotvResponse> updateTradesForDateNIsins(@RequestParam(value="requestId", required=false) String requestId,@RequestParam(value = "byPassThreshold", defaultValue ="false") Boolean byPassThreshold,
                                                                   @Valid @RequestBody TotvInputForDateWithIsins instrumentInputWithDate) throws ItusException {
    logger.info("Request[{}] received to run ToTv service for input: {}",requestId, instrumentInputWithDate);
    TotvTradeAmendRequest request = TotvControllerUtil.getTotvRequest(requestId,null , new TotvInstrumentDateInput(instrumentInputWithDate.getDate()), instrumentInputWithDate.getIsinSet(), null, byPassThreshold);
    Set<TotvTradeStatus> tradeStatusSet= igniteTradeUpdateService.updateTrades(request);
    TotvResponse response = TotvControllerUtil.createTotvResponse(tradeStatusSet);
    logger.info("Request[{}] completed. Total trades processed: {}", requestId, response.getResult());

    return ResponseEntity.status(HttpStatus.OK).body(response);
  }

  @RequestMapping(value = ROOT_PATH + "/updateTradesForDateNSourceSystems", method = RequestMethod.POST)
  public ResponseEntity<TotvResponse> updateTradesForDateNSourceSystems(@RequestParam(value="requestId", required=false) String requestId,@RequestParam(value="isDelta", required=true) boolean isDelta,@RequestParam(value = "byPassThreshold", defaultValue ="false") Boolean byPassThreshold,
                                                                         @Valid @RequestBody TotvTradeSystemsInput tradeSystemsInput) throws ItusException {
    logger.info("Request[{}] received to run ToTv service for input: {}",requestId, tradeSystemsInput);
    TotvTradeAmendRequest request = TotvControllerUtil.getTotvRequest(requestId, isDelta, tradeSystemsInput.getDateInput(), null, tradeSystemsInput.getSourceSystems(), byPassThreshold);
    Set<TotvTradeStatus> tradeStatusSet= igniteTradeUpdateService.updateTrades(request);
    TotvResponse response = TotvControllerUtil.createTotvResponse(tradeStatusSet);
    logger.info("Request[{}] completed. Total trades processed: {}", requestId, response.getResult());

    return ResponseEntity.status(HttpStatus.OK).body(response);
  }

  @RequestMapping(value = ROOT_PATH + "/updateTradesForDateNSourceSystemsNIsins", method = RequestMethod.POST)
  public ResponseEntity<TotvResponse> updateTradesForDateNSourceSystemsNIsins(@RequestParam(value="requestId", required=false) String requestId,@RequestParam(value = "byPassThreshold", defaultValue ="false") Boolean byPassThreshold,
                                                                                  @Valid @RequestBody TotvTradeSourceSystemDateIsinInput tradeSystemsInputForIsins) throws ItusException {
    logger.info("Request[{}] received to run ToTv service for input: {}",requestId, tradeSystemsInputForIsins);
    TotvTradeAmendRequest request = TotvControllerUtil.getTotvRequest(requestId,null ,
            tradeSystemsInputForIsins.getDateInput(), tradeSystemsInputForIsins.getIsinSet(), tradeSystemsInputForIsins.getSourceSystems(), byPassThreshold);
    Set<TotvTradeStatus> tradeStatusSet= igniteTradeUpdateService.updateTrades(request);
    TotvResponse response = TotvControllerUtil.createTotvResponse(tradeStatusSet);
    logger.info("Request[{}] completed. Total trades processed: {}", requestId, response.getResult());

    return ResponseEntity.status(HttpStatus.OK).body(response);
  }

  @RequestMapping (value = ROOT_PATH + "/getTradesForDate", method = RequestMethod.GET)
  public ResponseEntity<TotvTradeRetrievalResponse> getTradesForDate(@RequestParam(value = "requestId", required = false) String requestId, @RequestParam(value="isDelta", required=true) boolean isDelta,
                                                                         @RequestParam (value = "date" , required = true) String date)throws ItusException{

      logger.info("Request[{}] received to run ToTv service to get trades for input: {}", requestId, date);
      TotvTradeRetrievalRequest tradeRetrivalRequest = TotvControllerUtil.getTotvTradeRetrivalRequest(requestId,isDelta, date, null, null);
      Set<TotvInstrumentData> isinList = igniteTradeUpdateService.getInstrumentData(new TotvInstrumentDateInput(tradeRetrivalRequest.getDate()), requestId,isDelta);
      Set<String> list = (Set<String>) totvInstrumentDataToISINTransformer.transform(isinList);
      Set<TotvTrade> trades = igniteTradeUpdateService.retrieveTrades(list,tradeRetrivalRequest.getDate(),tradeRetrivalRequest.getSourceSystems(),tradeRetrivalRequest.getRequestId());
      TotvTradeRetrievalResponse totvTradeRetrievalResponse = TotvControllerUtil.createTotvTradeRetrivalResponse(trades);
      logger.info("Request[{}] completed. Total trades received: {}", requestId, totvTradeRetrievalResponse.getResult());
      return ResponseEntity.status(HttpStatus.OK).body(totvTradeRetrievalResponse);
  }

  @RequestMapping (value = ROOT_PATH + "/getTradesForDateNIsins", method = RequestMethod.POST)
  public ResponseEntity<TotvTradeRetrievalResponse> getTradesForDateNIsins(@RequestParam(value = "requestId", required = false) String requestId,
                                                                                 @RequestParam (value = "date" , required = true) String date,
                                                                                 @RequestBody Set<String> isins)throws ItusException{

    logger.info("Request[{}] received to run ToTv service to get trades for input: {}", requestId, date ,isins);
    TotvTradeRetrievalRequest tradeRetrivalRequest = TotvControllerUtil.getTotvTradeRetrivalRequest(requestId,null, date, isins, null);
    Set<TotvTrade> trades = igniteTradeUpdateService.retrieveTrades(isins,tradeRetrivalRequest.getDate(),tradeRetrivalRequest.getSourceSystems(),tradeRetrivalRequest.getRequestId());
    TotvTradeRetrievalResponse totvTradeRetrievalResponse = TotvControllerUtil.createTotvTradeRetrivalResponse(trades);
    System.out.println(totvTradeRetrievalResponse.getResult());
    logger.info("Request[{}] completed. Total trades received: {}", requestId, totvTradeRetrievalResponse.getResult());
    return ResponseEntity.status(HttpStatus.OK).body(totvTradeRetrievalResponse);
  }

  @RequestMapping (value = ROOT_PATH + "/getIsinsForDate", method = RequestMethod.GET)
  public ResponseEntity<TotvIsinRetrievalResponse> getIsinsForDate(@RequestParam(value = "requestId", required = false) String requestId, @RequestParam(value="isDelta", required=true) boolean isDelta,
                                                                      @RequestParam (value = "date" , required = true) String date) throws  ItusException{

    logger.info("Request[{}] received to run ToTv service to get isins for input: {}", requestId, date);
    TotvTradeRetrievalRequest tradeRetrivalRequest = TotvControllerUtil.getTotvTradeRetrivalRequest(requestId,isDelta, date, null, null);
    Set<TotvInstrumentData> isinList = igniteTradeUpdateService.getInstrumentData(new TotvInstrumentDateInput(tradeRetrivalRequest.getDate()), requestId,isDelta);
    Set<String> list = (Set<String>) totvInstrumentDataToISINTransformer.transform(isinList);
    TotvIsinRetrievalResponse totvIsinRetrievalResponse = TotvControllerUtil.createTotvISINRetrivalResponse(list);
    logger.info("Request[{}] completed. Total trades received: {}", requestId, totvIsinRetrievalResponse.getResult());
    return ResponseEntity.status(HttpStatus.OK).body(totvIsinRetrievalResponse);
  }
}
