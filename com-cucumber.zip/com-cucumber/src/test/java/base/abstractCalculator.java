package base;

import cucumber.api.Scenario;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import tests.domain.calculatorDomainResponse;

import java.io.File;

/**
 * Created by kumaunn on 22/11/2017.
 */
public abstract class abstractCalculator {
  protected Scenario scenario;

  public void init(Scenario scn) {
    this.scenario = scn;
    System.out.println(scenario.getName());
  }
  public calculatorDomainResponse addition(String no2, String no1) {
    String res = new String(Integer.parseInt(no1) + Integer.parseInt(no2)+"");
    calculatorDomainResponse response = new calculatorDomainResponse(res);
    return response;
  }
  public calculatorDomainResponse subtraction(String no1, String no2) {
    String res = new String(Integer.parseInt(no1) - Integer.parseInt(no2)+"");
    calculatorDomainResponse response = new calculatorDomainResponse(res);
    return response;
  }

  public calculatorDomainResponse fileAddition(String relativePath)  {

    try {
      String calcluatorInputXml = FileUtils.readFileToString(
              new File(abstractCalculator.class.getResource("/").getFile().concat(relativePath)));
      String res = Integer.parseInt(StringUtils.substringBetween(calcluatorInputXml,"<no1>" , "</no1>"))
              +Integer.parseInt(StringUtils.substringBetween(calcluatorInputXml,"<no2>" , "</no2>"))+"";
      calculatorDomainResponse response = new calculatorDomainResponse(res);
      return response;
    }catch (Exception e) {
      e.printStackTrace();
    }

    return  null;
  }

}
