package org.sk.tutorial.jfamily.devopsutility.matrics;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

public class DevOpsLogger {
    private static Logger LOGGER = LoggerFactory.getLogger(DevOpsLogger.class);
    private static final DevOpsLogger devOpsLogger = new DevOpsLogger();

    private String devOpsLogTemplateText;
    private boolean devOpsEnabled = false;
    private final ThreadLocal<MyLocalVariable> threadLocalVariables = new ThreadLocal<MyLocalVariable>() {

        @Override
        protected MyLocalVariable initialValue() {
            return new MyLocalVariable();
        }
    };

    private DevOpsLogger() {
    }

	/**
	 * Initialises the logger as per the processId
	 * @param processId
	 */
    public void initialise(String processId) {
        devOpsEnabled = true;
        devOpsLogTemplateText = " LI##~ProcessId=" + processId + "~";
    }

    /**
     * Returns the singleton instance of logger
     * @return
     */
    public static DevOpsLogger get() {
        return devOpsLogger;
    }

	/**
	 * build the logging string
	 * 
	 * @param logBuilder
	 * @param key
	 * @param object
	 */
    public void add(StringBuilder logBuilder, String key, Object object) {
        logBuilder.append(key).append("=").append(object).append("~");
    }

	/**
	 * logs the builder 
	 * @param logBuilder
	 */
    public void log(StringBuilder logBuilder) {
        if (logBuilder.length() != 0) {
            logStatement(logBuilder.substring(0, logBuilder.length() - 1));
        }
    }

	private void logStatement(String logStatement) {
        if (devOpsEnabled) {
            LOGGER.info(devOpsLogTemplateText + logStatement);
        }
    }

    /**
     * It logs key/value pair in a LI (log Intelligence Compliant format). Also it record event time to establish lineage and help in execution path timings.
     *
     * @param pairs key value pair for set for DevOps
     */
    public void logForDevOpsWithEL(Pair<String, ?>... pairs) {
        threadLocalVariables.get().receivedTimestampEvent();
        logForDevOps(pairs);
    }

    /**
     * Calculate lapsed time from last lineage event and coverts into required Time Unit.
     *
     * @param timeUnit The time unit
     * @return The lapsed time from last lineage event.
     */
    public long getLapsedTimeFromLastEvent(TimeUnit timeUnit) {
        return timeUnit.convert(System.currentTimeMillis() - threadLocalVariables.get().getLineageEventLatestTime(), TimeUnit.MILLISECONDS);
    }

    /**
     * It logs key/value pair in a LI (log Intelligence Compliant format)
     *
     * @param pairs key value pair for set for DevOps
     */
    public void logForDevOps(Pair<String, ?>... pairs) {
        StringBuilder logBuilder = new StringBuilder();
        for (Pair<String, ?> pair : pairs) {
            add(logBuilder, pair.getKey(), pair.getValue());
        }
        log(logBuilder);
    }

    /**
     * It logs status of event with reason
     * @param eventID ID of event
     * @param status current status
     * @param comment comment on current status
     */
    public void logStatusForDevOps(String eventID, String status, String comment) {
        StringBuilder logBuilder = new StringBuilder();
        logBuilder.append("EventId:\t").append(eventID)
                .append("\t having status as \t").append(status);
        if (comment != null){
            logBuilder.append("\t with comment as ").append(comment);
        }
        log(logBuilder);
    }

    /**
     * It logs status of event
     *
     * @param eventID ID of event
     * @param status current status
     */
    public void logStatusForDevOps(String eventID, String status) {
        logStatusForDevOps(eventID, status, null);
    }

    /**
     * It holds thread local variables to help with path execution matrics.
     */
    static class MyLocalVariable {
        private long lineageEventLatestTime;

        long getLineageEventLatestTime() {
            return lineageEventLatestTime;
        }

        void receivedTimestampEvent() {
            lineageEventLatestTime = System.currentTimeMillis();
        }
    }
}
