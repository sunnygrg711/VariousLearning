package org.sk.tutorial.jfamily.concurrency.animation;

/**
 * Created by kshekar on 26/03/2018.
 */
public class HeapSort extends SorterRunnable {

    public HeapSort(Double[] sortableValues, ArrayPanel arrayPanelToDisplayValues) {
        super(sortableValues, arrayPanelToDisplayValues);
    }

    @Override
    void sort() {
        arrayPanelToDisplayValues.setValues(sortableValues, null, null);
        for(int i=sortableValues.length/2-1;i>=0;i--){
            heapify(sortableValues.length,i);
        }
        for(int i=sortableValues.length -1;i>=0;i--){
            double swap = sortableValues[0];
            sortableValues[0] = sortableValues[i];
            sortableValues[i] = swap;
            heapify(i,0);
        }

    }

    private void heapify(int maxHeapSize, int currentIndex) {
        int largestValue=currentIndex;
        int leftIndex=currentIndex*2+1;
        int rightIndex=currentIndex*2+2;
        arrayPanelToDisplayValues.setValues(sortableValues, sortableValues[maxHeapSize==sortableValues.length?maxHeapSize-1:maxHeapSize], sortableValues[currentIndex]);
        try
        {
            if (run)
                Thread.sleep(DELAY_IN_MILLISECOND);
            else
                semaphorePermits.acquire();
        }
        catch (InterruptedException exception)
        {
            Thread.currentThread().interrupt();
        }
        if(leftIndex<maxHeapSize && Double.compare(sortableValues[leftIndex],sortableValues[largestValue])>0){
            largestValue=leftIndex;

        }

        if(rightIndex<maxHeapSize&& Double.compare(sortableValues[rightIndex],sortableValues[largestValue])>0){
            largestValue=rightIndex;
        }

        if(largestValue!=currentIndex){
            double swap = sortableValues[currentIndex];
            sortableValues[currentIndex] = sortableValues[largestValue];
            sortableValues[largestValue] = swap;
            heapify( maxHeapSize, largestValue);
        }
    }
}
