package org.sk.tutorial.jfamily.concurrency.examples.session1_2;


import org.sk.tutorial.jfamily.concurrency.annotation.ThreadSafe;

@ThreadSafe
public class StatelessExample {
    public void service(int data, Object object) {
        validate(data, object);
        doAction(data);
        endProcess(object);

    }

    private void endProcess(Object object) {
    }

    private void doAction(int data) {

    }

    private void validate(int data, Object object) {

    }
}
