package com.rbs.ignite.domain.itus.instrument.totv;


import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;

/**
 * Created by puronaa on 14/09/2017.
 */
public class TotvFileBasedInstrumentInput implements ItusInstrumentInput {

    private String fileName;

    public TotvFileBasedInstrumentInput(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TotvFileBasedInstrumentInput)) return false;

        TotvFileBasedInstrumentInput that = (TotvFileBasedInstrumentInput) o;

        return fileName.equals(that.fileName);
    }

    @Override
    public int hashCode() {
        return fileName.hashCode();
    }

    @Override
    public String toString() {
        return "TotvFileBasedInstrumentInput{" +
                "fileName='" + fileName + '\'' +
                '}';
    }
}
