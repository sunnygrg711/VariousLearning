package com.rbs.ignite.domain.itus.trade.totv.dave;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "ResponseDto"
})
public class TotvDaveResponse {

  @JsonProperty("ResponseDto")
  private ResponseDto responseDto;

  public ResponseDto getResponseDto() {
    return responseDto;
  }
  public void setResponseDto(ResponseDto responseDto) {
    this.responseDto = responseDto;
  }
  @Override
  public String toString() {
    return "TotvDaveResponse{" +
            "responseDto=" + responseDto +
            '}';
  }
}