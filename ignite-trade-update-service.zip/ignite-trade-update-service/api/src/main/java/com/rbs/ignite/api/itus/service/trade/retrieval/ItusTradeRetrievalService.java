package com.rbs.ignite.api.itus.service.trade.retrieval;



import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentData;
import com.rbs.ignite.domain.itus.trade.ItusTrade;

import java.time.LocalDate;
import java.util.Set;

/**
 * Created by puronaa on 24/08/2017.
 */
public interface ItusTradeRetrievalService<Input extends ItusInstrumentData, Output extends ItusTrade> {
    Set<Output> retrieveTrades(Set<Input> financialInstrumentDataSet,LocalDate date) throws ItusException;
}
