package org.sk.tutorial.jfamily.devopsutility.matrics;

import com.codahale.metrics.*;
import com.codahale.metrics.Timer;
import com.google.gson.Gson;
import org.apache.commons.lang3.tuple.Pair;
import org.sk.tutorial.jfamily.devopsutility.CommonUtil;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Consumer;


public class DevOpsScheduledReporter extends ScheduledReporter {
    private List<Consumer<Pair[]>> subscribers = new ArrayList<>();
    private LinkedList<String> allDevOpsData = new LinkedList();

    private final Lock allDevOpsDataLock;

    private static Integer MAX_DEV_OPS_DATA_COUNT;
    private String CREATION_TIME="CreationTime";
    /**
     * Create the schedules reporter instance as per the custom parameters
     *
     * @param registry
     * @param name
     * @param filter
     * @param rateUnit
     * @param durationUnit
     */
    public DevOpsScheduledReporter(MetricRegistry registry, String name, MetricFilter filter, TimeUnit rateUnit, TimeUnit durationUnit,Integer maxDevOpsCount) {
        super(registry, name, filter, rateUnit, durationUnit);
        MAX_DEV_OPS_DATA_COUNT=maxDevOpsCount;
        subscribers.add(pairs -> DevOpsLogger.get().logForDevOps(pairs));
        allDevOpsDataLock=new ReentrantLock();
    }


    public void register(Consumer<Pair[]> consumer) {
        subscribers.add(consumer);
    }

    /**
     * Generates the report
     */
    @Override
    public void report(SortedMap<String, Gauge> gaugesMap, SortedMap<String, Counter> counterMap, SortedMap<String, Histogram> sortedMap2, SortedMap<String, Meter> sortedMap3, SortedMap<String, Timer> sortedMap4) {
        List<Pair<String, ?>> pairArrayList = new ArrayList<>();
        populatePairArrayListForGauges(gaugesMap, pairArrayList);
        populatePairArrayListForCounters(counterMap, pairArrayList);
        if (!pairArrayList.isEmpty()) {
            notifyConsumers(pairArrayList.toArray(new Pair[0]));
        }
    }

    private void populatePairArrayListForGauges(SortedMap<String, Gauge> gaugesMap, List<Pair<String, ?>> pairArrayList){
        for (Map.Entry<String, Gauge> ele : gaugesMap.entrySet()) {
            Object value = ele.getValue().getValue();
            if (value instanceof Pair[]) {
                notifyConsumers((Pair[]) value);
            } else {
                pairArrayList.add(Pair.of(ele.getKey(), value));
            }
        }
    }

    private void populatePairArrayListForCounters(SortedMap<String, Counter> counterMap, List<Pair<String, ?>> pairArrayList) {
        for (Map.Entry<String, Counter> ele : counterMap.entrySet()) {
            Object value = ele.getValue().getCount();
            pairArrayList.add(Pair.of(ele.getKey(), String.valueOf(value)));
        }
    }

    private void notifyConsumers(Pair<String, ?>[] data) {
        Map<String,String> hashMap=new LinkedHashMap<>();
        hashMap.put(CREATION_TIME, CommonUtil.getDateInDefaultFormat());
        for(Pair pair :data){
            hashMap.put(pair.getKey().toString(),pair.getValue().toString());
        }

        addDataToDevOps(new Gson().toJson(hashMap));
        subscribers.forEach(consumer -> consumer.accept(data));
    }

    private void addDataToDevOps(String data) {
        allDevOpsDataLock.lock();
        try {
            allDevOpsData.addFirst(data);
            if (allDevOpsData.size() >= MAX_DEV_OPS_DATA_COUNT) {
                allDevOpsData.removeLast();
            }
        }
         finally {
            allDevOpsDataLock.unlock();
            }

    }

    public List<String> getAllDevOpsData() {
        allDevOpsDataLock.lock();
        try {
            return new ArrayList<>(allDevOpsData);
        }
        finally {
            allDevOpsDataLock.unlock();
        }

    }
}
