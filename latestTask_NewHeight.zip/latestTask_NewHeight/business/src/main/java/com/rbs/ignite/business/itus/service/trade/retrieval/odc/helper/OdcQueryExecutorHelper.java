package com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper;

import com.rbs.ignite.business.itus.util.WeekendTemporalAdjuster;
import com.rbs.ignite.domain.itus.enums.QueryParamName;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionState;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentMap;

/**
 * Created by upadkti on 07/11/2017.
 */
public class OdcQueryExecutorHelper {

  private static final Logger logger = LoggerFactory.getLogger(OdcQueryExecutorHelper.class);

  public static OdcQueryInputData convertParameterMapToInputData(ConcurrentMap<QueryParamName, Object> parameterMap) {
    OdcQueryInputData inputObj = new OdcQueryInputData();
    parameterMap.forEach((QueryParamName key, Object value) -> {
      try {
        switch (key) {
          case ISINSET:
            if (value instanceof Collection) {
              inputObj.setiSin((Set<String>) value);
            }
            break;
          case ELIGIBLE:
            inputObj.setEligible((value != null) ? (boolean) value : false);
            break;
          case SOURCE_SYSTEM:
            if (value instanceof Collection) {
              inputObj.setSourceSystems((Set<ItusTradeSourceSystem>) value);
            }
            break;
          case TRANSACTION_STATE:
            if (value instanceof String) {
              inputObj.setTransactionState(TransactionState.valueOf((String) value));
            } else if (value instanceof Integer) {
              inputObj.setTransactionState(TransactionState.valueOf((Integer) value));
            }
            break;
          case BUSINESS_DATE:
            if (value instanceof LocalDate) {
              LocalDate date = (LocalDate) value;
              inputObj.setBusinessDate(date);
            }
            break;
        }
      } catch (UnknownEnumerationValueException ex) {
        throw new ItusFatalErrorException("Unsupported Odc query parameter provided :" + key);
      }
    });
    return inputObj;
  }

  public static Set<ItusTradeSourceSystem> getSourceSystemsSetFromString(String sourceSystemStr) {
    Set<ItusTradeSourceSystem> systems = new HashSet<>();
    for (String system : sourceSystemStr.split(",")) {
      systems.add(ItusTradeSourceSystem.valueOf(system));
    }
    return systems;
  }

  public static Set<Transaction> getTransactionSetFromIteartor(Iterator<Transaction> transactionIterator) {
    Set<Transaction> result = new LinkedHashSet<>();
    if (transactionIterator == null) {
      return result;
    }

    while (transactionIterator.hasNext()) {
      Transaction transaction = transactionIterator.next();
      result.add(transaction);
    }
    return result;
  }

  /**
   * validation of input parameters
   *
   * @param value
   * @throws RuntimeException if input is null or blank
   */
  public static void validateInputParam(String name, Object value) {
    Objects.requireNonNull(value, "input parameter " + name + " should not be null");

    if (value instanceof Collection && ((Collection) value).size() <= 0) {
      throw new ItusFatalErrorException("input parameter " + name + " should not be empty");
    }
  }

  public static Set<SystemInstanceId> getSystemIdsForGivenSystems(String sourceSystem) {
    Set<SystemInstanceId> systemIds = new HashSet<>();
    for (String system : sourceSystem.split(",")) {
      systemIds.addAll(getSystemIdsForGivenSystem(system));
    }
    return systemIds;
  }

  public static Set<SystemInstanceId> getSystemIdsForGivenSystems(Set<ItusTradeSourceSystem> sourceSystems) {
    Set<SystemInstanceId> systemIds = new HashSet<>();
    sourceSystems.forEach((sourceSystem) -> {
      systemIds.addAll(getSystemIdsForGivenSystem(sourceSystem));
    });
    return systemIds;
  }

  public static Set<SystemInstanceId> getSystemIdsForGivenSystem(ItusTradeSourceSystem sourceSystem) {
    return SourceSystemToOdcSystemInstaceIdMapper.valueOf(sourceSystem.getName()).getSystemInstanceIds();
  }

  public static Set<SystemInstanceId> getSystemIdsForGivenSystem(String sourceSystem) {
    return SourceSystemToOdcSystemInstaceIdMapper.valueOf(sourceSystem).getSystemInstanceIds();
  }

  public static ZonedDateTime getZonedDateTime(LocalDate localDate, int fromDays, int startHourOfTheDay, String timeZone) {
    LocalDateTime localDateTime = localDate.atStartOfDay();
    LocalDateTime localDateWithWeekendConsideration = localDateTime.with(new WeekendTemporalAdjuster(fromDays,WeekendTemporalAdjuster.DateDirection.BACKWARD));
    localDateWithWeekendConsideration = localDateWithWeekendConsideration.plusHours(startHourOfTheDay);
    return localDateWithWeekendConsideration.atZone(ZoneId.of(timeZone));
  }

  public static String getYesterdaysDateInString() {
    LocalDate date = LocalDate.now().minusDays(1L);
    return String.valueOf(date);
  }

}
