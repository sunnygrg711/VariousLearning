package org.sk.tutorial.jfamily.concurrency.locks.unsynch;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Locking Tool for Bank
 * Created by kshekar on 22/03/2018.
 */
public class BankLockingImpl {
    private CountDownLatch latch;
    //private CyclicBarrier b=new CyclicBarrier(10000);

    public BankLockingImpl() {
        latch = new CountDownLatch(4);

    }

    public CountDownLatch getLatch() {
        return latch;
    }
}
