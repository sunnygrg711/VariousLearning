package org.sk.tutorial.jfamily.concurrency.animation;

import java.util.Arrays;
import java.util.Comparator;

/**
 * Created by kshekar on 23/03/2018.
 */
public class JavaApiSort extends SorterRunnable {

    public JavaApiSort(Double[] sortableValues, ArrayPanel arrayPanelToDisplayValues){
        super(sortableValues,arrayPanelToDisplayValues);
    }

    @Override
    void sort() {
        Comparator<Double> comp =  (i1, i2)->{
            arrayPanelToDisplayValues.setValues(sortableValues, i1, i2);
            try
            {
                if (run)
                    Thread.sleep(DELAY_IN_MILLISECOND);
                else
                    semaphorePermits.acquire();
            }
            catch (InterruptedException exception)
            {
                Thread.currentThread().interrupt();
            }
            return i1.compareTo(i2);
        } ;
        Arrays.sort(sortableValues, comp);
        arrayPanelToDisplayValues.setValues(sortableValues, null, null);
    }
}
