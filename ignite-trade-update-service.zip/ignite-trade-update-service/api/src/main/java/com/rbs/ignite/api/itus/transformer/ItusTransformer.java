package com.rbs.ignite.api.itus.transformer;


import com.rbs.ignite.domain.itus.exception.ItusTransformException;

public interface ItusTransformer<Source, Destination> {
    Destination transform(Source source) throws ItusTransformException;
}
