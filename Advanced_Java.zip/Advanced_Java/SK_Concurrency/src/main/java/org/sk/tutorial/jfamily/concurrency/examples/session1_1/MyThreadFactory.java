package org.sk.tutorial.jfamily.concurrency.examples.session1_1;

import java.util.concurrent.ThreadFactory;

/**
 * Created by kshekar on 07/05/2018.
 */
public class MyThreadFactory implements ThreadFactory {
    @Override
    public Thread newThread(Runnable r) {
        return new Thread(r);
    }

    public static void main(String[] args) {
        MyThreadFactory myThreadFactory=new MyThreadFactory();
        myThreadFactory.newThread(() -> System.out.println(Thread.currentThread())).start();
    }
}
