package com.rbs.ignite.business.itus.jmx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Component;

@Component
@ManagedResource(objectName = "TOTV:name=Configuration")
public class TotvJmxProvider {

  private static final Logger logger = LoggerFactory.getLogger(TotvJmxProvider.class);

  @Value("${totv.skip.trade.amend}")
  private boolean skipTradeAmend;

  @Value("${dave.trades.threshold.limit}")
  private long daveThresholdLimit;

  @Value("${gfx.trades.threshold.limit}")
  private long gfxThresholdLimit;

  @Value("${systemX.trades.threshold.limit}")
  private long systemXThresholdLimit;

  @Value("${ice.trades.threshold.limit}")
  private long iceThresholdLimit;

  @Value("${ignitebonds.trades.threshold.limit}")
  private long ignitebondsThresholdLimit;

  @Autowired
  public TotvJmxProvider() {
    logger.info("TotvJmxProvider is initialized");
  }

  @ManagedOperation(description = "To be used carefully, this will enable/disable TOTV service to communicate with other systems")
  public void enableReadOnlyMode(boolean enable) {
    logger.info("Read only mode is now {}", enable ? "ENABLED" : "DISABLED");
    skipTradeAmend = enable;
  }

  @ManagedOperation(description = "display existing skipTradeAmend value")
  public Boolean getReadOnlyMode() {
    return skipTradeAmend;
  }

  @ManagedOperation(description = "To be used to update the threshold limit for Dave trade source system")
  public void setDaveThresholdLimit(long daveThresholdLimit) {
    logger.info("Dave threshold limit is now {}", daveThresholdLimit);
    this.daveThresholdLimit = daveThresholdLimit;
  }
  @ManagedOperation(description = "display existing daveThresholdLimit value")
  public long getDaveThresholdLimit() {
    return daveThresholdLimit;
  }
  @ManagedOperation(description = "display existing gfxThresholdLimit value")
  public long getGfxThresholdLimit() {
    return gfxThresholdLimit;
  }

  @ManagedOperation(description = "To be used to update the threshold limit for Gfx trade source system")
  public void setGfxThresholdLimit(long gfxThresholdLimit) {
    logger.info("Gfx threshold limit is now {}", gfxThresholdLimit);
    this.gfxThresholdLimit = gfxThresholdLimit;
  }
  @ManagedOperation(description = "display existing systemXThresholdLimit value")
  public long getSystemXThresholdLimit() {
    return systemXThresholdLimit;
  }

  @ManagedOperation(description = "To be used to update the threshold limit for SystemX trade source system")
  public void setSystemXThresholdLimit(long systemXThresholdLimit) {
    logger.info("SystemX threshold limit is now {}", systemXThresholdLimit);
    this.systemXThresholdLimit = systemXThresholdLimit;
  }
  @ManagedOperation(description = "display existing iceThresholdLimit value")
  public long getIceThresholdLimit() {
    return iceThresholdLimit;
  }

  @ManagedOperation(description = "To be used to update the threshold limit for Ice trade source system")
  public void setIceThresholdLimit(long iceThresholdLimit) {
    logger.info("Ice threshold limit is now {}", iceThresholdLimit);
    this.iceThresholdLimit = iceThresholdLimit;
  }
  @ManagedOperation(description = "display existing ignitebondsThresholdLimit value")
  public long getIgnitebondsThresholdLimit() {
    return ignitebondsThresholdLimit;
  }

  @ManagedOperation(description = "To be used to update the threshold limit for IgniteBonds trade source system")
  public void setIgnitebondsThresholdLimit(long ignitebondsThresholdLimit) {
    logger.info("Dave threshold limit is now {}", ignitebondsThresholdLimit);
    this.ignitebondsThresholdLimit = ignitebondsThresholdLimit;
  }
}