package org.sk.tutorial.jfamily.concurrency.examples.session3_1;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

public class TaskWithStatus implements Callable<Boolean> {
    @Override
    public Boolean call() throws Exception {
        System.out.println(Thread.currentThread().getName() + ":: processing is started on " + new Date());
        long startTime = System.currentTimeMillis();
        TimeUnit.SECONDS.sleep(new Random().nextInt(5));
        System.out.println(Thread.currentThread().getName() + ":: processing is completed on " + new Date() + " . Processing time taken in second:" + (System.currentTimeMillis() - startTime) / 1000);
        return true;
    }
}
