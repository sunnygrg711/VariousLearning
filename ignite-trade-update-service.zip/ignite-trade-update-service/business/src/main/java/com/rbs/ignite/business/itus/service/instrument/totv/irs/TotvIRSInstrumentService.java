package com.rbs.ignite.business.itus.service.instrument.totv.irs;

import com.rbs.gbm.rates.core.auth.security.SsoTokenProviderService;
import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import com.rbs.ignite.api.itus.service.instrument.ItusInstrumentService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusWebServiceInterface;
import com.rbs.ignite.business.itus.util.WebServiceUtil;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentDateInput;
import com.rbs.ignite.domain.itus.irs.TotvIRSInstrumentIdentifier;
import com.rbs.ignite.domain.itus.irs.TotvIRSResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.client.RestTemplate;

import java.util.HashSet;
import java.util.Set;

public class TotvIRSInstrumentService implements ItusWebServiceInterface<TotvInstrumentDateInput,TotvIRSResponse> ,ItusInstrumentService<TotvInstrumentDateInput,TotvInstrumentData> {

  private static final Logger logger = LoggerFactory.getLogger(TotvIRSInstrumentService.class);
  private String tradeServiceUrl;
  private Class<TotvIRSResponse> responseClass;
  private TokenProviderService ssoTokenProviderService;
  @Autowired
  private RestTemplate restTemplate;

  public TotvIRSInstrumentService(String irsServiceUrl, Class<TotvIRSResponse> totvIrsResponseClass, SsoTokenProviderService ssoTokenProviderService) {
    this.responseClass= totvIrsResponseClass;
    this.tradeServiceUrl= irsServiceUrl;
    this.ssoTokenProviderService= ssoTokenProviderService;
  }

  @Override
  public String getTradeServiceUrl() {
    return tradeServiceUrl;
  }
  @Override
  public Class<TotvIRSResponse> getResponseClass() {
    return responseClass;
  }
  @Override
  public TotvIRSResponse getResponse(TotvInstrumentDateInput totvInstrumentDateInput) {

    HttpEntity<TotvInstrumentDateInput> httpEntity = new HttpEntity(totvInstrumentDateInput, WebServiceUtil.getHttpHeadersWithBasicAuth(ssoTokenProviderService));
    TotvIRSResponse postResponse = restTemplate.postForObject(tradeServiceUrl,httpEntity, TotvIRSResponse.class);
    return postResponse;
  }

  @Override
  public Set<TotvInstrumentData> getInstrumentData(TotvInstrumentDateInput instrumentInput) throws ItusException {
    TotvIRSResponse irsResponse = getResponse(instrumentInput);
    Set<TotvIRSInstrumentIdentifier> identifiers = (irsResponse.getIsins());
    logger.info("Total {} ISINs received",identifiers.size());
    Set<TotvInstrumentData> instrumentData = new HashSet<>();
    identifiers.forEach(identifier ->instrumentData.add(new TotvInstrumentData(identifier.getIdentifier())));
    return instrumentData;
  }
}

