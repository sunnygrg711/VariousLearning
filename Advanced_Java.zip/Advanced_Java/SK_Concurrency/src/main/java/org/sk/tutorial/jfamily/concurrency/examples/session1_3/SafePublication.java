package org.sk.tutorial.jfamily.concurrency.examples.session1_3;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by kshekar on 24/04/2018.
 */
public class SafePublication {

    private final IData iData;

    private Object mydata = "Secret";

    private SafePublication() {
        iData = new IData() {
            @Override
            public void doAction(Object data) {
                if (data instanceof ALoop) {
                    ((ALoop) data).setData(mydata);
                }
                System.out.println("Done!");
            }
        };
    }

    public static SafePublication newInstance(DataRegistry dataRegistry) {
        SafePublication safe = new SafePublication();
        dataRegistry.register(safe.iData);
        return safe;
    }


}



