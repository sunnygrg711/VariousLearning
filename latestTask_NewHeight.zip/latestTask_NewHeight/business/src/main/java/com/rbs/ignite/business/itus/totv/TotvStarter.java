package com.rbs.ignite.business.itus.totv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.system.ApplicationPidFileWriter;
import org.springframework.boot.system.EmbeddedServerPortFileWriter;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableMBeanExport;

import java.io.File;

/**
 * The starter key for the IgniteTradeUpdateService service, in just a few lines of annotations and code we ..
 * <ul>
 * <li>Create a {@link SpringApplication} instance</li>
 * <li>Scan the given {@link ComponentScan} path for configuration classes, components, services, controller etc</li>
 * <li>Enable JMX endpoints</li>
 * </ul>
 * <p>
 * This Spring application can be run like any main class
 * <ul>
 * <li>In your IDE: Run As > Java Application</li>
 * <li>In tests: using this annotation: <code>@SpringBootTest(classes = TotvStarter.class)</code></li>
 * <li>From a Maven command line: <code>mvn spring-boot:run</code></li>
 * <li>Standard Java command: <code>java -jar path/to/the/service/jar</code></li>
 * </ul>
 */
@EnableAutoConfiguration
@EnableConfigurationProperties
@EnableMBeanExport
@ComponentScan(value = {"com.rbs.ignite.business.itus"})
public class TotvStarter {
  private static final Logger logger = LoggerFactory.getLogger(TotvStarter.class);

  public static void main(String[] args) throws Exception {

    String logsDir = System.getProperty("logs.dir", "");
    SpringApplication app = new SpringApplication(TotvStarter.class);

    app.addListeners(new ApplicationPidFileWriter(logsDir + File.separator + "ignite-trade-update-service.pid"));
    app.addListeners(new EmbeddedServerPortFileWriter(logsDir + File.separator + "ignite-trade-update-service.port"));
    app.run(args);

  }
}