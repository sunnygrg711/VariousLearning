package org.sk.tutorial.jfamily.concurrency.locks;



/**
   A runnable that transfers money from an account to other
   accounts in a bank.
*/
public class TransferRunnable implements Runnable
{
   private IBankManager bankManager;
   private int fromBankAccountId;
   private double maxAmount;
   private static final int DELAY_IN_SECOND = 1;

   /**
    Constructs a transfer runnable.
    @param bankManager the bank between whose account money is transferred
    @param fromBankAccountId the account to transfer money from
    @param maxAmount the maximum amount of money in each transfer
    */
   public TransferRunnable(IBankManager bankManager, int fromBankAccountId, double maxAmount)
   {
      this.bankManager = bankManager;
      this.fromBankAccountId = fromBankAccountId;
      this.maxAmount = maxAmount;
   }

   public void run() {
      int i=0;
      try
      {
         while (i<8)
         {
            i++;
            int toRandomAccountID = (int) (bankManager.getBank().size() * Math.random());
            double randomAmount = maxAmount * Math.random();
            bankManager.getTransferable().transfer(fromBankAccountId, toRandomAccountID, randomAmount);
            System.out.printf("Total Balance: %10.2f%n",  bankManager.getBalanceViewable().getTotalBalance());
            Thread.sleep(1000*DELAY_IN_SECOND);
         }
      }
      catch (InterruptedException e) {}
   }
}
