package com.rbs.ignite.domain.itus.trade.enums;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import javax.validation.constraints.NotNull;

/**
 * Created by puronaa on 14/09/2017.
 */
public enum ItusTradeSourceSystem {
  DAVE("DAVE"), GFX("PabFX"), SYSTEMX("SystemX"), ICE("ICE"), IGNITE("IGNITE");
  @NotNull
  String name;

  ItusTradeSourceSystem(@JsonProperty("name")String name) {
    this.name = name;
  }

  @JsonValue
  public String getName() {
    return name;
  }

  @Override
  public String toString() {
    return "ItusTradeSourceSystem{" +
            "name='" + name + '\'' +
            '}';
  }
}
