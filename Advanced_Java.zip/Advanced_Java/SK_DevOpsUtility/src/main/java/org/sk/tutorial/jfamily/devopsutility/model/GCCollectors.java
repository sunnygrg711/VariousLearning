package org.sk.tutorial.jfamily.devopsutility.model;

/**
 * Created by kshekar on 24/04/2018.
 */
public class GCCollectors {



    public static YoungGCC getYoungGCC(String gcName){
        for (YoungGCC youngGCC:YoungGCC.values()) {
            if(youngGCC.javaName.equals(gcName)){
                return youngGCC;
            }
        }
        return null;
    }
    public static OldGCC oldGCC(String gcName){
        for (OldGCC oldGCC:OldGCC.values()) {
            if(oldGCC.javaName.equals(gcName)){
                return oldGCC;
            }
        }
        return null;
    }


     enum YoungGCC{
         COPY(1,"Copy"),
         PS_SCAVENGE(2,"PS Scavenge"),
         PAR_NEW(3,"ParNew"),
         G1_YOUNG_GENERATION(4,"G1 Young Generation");
         private int id;
         private String javaName;
         private YoungGCC(int id,String  javaName){
          this.id=id;
          this.javaName=javaName;
         }

    }

    enum OldGCC{
        MARK_SWEEP_COMPACT(1,"MarkSweepCompact"),
        G1_OLD_GENERATION(2,"G1 Old Generation"),
        PS_MARK_SWEEP(3,"PS MarkSweep"),
        CONCURRENT_MARK_SWEEP(4,"ConcurrentMarkSweep");
        private int id;
        private String javaName;
        private OldGCC(int id,String  javaName){
            this.id=id;
            this.javaName=javaName;
        }
    }
}
