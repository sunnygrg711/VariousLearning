package com.rbs.ignite.domain.itus.instrument.totv;



import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentDateRangeInput;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

public class TotvInstrumentDateRangeInput implements ItusInstrumentDateRangeInput {
    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate fromDate;
    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate toDate;

    @Override
    public LocalDate getFromDate() {
        return fromDate;
    }

    @Override
    public LocalDate getToDate() {
        return toDate;
    }

    public TotvInstrumentDateRangeInput(@JsonProperty("fromDate") LocalDate fromDate,  @JsonProperty("toDate")LocalDate toDate) {
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TotvInstrumentDateRangeInput)) return false;

        TotvInstrumentDateRangeInput that = (TotvInstrumentDateRangeInput) o;

        if (!fromDate.equals(that.fromDate)) return false;
        return toDate.equals(that.toDate);
    }

    @Override
    public int hashCode() {
        int result = fromDate.hashCode();
        result = 31 * result + toDate.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "TotvInstrumentDateRangeInput{" +
                "fromDate=" + fromDate +
                ", toDate=" + toDate +
                '}';
    }
}
