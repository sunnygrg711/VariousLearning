package org.sk.tutorial.jfamily.concurrency.examples.session1_2.app;

import org.sk.tutorial.jfamily.concurrency.examples.session1_2.Employee;
import org.sk.tutorial.jfamily.concurrency.examples.session1_2.SpecialEmployee;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by kshekar on 23/04/2018.
 */
public class ReentrancyMain {

    public static void main(String[] args) throws InterruptedException {
        Employee[] employees={new Employee(),
        new SpecialEmployee(),
        new SpecialEmployee(),
        new Employee(),
        new Employee(),
        new SpecialEmployee(),
        new Employee(),
        new Employee()};
        CountDownLatch countDownLatch=new CountDownLatch(employees.length);
        ExecutorService executors= Executors.newFixedThreadPool(3);
        for (Employee e:employees) {
            executors.submit(()->{

                    System.out.println(Thread.currentThread().getName()+" ->"+e.getDefaultBonus());
                    countDownLatch.countDown();
            });
        }
        countDownLatch.await();
        executors.shutdown();
        System.out.println("Done!");
    }

}
