package com.rbs.ignite.business.itus.service.instrument.totv.irs;

import com.google.common.base.Stopwatch;
import com.rbs.gbm.rates.core.auth.security.SsoTokenProviderService;
import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import com.rbs.ignite.api.itus.service.instrument.ItusInstrumentService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusWebServiceInterface;
import com.rbs.ignite.business.itus.util.WebServiceUtil;
import com.rbs.ignite.business.itus.util.WeekendTemporalAdjuster;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentDateInput;
import com.rbs.ignite.domain.itus.irs.FeedType;
import com.rbs.ignite.domain.itus.irs.TotvIrsInstrumentIdentifier;
import com.rbs.ignite.domain.itus.irs.TotvIrsRequest;
import com.rbs.ignite.domain.itus.irs.TotvIrsResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class TotvIrsInstrumentService implements ItusWebServiceInterface<TotvIrsRequest, TotvIrsResponse>, ItusInstrumentService<TotvInstrumentDateInput, TotvInstrumentData> {

  private static final Logger logger = LoggerFactory.getLogger(TotvIrsInstrumentService.class);
  private String tradeServiceUrl;
  private Class<TotvIrsResponse> responseClass;
  private TokenProviderService ssoTokenProviderService;
  private static final String FEED_DATE = "feedDate";
  private static final String FEED_TYPE = "feedType";
  @Autowired
  private RestTemplate restTemplate;

  public TotvIrsInstrumentService(String irsServiceUrl, Class<TotvIrsResponse> totvIrsResponseClass, SsoTokenProviderService ssoTokenProviderService) {
    this.responseClass = totvIrsResponseClass;
    this.tradeServiceUrl = irsServiceUrl;
    this.ssoTokenProviderService = ssoTokenProviderService;
  }

  @Override
  public String getTradeServiceUrl() {
    return tradeServiceUrl;
  }
  @Override
  public Class<TotvIrsResponse> getResponseClass() {
    return responseClass;
  }
  @Override
  public TotvIrsResponse getResponse(TotvIrsRequest request, String requestId) {

    HttpEntity<TotvInstrumentDateInput> httpEntity = new HttpEntity(WebServiceUtil.getHttpHeadersWithBasicAuth(ssoTokenProviderService));
    Map<String, String> parameterMap = new HashMap<>();
    parameterMap.put(FEED_TYPE, request.getFeedType().getType());
    parameterMap.put(FEED_DATE, request.getFeedDate().format(DateTimeFormatter.ofPattern("yyyyMMdd")));

    if (logger.isDebugEnabled())
      logger.debug(requestId + ":" + "IRS Url,Request:url[{}], Request[{}]", tradeServiceUrl + " with params " + parameterMap, httpEntity);
    ResponseEntity<TotvIrsResponse> postResponse = restTemplate.exchange(tradeServiceUrl, HttpMethod.GET, httpEntity, TotvIrsResponse.class, parameterMap);
    if (logger.isDebugEnabled()) logger.debug(requestId + ":" + "IRS response [{}]", postResponse);
    return postResponse.getBody();
  }

  @Override
  public Set<TotvInstrumentData> getInstrumentData(TotvInstrumentDateInput instrumentInput, String requestId, Boolean isDelta) throws ItusException {
    Stopwatch stopwatch = Stopwatch.createStarted();
    TotvIrsRequest request = new TotvIrsRequest();
    if (isDelta) {
      request.setFeedType(FeedType.DELTA);
    } else {
      request.setFeedType(FeedType.FULL);
    }
    request.setFeedDate(instrumentInput.getDate());
    logger.debug(requestId + ":" + "Calling IRS service to retrieve ISINs from MDX with input: ", instrumentInput.getDate());
    TotvIrsResponse irsResponse = getResponse(request, requestId);
    if (!irsResponse.getErrors().isEmpty()) {
      throw new ItusException(requestId + irsResponse.getErrors().toString());
    }
    if (irsResponse.getIsins().isEmpty()) {
      throw new ItusException(requestId + ": No isins received from IRS service ");
    }
    Set<TotvIrsInstrumentIdentifier> identifiers = (irsResponse.getIsins());
    Set<TotvInstrumentData> instrumentData = new HashSet<>();
    stopwatch.stop();
    Set<String> isinSet = new LinkedHashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(new TotvInstrumentData(identifier.getIdentifier())));
    identifiers.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    logger.info(requestId + ":" + "IRS call to get ISINs from MDX completed, found {} ISINs in {} ms.", identifiers.size(), stopwatch.elapsed(TimeUnit.MILLISECONDS));
    logger.info(requestId + ":" + "ISINs received from IRS:[{}]", isinSet);
    return instrumentData;
  }
}

