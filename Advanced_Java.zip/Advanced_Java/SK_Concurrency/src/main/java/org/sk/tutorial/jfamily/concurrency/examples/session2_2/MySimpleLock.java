package org.sk.tutorial.jfamily.concurrency.examples.session2_2;

import org.sk.tutorial.jfamily.concurrency.annotation.NotThreadSafe;

@NotThreadSafe(reason = "compound actions: check-then-act")
class MySimpleLock {
    private boolean locked = false;
    public boolean lock() {
        if(!locked) {
            locked = true;
            return true;
        }
        return false;
    }
}