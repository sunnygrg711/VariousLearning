package com.rbs.ignite.business.itus.service.trade.totv;

import com.google.common.base.Stopwatch;
import com.google.common.collect.Sets;
import com.rbs.ignite.api.itus.service.trade.IgniteTradeUpdateService;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentData;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.request.totv.TotvTradeAmendRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Created by upadkti on 13/11/2017.
 */
public abstract class AbstractTradeUpdateService implements IgniteTradeUpdateService<TotvTradeStatus,TotvInstrumentData,TotvTrade> {

  private static final Logger logger = LoggerFactory.getLogger(AbstractTradeUpdateService.class);

  @Override
  public Set<TotvTradeStatus> updateTrades(TotvTradeAmendRequest request) throws ItusException {
    Stopwatch stopwatch = Stopwatch.createStarted();
    Set<TotvTradeStatus> itusTradeStatuses = Sets.newHashSet();
    logger.info("{}:Started processing of trades for request {}", request.getRequestId(), request);
    try {
      Set<TotvTrade> tradesToProcess = request.getTrades();
      if (tradesToProcess == null || tradesToProcess.isEmpty()) {
        Set<String> instrumentSet = request.getIsins();

        if (instrumentSet == null || instrumentSet.isEmpty()) {
          Set<TotvInstrumentData> instrumentData = getInstrumentData(request.getDate(), request.getRequestId(),request.isDelta() );
          instrumentSet = getIsinSetFromTotvDataSet(instrumentData);
        }

        tradesToProcess = retrieveTrades(instrumentSet, request.getDate().getDate(), request.getSourceSystems(), request.getRequestId());
      }

      if (tradesToProcess != null && !tradesToProcess.isEmpty()) {
        itusTradeStatuses = processTrades(tradesToProcess, request.getRequestId(),request.getbyPassThreshold());
      }

      logger.info("{}: Processing of trades completed. Processed Trades Statuses: " + itusTradeStatuses);
    } catch (RuntimeException e) {
      throw new ItusFatalErrorException(request.getRequestId() + ":" + "Exception occurred while processing trades for date " + request.getDate(), e);
    }
    stopwatch.stop();
    logger.info(request.getRequestId() + ":" + "Processing of trades for date {} completed. Processed {} trades in {} ms.",
            request.getDate(), itusTradeStatuses.size(), stopwatch.elapsed(TimeUnit.MILLISECONDS));

    return itusTradeStatuses;
  }

  private Set<String> getIsinSetFromTotvDataSet(Set<TotvInstrumentData> financialInstrumentDataSet) {
    Set<String> isinSet = new LinkedHashSet<>();
    for (ItusInstrumentData data : financialInstrumentDataSet) {
      isinSet.add(data.getIsin());
    }
    return isinSet;
  }
  
  protected abstract Set<TotvTradeStatus> processTrades(Set<TotvTrade> tradeSet, String requestId, Boolean byPassThreshold);
}
