package com.rbs.ignite.domain.itus.trade.totv.ice;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.ignite.domain.itus.trade.totv.dave.ValidationResults;

/**
 * Created by upadkti on 02/12/2017.
 */
public class TotvIceResponse {

  private String responseCode;
  private String responseMessage;
  private String exceptionMessage;

  public String getResponseCode() {
    return responseCode;
  }
  public void setResponseCode(String responseCode) {
    this.responseCode = responseCode;
  }
  public String getResponseMessage() {
    return responseMessage;
  }
  public void setResponseMessage(String responseMessage) {
    this.responseMessage = responseMessage;
  }
  public String getExceptionMessage() {
    return exceptionMessage;
  }
  public void setExceptionMessage(String exceptionMessages) {
    this.exceptionMessage = exceptionMessages;
  }
  @Override
  public String toString() {
    return "TotvIceResponse{" +
            "responseCode='" + responseCode + '\'' +
            ", responseMessage='" + responseMessage + '\'' +
            ", exceptionMessage='" + exceptionMessage + '\'' +
            '}';
  }
}
