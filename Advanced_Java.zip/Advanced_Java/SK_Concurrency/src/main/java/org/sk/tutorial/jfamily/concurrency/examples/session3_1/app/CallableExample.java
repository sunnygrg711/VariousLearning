package org.sk.tutorial.jfamily.concurrency.examples.session3_1.app;

import org.sk.tutorial.jfamily.concurrency.examples.session3_1.Factorial;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableExample {

    public static void main(String []args) throws Exception {
        long N = 5;
        Callable<Long> task = new Factorial(N);
        ExecutorService es = Executors.newSingleThreadExecutor();
        Future<Long> future = es.submit(task);
        System.out.printf("factorial of %d is %d", N, future.get());
        es.shutdown();
    }
}
