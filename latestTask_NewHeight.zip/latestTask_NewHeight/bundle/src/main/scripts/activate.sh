#!/bin/bash

origDir=$(pwd)
cd $(dirname $0)
absDir=$(pwd)
if (( $(echo ${absDir} | grep -c opt) != 1 )); then
	echo "ERROR : Improper usage, please invoke $0 from the installed location"
	exit 1
fi

cd ../..
installedBase=$(pwd)

cd ..
envRoot=$(pwd)
if [[ $(basename ${installedBase}) == ${project.parent.artifactId} ]]; then
	echo "ERROR : Already activated installation."
	echo "        Symlink: ${project.parent.artifactId} already points to $(basename ${installedBase})"
	exit 1
fi

unlink ${project.parent.artifactId}.previous 2> /dev/null
mv ${project.parent.artifactId} ${project.parent.artifactId}.previous 2> /dev/null
ln -s $(basename ${installedBase}) ${project.parent.artifactId}
if (( $? != 0 )); then
  echo "ERROR : Unable to activate $installedBase"
  exit 1
fi
cd ${origDir}

echo " "
echo "======================================================================================"
echo "ACTIVATION SUCCESSFUL"
echo " "
echo "Details: Pointed Sym-Link: ${project.parent.artifactId} -> $(basename ${installedBase})"
echo "======================================================================================"
echo " "
exit 0
