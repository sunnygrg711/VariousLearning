package org.sk.tutorial.jfamily.concurrency.examples.session1_1;

/**
 * Created by kshekar on 07/05/2018.
 */
public class NullTread {
    public static void main(String[] args) {
        Thread t=new Thread(() -> {
            System.out.println(Thread.currentThread());
        },null);
        t.start();
    }
}
