package com.rbs.ignite.business.itus.web.controller.totv.mock;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;


public class DaveMockServer {

  private int mockServerPort;

  private WireMockServer server;


  public DaveMockServer(String daveUrl) {
    this.mockServerPort = MockServerUtil.getPortNumber(daveUrl);
    server = new WireMockServer(mockServerPort);
  }

  public WireMockServer ensureDaveServerIsDown() {
    server.stop();
    MockServerUtil.waitTillServerStops(server, mockServerPort);
    return server;
  }

  public WireMockServer ensureDaveResponse(String request1, String response1,String request2, String response2) {

    if (server.isRunning()) {
      server.resetAll();
    } else {
      server.start();
      MockServerUtil.waitTillServerStarts(server, mockServerPort);
    }



    try {
      server.stubFor(
              WireMock.post(WireMock.urlEqualTo("/api/v1/update/mifid"))
                      .withRequestBody(WireMock.equalToJson(request1))
                      .willReturn(
                              WireMock.aResponse()
                                      .withStatus(HttpStatus.OK.value())
                                      .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                      .withBody(response1)
                      )
      );
      server.stubFor(
              WireMock.post(WireMock.urlEqualTo("/api/v1/update/mifid"))
                      .withRequestBody(WireMock.equalToJson(request2))
                      .willReturn(
                              WireMock.aResponse()
                                      .withStatus(HttpStatus.OK.value())
                                      .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                      .withBody(response2)
                      )
      );
      return server;
    } catch (Exception e) {
      throw new RuntimeException(e);
    }

  }
}
