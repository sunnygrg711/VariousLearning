package com.rbs.ignite.business.itus.mgmt;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class DaveHealthIndicator extends AbstractHealthIndicator {

  @Autowired
  private RestTemplate restTemplate;

  @Value("${dave.health.url}")
  private String daveUrl;

  @Override
  protected void doHealthCheck(Health.Builder builder) throws Exception {

    ResponseEntity<JsonNode> resp = restTemplate.getForEntity(daveUrl, JsonNode.class);
    if (HttpStatus.NOT_FOUND != resp.getStatusCode()) {
      builder.withDetail("Env " ,daveUrl).status(Status.UP);
    } else {
      builder.status(Status.DOWN);
    }
  }
}
