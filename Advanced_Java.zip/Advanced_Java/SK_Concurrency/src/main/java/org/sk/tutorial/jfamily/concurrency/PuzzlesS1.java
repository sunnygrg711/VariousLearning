package org.sk.tutorial.jfamily.concurrency;

/**
 * Created by kshekar on 18/04/2018.
 */
public class PuzzlesS1 {
    final static long MICROS_PER_DAY = 24 * 60 * 60 * 1000 * 1000;
    final static long MILLIS_PER_DAY = 24 * 60 * 60 * 1000;

    public static void main(String[] args) {
        System.out.println(2.00 - 1.10);
        System.out.println(12345 + 5432l);
        System.out.println(MICROS_PER_DAY / MILLIS_PER_DAY);
        System.out.println(classifyMe('n') + classifyMe('+') + classifyMe('2'));
    }

    public static String classifyMe(char c) {
        if ("0123456789".indexOf(c) >= 0) {
            return "NUMERAL ";
        }
        if ("abcdefghijklmnopqrstuvwxyz".indexOf(c) >= 0) {
            return "LETTER ";
        }

// TODO finish implementation of operator classification
//       if("+-*/&|!=".indexOf(c) >= 0){
//            return "OPERATOR ";
//    }
//
//
        return "UNKNOW ";
    }
}