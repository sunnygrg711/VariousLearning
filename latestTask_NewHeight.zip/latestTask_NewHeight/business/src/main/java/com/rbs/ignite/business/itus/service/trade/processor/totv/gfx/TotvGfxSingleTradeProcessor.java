package com.rbs.ignite.business.itus.service.trade.processor.totv.gfx;

import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.processor.ItusWebServiceInterface;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.util.WebServiceUtil;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxRequest;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxResponse;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static com.rbs.ignite.business.itus.util.CommonConstantsUtil.CORRELATION.GFX;


/**
 * Class which process single Gfx trade
 */
public class TotvGfxSingleTradeProcessor implements ItusWebServiceInterface<TotvGfxRequest, TotvGfxResponse>, ItusSingleTradeProcessor<TotvTrade> {

  private static final Logger logger = LoggerFactory.getLogger(TotvGfxSingleTradeProcessor.class);

  private static final String TRANSACTION_IDENTIFIER = "transactionIdentifier";

  private String tradeServiceUrl;

  private Class<TotvGfxResponse> responseClass;

  private TokenProviderService ssoTokenProviderService;

  @Autowired
  private ItusTransformer totvTradeToGfxReqTransformer;

  @Autowired
  private RestTemplate restTemplate;

  public TotvGfxSingleTradeProcessor(String tradeServiceUrl, Class<TotvGfxResponse> responseClass, TokenProviderService ssoTokenProviderService) {
    this.tradeServiceUrl = tradeServiceUrl;
    this.responseClass = responseClass;
    this.ssoTokenProviderService = ssoTokenProviderService;
  }

  @Override
  public String getTradeServiceUrl() {
    return tradeServiceUrl;
  }

  @Override
  public Class<TotvGfxResponse> getResponseClass() {
    return responseClass;
  }

  @Override
  public TotvGfxResponse getResponse(TotvGfxRequest totvGfxRequest,String requestId) {
    HttpEntity requestEntity = new HttpEntity(WebServiceUtil.getHttpHeaders(ssoTokenProviderService, GFX));
    Map<String, String> parameterMap = new HashMap<>();
    if (StringUtils.isEmpty(totvGfxRequest.getTransactionIdentifier())){
      throw new ItusFatalErrorException("Invalid tradeId received from Odc");
    }
    parameterMap.put(TRANSACTION_IDENTIFIER, totvGfxRequest.getTransactionIdentifier());
    logger.debug(requestId+":"+"Making Gfx system request at URL " + tradeServiceUrl + " with params " + parameterMap);
    logger.info(requestId+":"+"Calling GFX Service {} : {} , Target {} ", GFX.getKey(), requestEntity.getHeaders().get(GFX.getKey()), totvGfxRequest.getTransactionIdentifier());
    ResponseEntity<TotvGfxResponse> responseEntity = restTemplate.exchange(tradeServiceUrl, HttpMethod.PUT, requestEntity, responseClass, parameterMap);
    TotvGfxResponse response = responseEntity.getBody();
    logger.info(requestId+":"+"{} : {}, Gfx response {}",GFX.getKey(), requestEntity.getHeaders().get(GFX.getKey()), response);
    return response;
  }

  @Override
  public TotvTradeStatus processTrade(TotvTrade totvTrade, String requestId) throws ItusException {
    logger.debug(requestId+":"+"Processing GFX Trade {} " + totvTrade);
    TotvTradeStatus status = null;
    TotvGfxRequest totvGfxRequest = (TotvGfxRequest) totvTradeToGfxReqTransformer.transform(totvTrade);
    try {
      TotvGfxResponse response = getResponse(totvGfxRequest,requestId);
      status = getItusTradeStatus(totvTrade, response);
      logger.debug(requestId+":"+"Trade status: {}", status);
    } catch (Exception e) {
      logger.warn(requestId+":"+"Error occurred while processing trade {}:{}",totvTrade, e);
      status = new TotvTradeStatus.TotvTradeStatusBuilder(totvTrade, ItusStatus.REJECTED, HttpStatus.SERVICE_UNAVAILABLE.toString())
              .exceptions(e.getMessage()).build();
    }
    return status;
  }

  private TotvTradeStatus getItusTradeStatus(TotvTrade trade, TotvGfxResponse totvGfxResponse) throws ItusException {
    if (totvGfxResponse == null) {
      throw new ItusException("Invalid Response from trade system");
    }
    String code = totvGfxResponse.getSuccess();
    String errorMessage = totvGfxResponse.getErrorMessage();
    String responseMessage = totvGfxResponse.getCorrelationId();
    if (code != null && !StringUtils.isEmpty(code))
      code = code.toLowerCase().trim();
    ItusStatus itusStatus = null;
    switch (code) {
      case "true":
        itusStatus = ItusStatus.ACCEPTED;
        break;
      default:
        itusStatus = ItusStatus.REJECTED;
    }
    TotvTradeStatus.TotvTradeStatusBuilder totvTradeStatus = new TotvTradeStatus.TotvTradeStatusBuilder(trade, itusStatus, code);
    if (errorMessage != null && !StringUtils.isEmpty(errorMessage))
      totvTradeStatus.exceptions(errorMessage);
    if (responseMessage != null && !StringUtils.isEmpty(responseMessage))
      totvTradeStatus.message(responseMessage);
    return totvTradeStatus.build();
  }
}
