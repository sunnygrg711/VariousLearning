package org.sk.tutorial.jfamily.adminui.model;

/**
 * Created by kshekar on 03/04/2018.
 */
public enum State {
    RUNNING,
    STOPPED,
    TERMINATED
}
