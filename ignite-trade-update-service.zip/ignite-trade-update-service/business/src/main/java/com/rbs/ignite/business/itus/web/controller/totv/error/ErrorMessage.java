package com.rbs.ignite.business.itus.web.controller.totv.error;

import java.io.Serializable;

public class ErrorMessage implements Serializable {

  private static final long serialVersionUID = 1L;

  private final int statusCode;
  private final String errorMsg;

  public ErrorMessage(int statusCode, String errorMsg) {
    super();
    this.statusCode = statusCode;
    this.errorMsg = errorMsg;
  }

  public int getHttpStatus() {
    return statusCode;
  }

  public String getErrorMsg() {
    return errorMsg;
  }

}
