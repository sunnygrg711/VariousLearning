package org.sk.tutorial.jfamily.devopsutility.model;

/**
 * Created by kshekar on 03/04/2018.
 */
public class Gc {
    private String minorGcName;
    private String majorGcName;
    private long minorGcCount;
    private long minorGcTime;
    private long majorGcCount;
    private long majorGcTime;

    public String getMinorGcName() {
        return minorGcName;
    }

    public void setMinorGcName(String minorGcName) {
        this.minorGcName = minorGcName;
    }

    public String getMajorGcName() {
        return majorGcName;
    }

    public void setMajorGcName(String majorGcName) {
        this.majorGcName = majorGcName;
    }

    public long getMinorGcCount() {
        return minorGcCount;
    }

    public void setMinorGcCount(long minorGcCount) {
        this.minorGcCount = minorGcCount;
    }

    public long getMinorGcTime() {
        return minorGcTime;
    }

    public void setMinorGcTime(long minorGcTime) {
        this.minorGcTime = minorGcTime;
    }

    public long getMajorGcCount() {
        return majorGcCount;
    }

    public void setMajorGcCount(long majorGcCount) {
        this.majorGcCount = majorGcCount;
    }

    public long getMajorGcTime() {
        return majorGcTime;
    }

    public void setMajorGcTime(long majorGcTime) {
        this.majorGcTime = majorGcTime;
    }
}

