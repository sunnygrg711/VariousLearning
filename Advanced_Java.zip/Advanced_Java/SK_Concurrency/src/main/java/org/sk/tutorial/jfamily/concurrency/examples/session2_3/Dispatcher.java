package org.sk.tutorial.jfamily.concurrency.examples.session2_3;

import org.sk.tutorial.jfamily.concurrency.annotation.GuardedBy;

import java.awt.*;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.util.HashSet;
import java.util.Set;

class Dispatcher {
    @GuardedBy(name = "this")
    private final Set<Taxi> taxis = new HashSet<Taxi>();
    @GuardedBy(name = "this")
    private final Set<Taxi> availableTaxis;

    public Dispatcher() {
        availableTaxis = new HashSet<Taxi>();
    }

    public synchronized void notifyAvailable(Taxi taxi) {
        availableTaxis.add(taxi);
    }

    public synchronized Image getImage() {
        Image image = new Image() {
            @Override
            public int getWidth(ImageObserver observer) {
                return 0;
            }

            @Override
            public int getHeight(ImageObserver observer) {
                return 0;
            }

            @Override
            public ImageProducer getSource() {
                return null;
            }

            @Override
            public Graphics getGraphics() {
                return null;
            }

            @Override
            public Object getProperty(String name, ImageObserver observer) {
                return null;
            }
            public void drawMarker(Point p){

            }
        };
        for (Taxi t : taxis) {
          //  image.drawMarker(t.getLocation());
        }
        return image;
    }
}