package com.rbs.ignite.business.itus.configurer;

import org.springframework.context.annotation.Configuration;

import com.rbs.rates.foundation.property.PropertiesPostProcessor;

/**
 * An implementation of {@link PropertiesPostProcessor} which sets up our environment so that it can handle encrypted properties
 * and is sensitive to our property file inheritance hierarchy. The parent class implements that, all we need do here is 
 * configure an instance of that class with our service's name.  
 */
@Configuration
public class IgniteTradeUpdateServicePropertiesConfigurer extends PropertiesPostProcessor {

  public IgniteTradeUpdateServicePropertiesConfigurer() {
    super("ignite-trade-update-service");
  }
}