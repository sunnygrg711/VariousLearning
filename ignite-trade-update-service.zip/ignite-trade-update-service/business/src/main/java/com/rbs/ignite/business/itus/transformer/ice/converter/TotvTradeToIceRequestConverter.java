package com.rbs.ignite.business.itus.transformer.ice.converter;


import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

/**
 * Created by upadkti on 04/12/2017.
 */
public class TotvTradeToIceRequestConverter implements Converter<TotvTrade, TotvIceRequest> {
  private static Logger logger = LoggerFactory.getLogger(TotvTradeToIceRequestConverter.class);

  @Override
  public TotvIceRequest convert(TotvTrade totvTrade) {
    TotvIceRequest totvIceRequest = new TotvIceRequest();
    if (totvTrade.getTradeIdentifier() != null)
      totvIceRequest.setTransactionIdentifier(totvTrade.getTradeIdentifier());
    else {
      totvIceRequest.setTransactionIdentifier("");
    }
    if (totvTrade.getIsin() !=null){
      totvIceRequest.setIsin(totvTrade.getIsin());
    }else{
      totvIceRequest.setIsin("");
    }
    logger.debug("Converted ICE Request is : {}", totvIceRequest);
    return totvIceRequest;
  }
}
