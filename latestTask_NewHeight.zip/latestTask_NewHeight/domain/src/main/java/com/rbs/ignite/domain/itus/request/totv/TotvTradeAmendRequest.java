package com.rbs.ignite.domain.itus.request.totv;

import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentDateInput;
import com.rbs.ignite.domain.itus.request.RequestEntity;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;

import java.util.Set;

/**
 * Created by upadkti on 12/01/2018.
 */
public class TotvTradeAmendRequest implements RequestEntity {
  private String requestId;
  private Boolean isDelta;
  private TotvInstrumentDateInput date;
  private Set<String> isins;
  private Set<ItusTradeSourceSystem> sourceSystems;
  private Set<TotvTrade> trades;
  private Boolean byPassThreshold;

  public TotvTradeAmendRequest(String requestId, Boolean isDelta, TotvInstrumentDateInput date, Set<String> isins,
                               Set<ItusTradeSourceSystem> sourceSystems, Set<TotvTrade> trades,Boolean byPassThreshold) {
    this.requestId = requestId;
    this.isDelta = isDelta;
    this.date = date;
    this.isins = isins;
    this.sourceSystems = sourceSystems;
    this.trades = trades;
    this.byPassThreshold=byPassThreshold;
  }

  public String getRequestId() {
    return requestId;
  }

  public void setRequestId(String requestId) {
    this.requestId = requestId;
  }

  public TotvInstrumentDateInput getDate() {
    return date;
  }

  public void setDate(TotvInstrumentDateInput date) {
    this.date = date;
  }

  public Set<String> getIsins() {
    return isins;
  }

  public Boolean isDelta() { return isDelta; }

  public void setIsins(Set<String> isins) {
    this.isins = isins;
  }

  public Boolean getbyPassThreshold() {
    return byPassThreshold;
  }
  public void setbyPassThreshold(Boolean byPassThreshold) {
    this.byPassThreshold = byPassThreshold;
  }
  public Set<TotvTrade> getTrades() {
    return trades;

  }

  public void setTrades(Set<TotvTrade> trades) {
    this.trades = trades;
  }

  public Set<ItusTradeSourceSystem> getSourceSystems() {
    return sourceSystems;
  }

  public void setSourceSystems(Set<ItusTradeSourceSystem> sourceSystems) {
    this.sourceSystems = sourceSystems;
  }
  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvTradeAmendRequest that = (TotvTradeAmendRequest) o;

    if (!requestId.equals(that.requestId)) return false;
    if (!isDelta.equals(that.isDelta)) return false;
    if (!date.equals(that.date)) return false;
    if (!isins.equals(that.isins)) return false;
    if (!sourceSystems.equals(that.sourceSystems)) return false;
    if (!trades.equals(that.trades)) return false;
    return byPassThreshold.equals(that.byPassThreshold);
  }
  @Override
  public int hashCode() {
    int result = requestId.hashCode();
    result = 31 * result + isDelta.hashCode();
    result = 31 * result + date.hashCode();
    result = 31 * result + isins.hashCode();
    result = 31 * result + sourceSystems.hashCode();
    result = 31 * result + trades.hashCode();
    result = 31 * result + byPassThreshold.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return "TotvTradeAmendRequest{" +
            "requestId='" + requestId + '\'' +
            ", isDelta=" + isDelta +
            ", date=" + date +
            ", isins=" + isins +
            ", sourceSystems=" + sourceSystems +
            ", trades=" + trades +
            ", byPassThreshold=" + byPassThreshold +
            '}';
  }
}
