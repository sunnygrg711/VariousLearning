package com.rbs.ignite.business.itus.service.trade.totv;

import com.google.common.collect.Sets;
import com.rbs.ignite.api.itus.service.instrument.ItusInstrumentService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessingService;
import com.rbs.ignite.api.itus.service.trade.retrieval.ItusTradeRetrievalService;
import com.rbs.ignite.business.itus.jmx.TotvJmxProvider;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentDateInput;
import com.rbs.ignite.domain.itus.request.totv.TotvTradeAmendRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.*;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.LocalDate;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

import static org.mockito.Matchers.any;

/**
 * Created by upadkti on 15/11/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class TotvTradeUpdateServiceTest {

  @InjectMocks
  private TotvTradeUpdateService totvTradeUpdateService;
  @Mock
  private TotvInstrumentDateInput itusInstrumentInput;
  @Mock
  private ItusInstrumentService itusInstrumentService;
  @Mock
  private ItusTradeRetrievalService itusTradeRetrievalService;
  @Mock
  private ItusTradeProcessingService itusTradeProcessingService;
  @Mock
  private TotvTrade totvTrade;
  @Mock
  private TotvTradeStatus itusTradeStatus;
  @Mock
  private ExecutorService executorService;
  @Mock
  private TotvJmxProvider totvJmxProvider;
  @Rule
  public ExpectedException thrown = ExpectedException.none();
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testUpdateTrades() throws ItusException {
    Set<String> dataSet = Sets.newHashSet("ISIN12345");
    Mockito.when(itusInstrumentService.getInstrumentData(itusInstrumentInput, "<EMPTY>",true )).thenReturn(dataSet);
    Mockito.when(itusInstrumentInput.getDate()).thenReturn(LocalDate.now());

    Set<TotvTrade> tradeSet = Sets.newHashSet(totvTrade);
    Mockito.when(itusTradeRetrievalService.retrieveTrades(dataSet, LocalDate.now(), Sets.newHashSet(), "<EMPTY>")).thenReturn(tradeSet);
    Mockito.when(itusTradeProcessingService.processTrades(tradeSet, "<EMPTY>", false)).thenReturn(Sets.newHashSet(itusTradeStatus));
    Mockito.when(executorService.submit(any(Callable.class))).thenReturn(CompletableFuture.completedFuture(Sets.newHashSet(itusTradeStatus)));
    Mockito.when(totvJmxProvider.getReadOnlyMode()).thenReturn(Boolean.FALSE);

    TotvTradeAmendRequest request = new TotvTradeAmendRequest("<EMPTY>",true, new TotvInstrumentDateInput(LocalDate.now()), dataSet, Sets.newHashSet(), null,false);
    Set<TotvTradeStatus> statusSet = totvTradeUpdateService.updateTrades(request);
    Assert.assertTrue(statusSet != null && statusSet.size() == 1);
    Assert.assertTrue(statusSet.contains(itusTradeStatus));
  }

  @Test
  public void testUpdateTrades_GetInstrumentDataThrowsException() throws ItusException {
    thrown.expect(ItusException.class);
    Set<String> dataSet = Sets.newHashSet("ISIN12345");
    Mockito.when(itusInstrumentService.getInstrumentData(Mockito.any(), Mockito.anyString(),Mockito.anyBoolean() )).thenThrow(new ItusException());
    TotvTradeAmendRequest request = new TotvTradeAmendRequest("<EMPTY>",true, new TotvInstrumentDateInput(LocalDate.now()), null, Sets.newHashSet(), null,false);
    totvTradeUpdateService.updateTrades(request);
  }

  @Test
  public void testUpdateTrades_GetTradeFromODCThrowsException() throws ItusException {
    thrown.expect(ItusException.class);
    Set<String> dataSet = Sets.newHashSet("ISIN12345");
    Mockito.when(itusInstrumentService.getInstrumentData(itusInstrumentInput, "<EMPTY>",true )).thenReturn(dataSet);
    Mockito.when(itusInstrumentInput.getDate()).thenReturn(LocalDate.now());
    Mockito.when(itusTradeRetrievalService.retrieveTrades(dataSet, LocalDate.now(), Sets.newHashSet(), "<EMPTY>")).thenThrow(new ItusException());
    TotvTradeAmendRequest request = new TotvTradeAmendRequest("<EMPTY>", true,new TotvInstrumentDateInput(LocalDate.now()), dataSet, Sets.newHashSet(), null,false);
    totvTradeUpdateService.updateTrades(request);
  }

  @Test
  public void testUpdateTrades_ThrowsException() throws ItusException {

    Set<String> dataSet = Sets.newHashSet("ISIN12345");
    Mockito.when(itusInstrumentService.getInstrumentData(itusInstrumentInput, "<EMPTY>", true)).thenReturn(dataSet);
    Mockito.when(itusInstrumentInput.getDate()).thenReturn(LocalDate.now());

    Set<TotvTrade> tradeSet = Sets.newHashSet(totvTrade);
    Mockito.when(itusTradeRetrievalService.retrieveTrades(dataSet, LocalDate.now(), Sets.newHashSet(), "<EMPTY>")).thenReturn(tradeSet);
    Mockito.when(itusTradeProcessingService.processTrades(tradeSet, "<EMPTY>", false)).thenThrow(new ItusException());
    Mockito.when(executorService.submit(any(Callable.class))).thenReturn(CompletableFuture.completedFuture(Sets.newHashSet(itusTradeStatus)));
    Mockito.when(totvJmxProvider.getReadOnlyMode()).thenReturn(Boolean.FALSE);

    TotvTradeAmendRequest request = new TotvTradeAmendRequest("<EMPTY>", true,new TotvInstrumentDateInput(LocalDate.now()), dataSet, Sets.newHashSet(), null,false);
    Set<TotvTradeStatus> statusSet = totvTradeUpdateService.updateTrades(request);
    Assert.assertTrue(statusSet != null && statusSet.size() == 0);
  }
}
