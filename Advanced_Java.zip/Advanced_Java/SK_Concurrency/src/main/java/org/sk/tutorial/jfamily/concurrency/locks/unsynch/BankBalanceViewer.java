package org.sk.tutorial.jfamily.concurrency.locks.unsynch;

import org.sk.tutorial.jfamily.concurrency.locks.Account;
import org.sk.tutorial.jfamily.concurrency.locks.BalanceViewable;
import org.sk.tutorial.jfamily.concurrency.locks.Bank;
import org.sk.tutorial.jfamily.concurrency.locks.synch.BankLockingImpl;

/**
 * Created by kshekar on 22/03/2018.
 */
public class BankBalanceViewer implements BalanceViewable {
    private Bank bank;

    public BankBalanceViewer(Bank bank) {
        this.bank = bank;

    }
    public double getTotalBalance() {

            double sum = 0;

            for (Account account : bank.getAccounts())
                sum += account.getBalanceAmount();

            return sum;
    }

}
