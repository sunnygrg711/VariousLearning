package org.sk.tutorial.jfamily.devopsutility.exceptions;

/**
 * Created by kshekar on 06/04/2018.
 */
public class JFamilyException extends RuntimeException {

    public JFamilyException(String message) {
        super(message);
    }

    public JFamilyException(String message, Throwable cause) {
        super(message, cause);
    }

    public JFamilyException(Throwable cause) {
        super(cause);
    }


    public JFamilyException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
