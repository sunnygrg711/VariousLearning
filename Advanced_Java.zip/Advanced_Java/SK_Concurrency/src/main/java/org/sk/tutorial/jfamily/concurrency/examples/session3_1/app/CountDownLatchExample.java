package org.sk.tutorial.jfamily.concurrency.examples.session3_1.app;

import org.sk.tutorial.jfamily.concurrency.examples.session3_1.Task;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class CountDownLatchExample {

    public static void main(String[] args) throws InterruptedException {
        CountDownLatch countDownLatch=new CountDownLatch(5);
        ExecutorService executorService= Executors.newFixedThreadPool(3);
        List<Task> tasks=Arrays.asList(new Task(countDownLatch),
                new Task(countDownLatch),new Task(countDownLatch),
                new Task(countDownLatch),new Task(countDownLatch));
        tasks.forEach(task -> executorService.submit(task));
        countDownLatch.await();
        executorService.shutdown();
        System.out.println(tasks.size()+" tasks is processed!.");
    }
}
