package com.rbs.ignite.business.itus.service.trade.retrieval.odc.totv;

import com.google.common.collect.Lists;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusQueryExecutor;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.odc.access.domain.Transaction;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.Set;

/**
 * Created by upadkti on 08/11/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class OdcTradeRetrievalServiceTest {

  @InjectMocks
  private OdcTradeRetrievalService testObj = new OdcTradeRetrievalService();
  @Mock
  private TotvInstrumentData totvInstrumentData;
  @Mock
  private ItusQueryExecutor<Set<Transaction>> iteratorItusQueryExecutor;
  @Mock
  private Transaction transaction;
  @Mock
  private ItusTransformer<Set<Transaction>,Set<TotvTrade>> tusTransformer;
  private TotvTrade trade = new TotvTrade("ISIN1234567","123456789", ItusTradeSourceSystem.DAVE,"1","DAVE","GDSLDN");

  @Rule
  public ExpectedException thrown= ExpectedException.none();

  @Before
  public void setup(){
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testRetrieveTrades_Success() throws Exception {
    Mockito.when(totvInstrumentData.getIsin()).thenReturn("ISIN1234567");
    Mockito.when(iteratorItusQueryExecutor.executeQuery(Mockito.any())).thenReturn(Sets.newSet(transaction));
    Mockito.when(tusTransformer.transform(Mockito.anySet())).thenReturn(Sets.newSet(trade));
    ReflectionUtil.setPrivateField(OdcTradeRetrievalService.class, testObj,"totvSourceSystem", "DAVE");
    Set<TotvTrade> tradeSet = testObj.retrieveTrades(Sets.newSet(totvInstrumentData), LocalDate.now());
    Assert.assertTrue(tradeSet!= null && tradeSet.size() == 1);
    Assert.assertTrue(tradeSet.contains(trade));
  }

  @Test
  public void testRetrieveTrades_ExceptionForBlankInput() throws Exception {
    thrown.expect(ItusException.class);
    thrown.expectMessage("No Isins found");
    testObj.retrieveTrades(Sets.newSet(),LocalDate.now());
  }

  @Test
  public void testRetrieveTrades_ExceptionForNullInput() throws Exception {
    thrown.expect(ItusException.class);
    thrown.expectMessage("No Isins found");
    testObj.retrieveTrades(null, LocalDate.now());
  }

  @Test
  public void testRetrieveTrades_IfODCReturnsNull() throws Exception {
    Mockito.when(totvInstrumentData.getIsin()).thenReturn("ISIN1234567");
    Mockito.when(iteratorItusQueryExecutor.executeQuery(Mockito.any())).thenReturn(null);
    ReflectionUtil.setPrivateField(OdcTradeRetrievalService.class, testObj,"totvSourceSystem", "DAVE");
    Set<TotvTrade> tradeSet = testObj.retrieveTrades(Sets.newSet(totvInstrumentData),LocalDate.now());
    Assert.assertEquals(tradeSet,null);
  }
}
