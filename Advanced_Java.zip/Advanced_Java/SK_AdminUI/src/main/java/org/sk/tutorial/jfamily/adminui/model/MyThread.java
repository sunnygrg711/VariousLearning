package org.sk.tutorial.jfamily.adminui.model;

/**
 * Created by kshekar on 25/04/2018.
 */
public class MyThread extends Thread {


    public MyThread(String name) {
        super(name);
    }


    public MyThread(Runnable target, String name) {
        super(target, name);
    }

    @Override
    public void run() {
        try{
            int timer=200;
            while(timer-->0){
                Thread.sleep(1000);
                System.out.println(this+"Timer..."+timer);
            }
            System.out.println("Done!!");
        }
        catch (Exception e){

        }
    }
}
