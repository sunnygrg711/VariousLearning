package org.sk.tutorial.jfamily.concurrency.examples.session3_1;

import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class PersonThread extends Thread {

    private Semaphore atmRome;

    public PersonThread(String name, Semaphore atmRome) {
        super(name);
        this.atmRome = atmRome;
    }

    @Override
    public void run(){
        System.out.println(getName()+" waiting for ATM");
        long startTime=System.currentTimeMillis();
        try {
            atmRome.acquire();
            System.out.println("ATM is being used by "+getName());
            TimeUnit.SECONDS.sleep(new Random().nextInt(5));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        finally {
            atmRome.release();
            System.out.println("ATM is released by "+getName()+". Processing time taken in second:"+(System.currentTimeMillis()-startTime)/1000);
        }
    }
}
