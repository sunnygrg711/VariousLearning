package com.rbs.ignite.domain.itus.instrument.totv;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Set;

public class TotvInputForDateWithIsins {

  @NotNull
  private Set<String> isinSet;

  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
  private LocalDate date;

  public TotvInputForDateWithIsins(@JsonProperty("isinSet") Set<String> isinSet, @JsonProperty("date")LocalDate date) {
    this.isinSet = isinSet;
    this.date = date;
  }
  public Set<String> getIsinSet() {
    return isinSet;
  }
  public LocalDate getDate() {
    return date;
  }
  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvInputForDateWithIsins that = (TotvInputForDateWithIsins) o;

    if (isinSet != null ? !isinSet.equals(that.isinSet) : that.isinSet != null) return false;
    return date != null ? date.equals(that.date) : that.date == null;
  }
  @Override
  public int hashCode() {
    int result = isinSet != null ? isinSet.hashCode() : 0;
    result = 31 * result + (date != null ? date.hashCode() : 0);
    return result;
  }
  @Override
  public String toString() {
    return "TotvInputForDateWithIsins{" +
            "isinSet=" + isinSet +
            ", date=" + date +
            '}';
  }
}
