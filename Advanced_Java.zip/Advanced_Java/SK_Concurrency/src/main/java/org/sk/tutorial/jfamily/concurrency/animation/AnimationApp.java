package org.sk.tutorial.jfamily.concurrency.animation;

import javax.swing.*;

/**
 *
 * Created by kshekar on 22/03/2018.
 */
public class AnimationApp {

    public static void main(String[] args) {
       // AllSortingAlgo();
       JFrame jFrame=new AnimationFrame(System.getProperty("sortingAlgo","JAVA_DEFAULT_API")+" Algorithm..");
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setVisible(true);
    }

    private static void AllSortingAlgo() {
        for(SortingAlgorithmTypes sortingAlgorithmTypes: SortingAlgorithmTypes.values())
        {
            System.setProperty("sortingAlgo",sortingAlgorithmTypes.name());
            JFrame jFrame=new AnimationFrame(System.getProperty("sortingAlgo","JAVA_DEFAULT_API")+" Algorithm..");
            jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jFrame.setVisible(true);
        }
    }
}
