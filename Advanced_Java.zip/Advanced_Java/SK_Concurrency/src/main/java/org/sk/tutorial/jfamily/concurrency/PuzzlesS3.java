package org.sk.tutorial.jfamily.concurrency;

/**
 * Created by kshekar on 18/04/2018.
 */
public class PuzzlesS3 {
    public PuzzlesS3(Object o) {
        System.out.println("Object");
    }
    public PuzzlesS3(double[] d) {
        System.out.println("double array");
    }
    public static void main(String[] args) {
      new PuzzlesS3(null);
      Object o=null;
      new PuzzlesS3(o);
      double[] d=null;
      new PuzzlesS3(d);
    }
}
