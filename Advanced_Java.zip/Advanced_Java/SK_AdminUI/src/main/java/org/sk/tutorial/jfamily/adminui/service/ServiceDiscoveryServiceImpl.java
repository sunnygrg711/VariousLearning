package org.sk.tutorial.jfamily.adminui.service;

import org.sk.tutorial.jfamily.adminui.model.Application;
import org.sk.tutorial.jfamily.adminui.model.State;
import org.sk.tutorial.jfamily.devopsutility.service.ApplicationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by kshekar on 02/04/2018.
 */
@Service
public class ServiceDiscoveryServiceImpl implements ServiceDiscoveryService {


    @Autowired
    private Application application;
    static private final Logger LOGGER= LoggerFactory.getLogger(ServiceDiscoveryService.class);


    private Map<String,Application> inMemoryRepository=new ConcurrentHashMap<>();


    @PostConstruct
    void addMySelf(){
        register(application);
    }

    /**
     * Get Application details by Name
     *
     * @param applicationName
     * @return
     */
    @Override
    public Application getApplicationByName(String applicationName) {
        return inMemoryRepository.get(applicationName);
    }

    /**
     * Register Application on Service Discovery
     *
     * @param application
     * @return
     */
    @Override
    public boolean register(Application application) {
        inMemoryRepository.put(application.getApplicationName(),application);
        LOGGER.info("{} is registered successfully",application);
        return true;
    }

    /**
     * Check status of registered application on ServiceDiscovery
     *
     * @param applicationName
     * @return Application
     */
    @Override
    public Application status(String applicationName) {
        return inMemoryRepository.get(applicationName);
    }

    /**
     * List All active application
     *
     * @return List of Application
     */
    @Override
    public List<Application> getAllActiveApplications() {
        return new ArrayList<>(inMemoryRepository.values());
    }

    /**
     * Get Application details by Name
     *
     * @param applicationName
     * @return
     */
    @Override
    public Application unregister(String applicationName) {
        return   inMemoryRepository.remove(applicationName);
    }

    @Override
    public String runningMemoryStatus(String applicationName) {
        return inMemoryRepository.get(applicationName).getState().name();
    }

    @Override

    public boolean updateState(String applicationName) {
        Optional<Application> applicationOptional= Optional.ofNullable(inMemoryRepository.get(applicationName));
        if(applicationOptional.isPresent()){
            if(applicationOptional.get().getState().equals(State.RUNNING)){
                applicationOptional.get().setState(State.STOPPED);
            }
            else if(applicationOptional.get().getState().equals(State.STOPPED)){
                applicationOptional.get().setState(State.TERMINATED);
            }
            return true;
        }
        return false;
    }
}
