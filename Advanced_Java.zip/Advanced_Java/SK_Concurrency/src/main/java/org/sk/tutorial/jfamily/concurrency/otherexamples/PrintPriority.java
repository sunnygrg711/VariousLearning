package org.sk.tutorial.jfamily.concurrency.otherexamples;

/**
 * Created by kshekar on 22/03/2018.
 */
public class PrintPriority {
}
