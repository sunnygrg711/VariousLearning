package org.sk.tutorial.jfamily.devopsutility.model;

/**
 * Created by kshekar on 04/04/2018.
 */
public class OsInfo {
    private final String operatingSystem=System.getProperty("os.name");
    private final String architecture=System.getProperty("os.arch");
    private final String operatingSystemVersion=System.getProperty("os.version");
    private final int availableProcessors=Runtime.getRuntime().availableProcessors();

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public String getArchitecture() {
        return architecture;
    }

    public String getOperatingSystemVersion() {
        return operatingSystemVersion;
    }

    public int getAvailableProcessors() {
        return availableProcessors;
    }
    private OsInfo(){}
    private static OsInfo osInfo=new OsInfo();
    public static OsInfo getInstance(){
        return osInfo;
    }

    @Override
    public String toString() {
        return "OsInfo{" +
                "operatingSystem='" + operatingSystem + '\'' +
                ", architecture='" + architecture + '\'' +
                ", operatingSystemVersion='" + operatingSystemVersion + '\'' +
                ", availableProcessors=" + availableProcessors +
                '}';
    }
}
