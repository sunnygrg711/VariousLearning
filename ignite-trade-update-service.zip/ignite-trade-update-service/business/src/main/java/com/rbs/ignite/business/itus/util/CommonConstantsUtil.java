package com.rbs.ignite.business.itus.util;

/**
 * Created by upadkti on 07/11/2017.
 */
public class CommonConstantsUtil {

  public static final String BUSINESS_DATE_FORMAT = "yyyy-MM-dd";

  public enum CORRELATION {
    SYSX("correlationId"), DAVE("correlationId "), GFX("correlationId"), ICE("correlationId");

    private String key;

    CORRELATION(String key) {
      this.key = key;
    }

    public String getKey() {
      return key;
    }
  }

}
