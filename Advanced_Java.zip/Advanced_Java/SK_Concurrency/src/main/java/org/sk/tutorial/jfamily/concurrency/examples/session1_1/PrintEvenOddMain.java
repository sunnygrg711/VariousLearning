package org.sk.tutorial.jfamily.concurrency.examples.session1_1;

/**
 * Created by kshekar on 07/05/2018.
 */
public class PrintEvenOddMain {
    public static void main(String[] args) {
        EvenOddFlagger evenOddFlagger=new EvenOddFlagger();
        Thread printEven=new PrintEven(evenOddFlagger);
        Thread printOdd=new PrintOdd(evenOddFlagger);
        printEven.start();
        printOdd.start();
    }
}
