package com.rbs.ignite.business.itus.transformer.ice.converter;

import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by upadkti on 20/12/2017.
 */
public class TotvTradeToIceRequestConverterTest {

  private TotvTradeToIceRequestConverter testObj;

  @Before
  public void setup() {
    testObj = new TotvTradeToIceRequestConverter();
  }

  @Test
  public void testConvert() {
    TotvTrade inputTrade = new TotvTrade("ISIN12345","tradeId12345", ItusTradeSourceSystem.ICE,"LDN");
    TotvIceRequest outputIceRequet = testObj.convert(inputTrade);

    Assert.assertEquals(outputIceRequet.getIsin(),"ISIN12345");
    Assert.assertEquals(outputIceRequet.getTransactionIdentifier(),"tradeId12345");
  }

  @Test
  public void testConvert_NoTradeIdentifierAndIsin() {
    TotvTrade inputTrade = new TotvTrade(null,null, ItusTradeSourceSystem.ICE,"LDN");
    TotvIceRequest outputIceRequet = testObj.convert(inputTrade);

    Assert.assertEquals(outputIceRequet.getIsin(),"");
    Assert.assertEquals(outputIceRequet.getTransactionIdentifier(),"");
  }

}
