package com.rbs.ignite.business.itus.transformer.totv.converter;


import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import org.springframework.core.convert.converter.Converter;

/**
 * Created by kumaunn on 13/11/2017.
 */
public class TotvInstrumentDataToISINConverter implements Converter<TotvInstrumentData, String> {

  @Override
  public String convert(TotvInstrumentData totvInstrument) {
    return totvInstrument.getIsin() == null ? null : totvInstrument.getIsin();
  }
}