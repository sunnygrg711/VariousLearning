package com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds;

/**
 * Created by upadkti on 10/11/2017.
 */
public class Identifier {
  private String siteId;
  private String tradeId;

  public Identifier(String siteId, String tradeId) {
    this.siteId = siteId;
    this.tradeId = tradeId;
  }

  public String getSiteId() {
    return siteId;
  }

  public void setSiteId(String siteId) {
    this.siteId = siteId;
  }

  public String getTradeId() {
    return tradeId;
  }

  public void setTradeId(String tradeId) {
    this.tradeId = tradeId;
  }

  @Override
  public boolean equals(Object o) {
    if(this==o) return true;
    if(o==null||getClass()!=o.getClass()) return false;

    Identifier that = (Identifier) o;

    if(siteId!=null ? !siteId.equals(that.siteId) : that.siteId!=null) return false;
    return tradeId!=null ? tradeId.equals(that.tradeId) : that.tradeId==null;
  }

  @Override
  public int hashCode() {
    int result = siteId!=null ? siteId.hashCode() : 0;
    result = 31*result+(tradeId!=null ? tradeId.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "Identifier{"+
      "siteId='"+siteId+'\''+
      ", tradeId='"+tradeId+'\''+
      '}';
  }
}
