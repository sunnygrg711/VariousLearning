package org.sk.tutorial.jfamily.devopsutility.model;

import org.sk.tutorial.jfamily.devopsutility.CommonUtil;

import java.io.File;

/**
 * Created by kshekar on 04/04/2018.
 */
public class HeapDumpInfo {

    private  String fileLocation=System.getProperty("user.home");
    private boolean isOverride;
    private String getFileLocation() {
        if(!isOverride){
            isOverride=true;
            fileLocation+= File.separator+"DevOpsUtility";
            new File(fileLocation).mkdir();
        }
        return fileLocation;
    }


    public String getFileName() {
        return getFileLocation()+File.separator+"HeapDump_Live_"+ CommonUtil.getDateInKeyFormat()+".hprof";
    }
}
