package com.rbs.ignite.domain.itus.irs;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TotvIRSResponse {

  private final Set<TotvIRSInstrumentIdentifier> isins;

 public TotvIRSResponse(@JsonProperty("identifiers")Set<TotvIRSInstrumentIdentifier> isins) {
    this.isins = isins;
  }
  public Set<TotvIRSInstrumentIdentifier> getIsins() {
    return isins;
  }

  @Override
  public String toString() {
    return "TotvIrsResponse{" +
            "isins=" + isins +
            '}';
  }
}
