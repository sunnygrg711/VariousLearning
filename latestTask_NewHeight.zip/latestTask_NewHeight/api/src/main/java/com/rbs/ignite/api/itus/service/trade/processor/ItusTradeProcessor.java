package com.rbs.ignite.api.itus.service.trade.processor;


import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.ItusTradeHolder;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatusHolder;

public interface ItusTradeProcessor<TradeHolder extends ItusTradeHolder, TradeStatusHolder extends ItusTradeStatusHolder> {
    TradeStatusHolder processTrades(TradeHolder tradeHolder, String requestId, Boolean byPassThreshold) throws ItusException;
}
