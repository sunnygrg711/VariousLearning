package org.sk.tutorial.jfamily.concurrency.examples.session3_1;

import java.util.concurrent.CountDownLatch;

public class GameRunner extends Thread {

    private CountDownLatch timer;

    public GameRunner(String name, CountDownLatch timer) {
        super(name);
        this.timer = timer;
        System.out.println(name+" is ready and waiting for count down.");
    }

    @Override
    public  void run(){
        try {
            timer.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(getName()+" is running.");
    }
}
