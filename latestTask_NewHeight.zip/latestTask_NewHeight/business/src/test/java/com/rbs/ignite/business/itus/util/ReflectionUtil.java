package com.rbs.ignite.business.itus.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * Created by upadkti on 15/11/2017.
 */
public class ReflectionUtil {

  public static void setPrivateField(Class clazz, Object obj, String fieldname, String fieldValue) throws NoSuchFieldException, IllegalAccessException {
    Field f1 = obj.getClass().getDeclaredField(fieldname);
    f1.setAccessible(true);
    f1.set(obj, fieldValue);
  }
  public static void setPrivateField(Class clazz, Object obj, String fieldname, int fieldValue) throws NoSuchFieldException, IllegalAccessException {
    Field f1 = obj.getClass().getDeclaredField(fieldname);
    f1.setAccessible(true);
    f1.set(obj, fieldValue);
  }

  public static void setPrivateField(Class clazz, Object obj, String fieldname, boolean fieldValue) throws NoSuchFieldException, IllegalAccessException {
    Field f1 = obj.getClass().getDeclaredField(fieldname);
    f1.setAccessible(true);
    f1.set(obj, fieldValue);
  }

  public static void setPrivateField(Class clazz, String fieldname, Object newValue) throws NoSuchFieldException, IllegalAccessException {
    Field field  = clazz.getDeclaredField( fieldname );
    Field modifiersField = Field.class.getDeclaredField( "modifiers" );
    modifiersField.setAccessible( true );
    modifiersField.setInt( field, field.getModifiers() & ~Modifier.FINAL );
    field.setAccessible( true );
    field.set( null, newValue );
  }
}
