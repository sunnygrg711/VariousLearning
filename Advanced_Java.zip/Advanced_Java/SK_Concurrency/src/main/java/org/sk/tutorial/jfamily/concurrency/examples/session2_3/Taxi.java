package org.sk.tutorial.jfamily.concurrency.examples.session2_3;

import org.sk.tutorial.jfamily.concurrency.annotation.GuardedBy;

import java.awt.*;

public class Taxi {
    @GuardedBy(name="this")
    private Point location, destination;
    private final Dispatcher dispatcher;

    public Taxi(Dispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    public synchronized Point getLocation() {
        return location;
    }
    public synchronized void setLocation(Point location) {
        this.location = location;
        if (location.equals(destination))
            dispatcher.notifyAvailable(this);
    }
}