package com.rbs.ignite.business.itus.util;

import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.UUID;

public class WebServiceUtil {

  public static HttpHeaders getHttpHeaders(TokenProviderService service, CommonConstantsUtil.CORRELATION correlationId) {
    return getHttpHeaders("Authorization", service, correlationId);
  }

  public static HttpHeaders getHttpHeaders(String headerKey, TokenProviderService service, CommonConstantsUtil.CORRELATION correlationId) {
    HttpHeaders headers = new HttpHeaders();
    if (correlationId == CommonConstantsUtil.CORRELATION.ICE) {
      headers.add(headerKey, service.getToken());
      headers.setContentType(MediaType.APPLICATION_JSON);
    } else {
      headers.add(headerKey, getAuthorizationHeader(correlationId, service));
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.add(correlationId.getKey(), UUID.randomUUID().toString());
    }
    return headers;
  }

  public static String getAuthorizationHeader(CommonConstantsUtil.CORRELATION correlationId, TokenProviderService tokenService) {
    return new String("SSO " + new String(Base64.encodeBase64(("ssoToken:" + tokenService.getToken()).getBytes())));
  }

  public static HttpHeaders getHttpHeadersWithBasicAuth(TokenProviderService service) {
    HttpHeaders headers = new HttpHeaders();
    headers.add("Authorization", "Basic " + new String(Base64.encodeBase64((":" + service.getToken()).getBytes())));
    headers.setContentType(MediaType.APPLICATION_JSON);
    return headers;
  }
}
