package com.rbs.ignite.business.itus.service.trade.processor.totv.gfx;

import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxRequest;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxResponse;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by kumaunn on 13/11/2017.
 */

@RunWith(MockitoJUnitRunner.class)
public class TotvGfxSingleTradeProcessorTest {

  @Mock
  private TokenProviderService tokenProviderService;

  @InjectMocks
  private TotvGfxSingleTradeProcessor gfxSingleTradeProcessor = new TotvGfxSingleTradeProcessor("url", TotvGfxResponse.class, tokenProviderService);

  @Mock
  private ItusTransformer totvTradeToGfxReqTransformer;

  @Mock
  private RestTemplate restTemplate;

  @Mock
  TotvTrade totvTrade;

  private HttpHeaders headers = new HttpHeaders();
  private TotvGfxRequest tradeInput = new TotvGfxRequest();

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testProcessTrade() throws Exception {
    TotvGfxResponse res = new TotvGfxResponse();
    tradeInput.setTransactionIdentifier("gfxIdentifier");
    res.setSuccess("true");

    ResponseEntity responseEntity = new ResponseEntity(res, HttpStatus.ACCEPTED);
    Mockito.when(totvTradeToGfxReqTransformer.transform(Mockito.any())).thenReturn(tradeInput);
    TotvTradeStatus status = null;
          when(restTemplate.exchange(Mockito.anyString(),
              Mockito.any(),
              Mockito.any(),
              Mockito.any(Class.class),
              Mockito.anyMap())
      )
              .thenReturn(responseEntity);

    status = gfxSingleTradeProcessor.processTrade(totvTrade);
    assertEquals("true", status.getServiceResponseCode());
    assertEquals("ACCEPTED", status.getStatus().name());

    res.setSuccess("false");
    res.setErrorMessage("error while processing request");
    responseEntity = new ResponseEntity(res, HttpStatus.ACCEPTED);
    Mockito.when(totvTradeToGfxReqTransformer.transform(Mockito.any())).thenReturn(tradeInput);
     status = null;
    when(restTemplate.exchange(Mockito.anyString(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(Class.class),
            Mockito.anyMap())
    )
            .thenReturn(responseEntity);

    status = gfxSingleTradeProcessor.processTrade(totvTrade);
    assertEquals("false", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }

  @Test
  public void testProcessTradeException() throws Exception {
    tradeInput.setTransactionIdentifier("gfxIdentifier");

    Mockito.when(totvTradeToGfxReqTransformer.transform(totvTrade)).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    when(restTemplate.exchange(Mockito.anyString(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(Class.class),
            Mockito.anyMap())
    )
            .thenThrow(Exception.class);

    status = gfxSingleTradeProcessor.processTrade(totvTrade);
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }

  @Test
  public void testProcessTradeFailure() throws Exception {
    tradeInput.setTransactionIdentifier("");
    Mockito.when(totvTradeToGfxReqTransformer.transform(totvTrade)).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    status = gfxSingleTradeProcessor.processTrade(totvTrade);
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }

  @Test
  public void testProcessTradeWhenNullResponse() throws Exception {
    tradeInput.setTransactionIdentifier("gfxIdentifier");
    Mockito.when(totvTradeToGfxReqTransformer.transform(Mockito.any(TotvTrade.class))).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    Mockito.when(restTemplate.exchange(Mockito.anyString(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(Class.class),
            Mockito.anyMap())
    ).thenReturn(null);
    status = gfxSingleTradeProcessor.processTrade(totvTrade);
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());

  }

  @After
  public void tearDown() {
    gfxSingleTradeProcessor = null;
  }
}
