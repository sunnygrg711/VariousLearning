package com.rbs.ignite.business.itus.configurer;

import com.rbs.ignite.business.itus.configurer.totv.SsoToRssRoleAdapter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.rbs.gbm.rates.core.auth.security.AuthenticationService;
import com.rbs.gbm.rates.core.auth.security.CachedAuthenticationService;
import com.rbs.gbm.rates.core.auth.security.SSOAuthenticationService;
import com.rbs.rates.foundation.security.SecurityProvider;
import com.rbs.rates.foundation.security.rss.CachedRssClientProxy;
import com.rbs.rates.foundation.security.rss.RssClient;
import com.rbs.rates.foundation.security.rss.RssClientProxy;
import com.rbs.rates.foundation.security.rss.RssUserResponseDeserializer;
import com.rbs.rates.foundation.security.spring.BaseSecurityConfigurer;

/**
 * An implementation of {@link BaseSecurityConfigurer} for the exemplar service. Defines the secured URL pattern and allocates the 
 * {@link SecurityProvider} to the parent so that all authentication and authorization calls for this service are handled by
 * that provider.  
 */
@Configuration
public class IgniteTradeUpdateServiceAuthenticationAndAuthorisationConfigurer {

  @Value("${rss.user.detail.url}")
  private String rssUserDetailURL;

  @Value("${sso.url}")
  private String ssoUrl;

  @Value("${sso.read.permission.name}")
  private String ssoReadPermissionName;

  @Value("${sso.write.permission.name}")
  private String ssoWritePermissionName;

  @Bean
  public SecurityProvider securityProvider(AuthenticationService authenticationService) {
    return new SecurityProvider(authenticationService, getRoleProvider(authenticationService), ssoReadPermissionName);
  }

  private RssClient getRoleProvider(AuthenticationService authenticationService) {
    return new SsoToRssRoleAdapter(authenticationService, ssoReadPermissionName, ssoWritePermissionName);
  }

  @Bean
  public AuthenticationService authenticationService() {
    return new CachedAuthenticationService(new SSOAuthenticationService(ssoUrl));
  }
}