package com.rbs.ignite.domain.itus.request;

/**
 * Created by upadkti on 10/11/2017.
 */
public interface RequestEntity {
}
