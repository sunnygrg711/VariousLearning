package org.sk.tutorial.jfamily.concurrency.examples.session1_3.app;

import org.sk.tutorial.jfamily.concurrency.annotation.NotThreadSafe;

/**
 * Created by kshekar on 23/04/2018.
 */
@NotThreadSafe(reason = "Compiler is doing reordering for operations.Don't confuse with Main Method which it itself a thread.")
public class ReorderingIssue {
    private  static boolean visible;
    private static int myValue;

    public static void main(String[] args) {
        new Reader().start();
        visible=true;
        myValue=10;
       /* int counter=100;
        while (counter-->0){
            new Reader().start();

            myValue=counter;
        }
*/
    }
   static class Reader extends Thread{
        @Override
        public void run(){
            while (!visible)
                yield();
            System.out.println(myValue);
        }
    }
}
