package com.rbs.ignite.domain.itus.trade;



import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import java.util.Set;

public interface ItusTradeHolder {
    ItusTradeSourceSystem getTradeSourceSystem();
    Set<? extends ItusTrade> getTradeSet();
}
