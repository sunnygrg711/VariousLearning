package com.rbs.ignite.business.itus.configurer.totv;

import com.google.common.collect.Maps;
import com.rbs.ignite.business.itus.configurer.JMXAuthenticatorImpl;
import com.rbs.rates.foundation.security.SecurityProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.jmx.support.ConnectorServerFactoryBean;
import org.springframework.remoting.rmi.RmiRegistryFactoryBean;

import javax.management.MalformedObjectNameException;
import javax.management.remote.JMXAuthenticator;
import javax.management.remote.JMXConnectorServer;
import java.util.Map;

@Configuration
public class TotvJmxConfigurer {

  @Value("${jmx.rmi.port}")
  private int jmxRmiPort;

  @Bean
  public RmiRegistryFactoryBean rmiRegistry() {
    RmiRegistryFactoryBean rmiRegistryFactoryBean = new RmiRegistryFactoryBean();
    rmiRegistryFactoryBean.setPort(jmxRmiPort);
    rmiRegistryFactoryBean.setAlwaysCreate(false);
    return rmiRegistryFactoryBean;
  }

  @Bean
  public JMXAuthenticator jmxAuthenticator(SecurityProvider securityProvider) {
    return new JMXAuthenticatorImpl(securityProvider);
  }

  @Bean
  @DependsOn("rmiRegistry")
  public ConnectorServerFactoryBean connectorServerFactoryBean(JMXAuthenticator jmxAuthenticator) throws MalformedObjectNameException{
    Map<String, Object> env = Maps.newHashMap();
    env.put(JMXConnectorServer.AUTHENTICATOR, jmxAuthenticator);

    ConnectorServerFactoryBean connectorServerFactoryBean = new ConnectorServerFactoryBean();
    connectorServerFactoryBean.setObjectName("connector:name=rmi");
    connectorServerFactoryBean.setEnvironmentMap(env);

    String url = String.format("service:jmx:rmi:///jndi/rmi://:%s/jmxrmi", jmxRmiPort);
    connectorServerFactoryBean.setServiceUrl(url);
    return connectorServerFactoryBean;
  }
}