package org.sk.tutorial.jfamily.concurrency.examples.session1_2;


import org.sk.tutorial.jfamily.concurrency.annotation.ThreadSafe;

import java.util.concurrent.atomic.AtomicLong;

@ThreadSafe
public class VisitCounterByAtomic {
    private AtomicLong counter = new AtomicLong();

    public void service(int data, Object object) {
        counter.incrementAndGet();
        validate(data, object);
        doAction(data);
        endProcess(object);

    }

    public Long getCounter() {
        return counter.get();
    }

    private void endProcess(Object object) {
    }

    private void doAction(int data) {

    }

    private void validate(int data, Object object) {

    }
}
