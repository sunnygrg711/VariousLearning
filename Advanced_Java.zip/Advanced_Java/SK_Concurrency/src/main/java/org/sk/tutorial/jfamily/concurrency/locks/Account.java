package org.sk.tutorial.jfamily.concurrency.locks;

/**
 * Created by kshekar on 22/03/2018.
 */
public class Account {
    private int accountId;
    private String accountHolderName;
    private double balanceAmount;

    public Account(int accountId, String accountHolderName, double balanceAmount) {
        this.accountId = accountId;
        this.accountHolderName = accountHolderName;
        this.balanceAmount = balanceAmount;
    }

    public int getAccountId() {
        return accountId;
    }


    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public double getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(double balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    @Override
    public String toString() {
        return accountHolderName + "( with balance :" +  Math.round(balanceAmount) + ")";
    }
}
