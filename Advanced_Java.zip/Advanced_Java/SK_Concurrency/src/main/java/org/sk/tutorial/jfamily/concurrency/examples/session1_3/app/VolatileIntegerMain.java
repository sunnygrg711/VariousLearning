package org.sk.tutorial.jfamily.concurrency.examples.session1_3.app;


import org.sk.tutorial.jfamily.concurrency.examples.session1_3.VolatileIntegerPojo;

/**
 * Created by kshekar on 23/04/2018.
 */
public class VolatileIntegerMain {

    public static void main(String[] args) throws InterruptedException {
        int counter=2000;
        while(counter-->0){
            final VolatileIntegerPojo integerPojo=new VolatileIntegerPojo();
            Thread threadSetter=new Thread(()->{
                integerPojo.setValue(10);
            },"Setter"+counter);
            Thread threadGetter=new Thread(()->{
                System.out.println(Thread.currentThread()+":"+integerPojo.getValue());
            },"Getter"+counter);
                threadSetter.start();
                threadGetter.start();

        }

    }
}
