package org.sk.tutorial.jfamily.concurrency.examples.session1_2.app;

import org.sk.tutorial.jfamily.concurrency.examples.session1_2.HugeObject;
import org.sk.tutorial.jfamily.concurrency.examples.session1_2.LazyInitHugeObject;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * Created by kshekar on 23/04/2018.
 */
public class LazyInitHugeObjectMain {


    public static void main(String[] args) throws InterruptedException {
        int repetition =10000;
        while(repetition-->0){
            final HugeObject[] hugeObjects=new HugeObject[100];
            CountDownLatch countDownLatch=new CountDownLatch(hugeObjects.length);
            final LazyInitHugeObject lazyInitHugeObject=new LazyInitHugeObject();
            ExecutorService executors= Executors.newFixedThreadPool(5);
            for(int i=0;i<hugeObjects.length;i++){
                final int iFinal=i;
                executors.submit(()->{
                    hugeObjects[iFinal]=lazyInitHugeObject.getHugeObject();
                    countDownLatch.countDown();
                });
            }
            countDownLatch.await();
            executors.shutdown();
            List<String> hugeObjectList=Arrays.asList(hugeObjects).stream().map(HugeObject::toString).distinct().collect(Collectors.toList());
            System.out.println(hugeObjectList);

        }
        System.out.println("Done!");
    }

}
