package com.rbs.ignite.business.itus.transformer.systemx.converter;


import com.rbs.ignite.domain.itus.trade.totv.systemx.TotvSystemXRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

/**
 * Created by kumaunn on 13/11/2017.
 */
public class TotvTradeToSystemXReqConverter implements Converter<TotvTrade, TotvSystemXRequest> {
  private static Logger logger = LoggerFactory.getLogger(TotvTradeToSystemXReqConverter.class);

  @Override
  public TotvSystemXRequest convert(TotvTrade totvTrade) {
    TotvSystemXRequest totvSystemxRequest = new TotvSystemXRequest();
    if (totvTrade.getTradeIdentifier() != null)
      totvSystemxRequest.setTransactionIdentifier(totvTrade.getTradeIdentifier());
    else {
      totvSystemxRequest.setTransactionIdentifier("");
    }
    logger.debug("Converted systemx Request is : {}", totvSystemxRequest);
    return totvSystemxRequest;
  }
}
