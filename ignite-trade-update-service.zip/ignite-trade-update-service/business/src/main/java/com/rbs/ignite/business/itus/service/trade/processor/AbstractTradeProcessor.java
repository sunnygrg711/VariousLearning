package com.rbs.ignite.business.itus.service.trade.processor;

import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTaskCallable;
import com.rbs.ignite.business.itus.service.trade.task.totv.TotvTradeTask;
import com.rbs.ignite.domain.itus.enums.BeanName;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatusHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

/**
 * Created by upadkti on 08/11/2017.
 */
public abstract class AbstractTradeProcessor implements ItusTradeProcessor<TotvTradeHolder,TotvTradeStatusHolder> {
  private static final Logger logger = LoggerFactory.getLogger(AbstractTradeProcessor.class);

  protected ExecutorService executorService;
  protected ItusSingleTradeProcessor itusSingleTradeProcessor;
  @Autowired
  private ApplicationContext context;

  public AbstractTradeProcessor(ExecutorService executorService, ItusSingleTradeProcessor itusSingleTradeProcessor) {
    this.executorService = executorService;
    this.itusSingleTradeProcessor = itusSingleTradeProcessor;
  }

  protected Set<TotvTradeStatus> call(Set<TotvTrade> totvTradeSet) throws ItusException {
    Set<TotvTradeStatus> tradeStatusSet = new LinkedHashSet<>();

    int tradeSize = totvTradeSet.size();
    logger.info("Trades Size:"+tradeSize);

    Set<Future<ItusTradeStatus>> futureSet = new LinkedHashSet<>();
    int count = 0;
    for(TotvTrade trade : totvTradeSet) {
      TotvTradeTask task = (TotvTradeTask) context.getBean(BeanName.ITUS_TRADE_TASK.getName(), trade, itusSingleTradeProcessor, new Long(++count));
      ItusTradeTaskCallable callable = (ItusTradeTaskCallable) context.getBean(BeanName.ITUS_TRADE_TASK_CALLABLE.getName(), task);
      Future<ItusTradeStatus> future = executorService.submit(callable);
      futureSet.add(future);
    }

    try {
      for(Future<ItusTradeStatus> future : futureSet) {
        try {
          TotvTradeStatus tradeStatus = (TotvTradeStatus) future.get();
          tradeStatusSet.add(tradeStatus);
        } catch(ExecutionException e) {
          throw new ItusException("Problem occured while fetching TradeStatus ", e);
        }
      }
    } catch(InterruptedException e) {
      throw new ItusException("Problem occured while waiting for TotvDaveTradeProcessor service", e);
    }
    return tradeStatusSet;
  }

}
