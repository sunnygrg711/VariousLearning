package calculator;

import base.abstractCalculator;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import tests.domain.calculatorDomainResponse;

/**
 * Created by kumaunn on 21/11/2017.
 */
public class calculatorSteps extends abstractCalculator{

  private calculatorDomainResponse response;
  @Before
  public void init(Scenario scn) {
    super.init(scn);
  }

  @Given("^I have a calculator$")
  public void calcula() throws Exception{
    System.out.println("inside calculator");
  }

  @When("^I add \"(.*)\" and \"(.*)\"$")
          public void calcula1(String no1, String no2) throws Exception{
         response =  super.addition(no1, no2);
          }

  @Then("^it should result \"(.*)\"$")
  public void validateResult(String result) {

    String res = response.getResult();
    Assert.assertEquals(res,result);
  }

  @When("^I subtract \"(.*)\" and \"(.*)\"$")
  public void subtract(String no1, String no2) {
    response = subtraction(no1,no2);
  }

  @When("^I add \\((.*)\\) and \\((.*)\\)$")
  public void performAddingWithExamples(String no1, String no2) {
    response = addition(no1,no2);
  }

  @When("^add 2 nos using \\((.*)\\) xml file$")
  public void fileAdditin(String relativePath) throws Throwable {
   response =  fileAddition(relativePath);
  }

  @When("^it should result \\((.*)\\)$")
  public void validateFileResult(String no3) {
    String res = response.getResult();
    Assert.assertEquals(res,no3);
  }
}
