package org.sk.tutorial.jfamily.devopsutility.service;

/**
 * Created by kshekar on 09/04/2018.
 */
public class LVA_Test {

    interface  Value{
        int getValue();
    }

    public static void main(String[] args) {
        int maxValue=5;
        Long startTime=System.nanoTime();
        int total=0;
        total=0;
        Value[] values=new Value[maxValue];
        values[0]=()->1;
        values[1]=()->2;
        values[2]=()->3;
        values[3]=()->4;
        values[4]=()->5;
        startTime=System.nanoTime();
        for (Value value : values) {
            total+=value.getValue();
        }
        Long endTime=System.nanoTime();
        System.out.println("Using Lambda##############");
        System.out.println("Total::"+total);
        System.out.println("Total Time in NS::"+(endTime-startTime));



        total=0;
        Value[] values1=new Value[5];

        values1[0]=new Value() {
            @Override
            public int getValue() {
                return 1;
            }
        };
        values1[1]=new Value() {
            @Override
            public int getValue() {
                return 2;
            }
        };
        values1[2]=new Value() {
            @Override
            public int getValue() {
                return 3;
            }
        };
        values1[3]=new Value() {
            @Override
            public int getValue() {
                return 4;
            }
        };
        values1[4]=new Value() {
            @Override
            public int getValue() {
                return 5;
            }
        };

      /*  for(int i=0;i<values1.length;i++) {
            final int value=i+1;
            values1[i]=new Value() {
                @Override
                public int getValue() {
                    return value;
                }
            };
        }*/
        startTime=System.nanoTime();
        for (Value value : values1) {
            total+=value.getValue();
        }
         endTime=System.nanoTime();
        System.out.println("Using Anonymous ##############");
        System.out.println("Total::"+total);
        System.out.println("Total Time in NS::"+(endTime-startTime));


    }
}
