package com.rbs.ignite.business.itus.transformer.totv.converter;

import com.google.common.collect.Lists;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.odc.access.domain.InstrumentId;
import com.rbs.odc.access.domain.InstrumentUnderlier;
import com.rbs.odc.access.domain.Location;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.ReportableInstrument;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionId;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * Created by upadkti on 20/12/2017.
 */
public class TransactionToTotvTradeConverterTest {

  private TransactionToTotvTradeConverter testObj;
  @Mock
  private Transaction transaction;
  @Mock
  private RegulatoryRegimeImpact regulatoryRegimeImpact;
  @Mock
  private ReportableInstrument reportableInstrument;
  @Mock
  private InstrumentUnderlier instrumentUnderlier;
  @Mock
  private InstrumentId instrumentId;
  @Mock
  private TransactionId transactionId;

  @Before
  public void setup() {
    testObj = new TransactionToTotvTradeConverter();
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testConvert() {
    Mockito.when(transaction.getRegulatoryRegimeImpact()).thenReturn(Lists.newArrayList(regulatoryRegimeImpact));
    Mockito.when(regulatoryRegimeImpact.getReportableInstruments()).thenReturn(Lists.newArrayList(reportableInstrument));
    Mockito.when(reportableInstrument.getInstrumentId()).thenReturn("ISIN12345");

    Mockito.when(transaction.getId()).thenReturn(transactionId);
    Mockito.when(transactionId.getSourceSystemTransactionId()).thenReturn("tradeId12345");
    Mockito.when(transactionId.getSourceSystemId()).thenReturn(SystemInstanceId.Ignite);

    Mockito.when(transaction.getLocation()).thenReturn(Location.GBLO);
    TotvTrade trade = testObj.convert(transaction);
    Assert.assertEquals("tradeId12345", trade.getTradeIdentifier());
    Assert.assertEquals("ISIN12345",trade.getIsin());
    Assert.assertEquals(trade.getItusTradeSourceSystem(),ItusTradeSourceSystem.IGNITE);
    Assert.assertEquals("GBLO",trade.getLocation());
  }

  @Test(expected = ItusFatalErrorException.class)
  public void testConvertFatalErrorException() {
    Mockito.when(transaction.getRegulatoryRegimeImpact()).thenReturn(Lists.newArrayList(regulatoryRegimeImpact));
    Mockito.when(regulatoryRegimeImpact.getReportableInstruments()).thenReturn(Lists.newArrayList(reportableInstrument));
    Mockito.when(reportableInstrument.getInstrumentId()).thenReturn("ISIN12345");

    Mockito.when(transaction.getId()).thenReturn(transactionId);
    Mockito.when(transactionId.getSourceSystemTransactionId()).thenReturn("tradeId12345");
    Mockito.when(transactionId.getSourceSystemId()).thenReturn(SystemInstanceId.RBSFiX);

    Mockito.when(transaction.getLocation()).thenReturn(Location.GBLO);
    testObj.convert(transaction);

  }
}
