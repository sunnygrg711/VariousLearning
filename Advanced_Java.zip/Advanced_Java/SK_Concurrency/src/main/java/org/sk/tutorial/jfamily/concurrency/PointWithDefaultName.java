package org.sk.tutorial.jfamily.concurrency;

public class PointWithDefaultName {
    final int x, y;
    final String name;
   public   PointWithDefaultName(int X, int Y) {
        x = X;y = Y;
        name = makeName();
    }
   protected String makeName() {
        return "[" + x + "," + y + "]";
    }
    final public String toString() {
        return name;
    }
}