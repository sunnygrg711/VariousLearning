package com.rbs.ignite.business.itus.configurer;

import com.rbs.gbm.rates.core.auth.security.AuthenticationService;
import com.rbs.ignite.business.itus.configurer.totv.SsoToRssRoleAdapter;
import com.rbs.rates.foundation.security.domain.RssUserResponse;
import com.rbs.rates.foundation.security.rss.RssClient;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Set;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SsoToRssRoleAdapterTotvTest {

  @Mock
  private AuthenticationService authenticationService;

  private String readPermission = "aReadPermission";
  private String writePermission = "aWritePermission";
  private String userName = "aUserName";
  private String token = "aToken";

  private RssClient adapter;

  @Before
  public void prepare() {
    MockitoAnnotations.initMocks(this);

    adapter = new SsoToRssRoleAdapter(authenticationService, readPermission, writePermission);
  }

  @Test
  public void willAddTheReadAndWriteRolesIfTheUserHasBothPermissions() {
    when(authenticationService.isValidToken(token, readPermission)).thenReturn(true);
    when(authenticationService.isValidToken(token, writePermission)).thenReturn(true);

    Set<String> roleNames = adapter.getRoleNames(userName, token);

    assertThat(roleNames.size(), is(2));
  }

  @Test
  public void willNotAddTheWriteRoleIfTheUserDoesNotHaveTheWritePermission() {
    when(authenticationService.isValidToken(token, readPermission)).thenReturn(true);
    when(authenticationService.isValidToken(token, writePermission)).thenReturn(false);

    Set<String> roleNames = adapter.getRoleNames(userName, token);

    assertThat(roleNames.size(), is(1));
  }

  @Test
  public void willNotAddTheWriteRoleIfTheUserDoesHaveTheWritePermission() {
    when(authenticationService.isValidToken(token, readPermission)).thenReturn(false);
    when(authenticationService.isValidToken(token, writePermission)).thenReturn(true);

    Set<String> roleNames = adapter.getRoleNames(userName, token);
    Set<String> roleNames1 = adapter.getRoleNames(userName, token);

    assertThat(roleNames.size(), is(1));
    assertThat(roleNames1.size(), is(1));
  }

  @Test
  public void getPermission() {
    RssUserResponse response = adapter.getPermissions(userName, token);
    Assert.assertNotNull(response);
  }
}