package com.rbs.ignite.business.itus.service.trade.processor.totv.systemx;

import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.service.trade.processor.totv.systemx.TotvSystemXSingleTradeProcessor;
import com.rbs.ignite.business.itus.totv.TotvStarter;
import com.rbs.ignite.business.itus.util.configurer.totv.TotvTestConfigurer;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxResponse;
import com.rbs.ignite.domain.itus.trade.totv.systemx.TotvSystemXRequest;
import com.rbs.ignite.domain.itus.trade.totv.systemx.TotvSystemXResponse;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by kumaunn on 13/11/2017.
 */

@RunWith(MockitoJUnitRunner.class)@SpringBootTest(classes = { TotvStarter.class, TotvTestConfigurer.class })
public class TotvSystemXSingleTradeProcessorTest {

  @Mock
  private TokenProviderService tokenProviderService;

  @InjectMocks
  private TotvSystemXSingleTradeProcessor systemXSingleTradeProcessor = new TotvSystemXSingleTradeProcessor("url", TotvSystemXResponse.class, tokenProviderService);

  @Mock
  private ItusTransformer totvTradeToSystemXReqTransformer;

  @Mock
  private RestTemplate restTemplate;

  @Mock
  TotvTrade totvTrade;

  @Mock
  ResponseEntity responseEntity;

  private HttpHeaders headers = new HttpHeaders();
  private TotvSystemXRequest tradeInput = new TotvSystemXRequest();

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testProcessTrade() throws Exception {
    TotvSystemXResponse res = new TotvSystemXResponse();
    tradeInput.setTransactionIdentifier("systemXIdentifier");
    res.setSuccess("true");

    ResponseEntity responseEntity = new ResponseEntity(res, HttpStatus.ACCEPTED);
    Mockito.when(totvTradeToSystemXReqTransformer.transform(Mockito.any())).thenReturn(tradeInput);
    TotvTradeStatus status = null;
          when(restTemplate.exchange(Mockito.anyString(),
              Mockito.any(),
              Mockito.any(),
              Mockito.any(Class.class),
              Mockito.anyMap())
      )
              .thenReturn(responseEntity);

    status = systemXSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("true", status.getServiceResponseCode());
    assertEquals("ACCEPTED", status.getStatus().name());
  }

  @Test
  public void testProcessTradeException() throws Exception {
    tradeInput.setTransactionIdentifier("systemXIdentifier");

    Mockito.when(totvTradeToSystemXReqTransformer.transform(totvTrade)).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    when(restTemplate.exchange(Mockito.anyString(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(Class.class),
            Mockito.anyMap())
    )
            .thenThrow(Exception.class);

    status = systemXSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }

  @Test
  public void testProcessTradeFailure() throws Exception {
    tradeInput.setTransactionIdentifier("");
    Mockito.when(totvTradeToSystemXReqTransformer.transform(totvTrade)).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    status = systemXSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }
  @Test
  public void testProcessTradeWhenNullResponseForItusTradeStatus() throws Exception {
    tradeInput.setTransactionIdentifier("gfxIdentifier");
    Mockito.when(totvTradeToSystemXReqTransformer.transform(Mockito.any(TotvTrade.class))).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    Mockito.when(restTemplate.exchange(Mockito.anyString(),
        Mockito.any(),
        Mockito.any(),
        Mockito.any(Class.class),
        Mockito.anyMap())
    ).thenReturn(responseEntity);

    Mockito.when(responseEntity.getBody()).thenReturn(null);
    status = systemXSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());

  }

  @Test
  public void testProcessTradeWhenNullResponseWhenResponseMessageNotNull() throws Exception {
    tradeInput.setTransactionIdentifier("gfxIdentifier");
    Mockito.when(totvTradeToSystemXReqTransformer.transform(Mockito.any(TotvTrade.class))).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    Mockito.when(restTemplate.exchange(Mockito.anyString(),
        Mockito.any(),
        Mockito.any(),
        Mockito.any(Class.class),
        Mockito.anyMap())
    ).thenReturn(responseEntity);

    TotvSystemXResponse response = new TotvSystemXResponse();
    response.setCorrelationId("1234");
    response.setSuccess("true");
    Mockito.when(responseEntity.getBody()).thenReturn(response);
    status = systemXSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("true", status.getServiceResponseCode());
    assertEquals("ACCEPTED", status.getStatus().name());

  }

  @After
  public void tearDown() {
    systemXSingleTradeProcessor = null;
  }
}
