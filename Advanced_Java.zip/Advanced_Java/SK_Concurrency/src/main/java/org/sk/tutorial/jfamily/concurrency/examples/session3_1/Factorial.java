package org.sk.tutorial.jfamily.concurrency.examples.session3_1;

import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

public class Factorial implements Callable<Long> {
    private long n;

    public Factorial(long n) {
        this.n = n;
    }

    public Long call() throws Exception {
        if (n <= 0) {
            throw new Exception("for finding factorial, N should be > 0");
        }
        long fact = 1;
        for (long longVal = 1; longVal <= n; longVal++) {
            fact *= longVal;
            TimeUnit.MILLISECONDS.sleep(new Random().nextInt(1000));
        }
        return fact;
    }
}