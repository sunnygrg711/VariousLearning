package com.rbs.ignite.domain.itus.enums;

/**
 * Created by puronaa on 03/10/2017.
 */
public enum QueryParamName {
  ISINSET("ISINSET"),
  ELIGIBLE("eligible"),
  TRANSACTION_STATE("transaction_state"),
  BUSINESS_DATE("business_date"),
  SOURCE_SYSTEM("source_system"), REQUEST_ID("request_id");

  private String name;

  QueryParamName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
