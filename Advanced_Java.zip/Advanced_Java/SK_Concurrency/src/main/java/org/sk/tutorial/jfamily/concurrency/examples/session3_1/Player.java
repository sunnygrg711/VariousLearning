package org.sk.tutorial.jfamily.concurrency.examples.session3_1;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

public class Player implements Runnable {

    private CyclicBarrier barrier;
    private String name;
    public Player(String name, CyclicBarrier barrier) {
        this.barrier = barrier;
        this.name=name;

    }

    @Override
    public  void run(){
        System.out.println(name+" is ready.");
        try {
            barrier.await();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
