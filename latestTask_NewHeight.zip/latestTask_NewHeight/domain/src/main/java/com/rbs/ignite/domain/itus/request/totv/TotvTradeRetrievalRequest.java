package com.rbs.ignite.domain.itus.request.totv;

import com.rbs.ignite.domain.itus.request.RequestEntity;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;

import java.time.LocalDate;
import java.util.Set;

/**
 * Created by kumaunn on 08/02/2018.
 */
public class TotvTradeRetrievalRequest implements RequestEntity {
  private String requestId;
  private LocalDate date;
  private Set<String> isins;
  private Set<ItusTradeSourceSystem> sourceSystems;
  private Set<TotvTrade> trades;
  private Boolean isDelta;

  public TotvTradeRetrievalRequest(String requestId, Boolean isDelta, LocalDate localDate, Set<String> isins, Set<ItusTradeSourceSystem> sourceSystems, Set<TotvTrade> trades) {

    this.requestId = requestId;
    this.date = localDate;
    this.isins = isins;
    this.sourceSystems = sourceSystems;
    this.trades = trades;
    this.isDelta=isDelta;
  }

  public String getRequestId() {
    return requestId;
  }

  public void setRequestId(String requestId) {
    this.requestId = requestId;
  }

  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }

  public Set<String> getIsins() {
    return isins;
  }

  public void setIsins(Set<String> isins) {
    this.isins = isins;
  }

  public Set<TotvTrade> getTrades() {
    return trades;
  }

  public void setTrades(Set<TotvTrade> trades) {
    this.trades = trades;
  }

  public Set<ItusTradeSourceSystem> getSourceSystems() {
    return sourceSystems;
  }

  public void setSourceSystems(Set<ItusTradeSourceSystem> sourceSystems) {
    this.sourceSystems = sourceSystems;
  }
  public Boolean getDelta() {
    return isDelta;
  }
  public void setDelta(Boolean delta) {
    isDelta = delta;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvTradeRetrievalRequest that = (TotvTradeRetrievalRequest) o;

    if (requestId != null ? !requestId.equals(that.requestId) : that.requestId != null) return false;
    if (date != null ? !date.equals(that.date) : that.date != null) return false;
    if (isins != null ? !isins.equals(that.isins) : that.isins != null) return false;
    if (sourceSystems != null ? !sourceSystems.equals(that.sourceSystems) : that.sourceSystems != null) return false;
    if (trades != null ? !trades.equals(that.trades) : that.trades != null) return false;
    return isDelta != null ? isDelta.equals(that.isDelta) : that.isDelta == null;
  }
  @Override
  public int hashCode() {
    int result = requestId != null ? requestId.hashCode() : 0;
    result = 31 * result + (date != null ? date.hashCode() : 0);
    result = 31 * result + (isins != null ? isins.hashCode() : 0);
    result = 31 * result + (sourceSystems != null ? sourceSystems.hashCode() : 0);
    result = 31 * result + (trades != null ? trades.hashCode() : 0);
    result = 31 * result + (isDelta != null ? isDelta.hashCode() : 0);
    return result;
  }
  @Override
  public String toString() {
    return "TotvTradeRetrievalRequest{" +
            "requestId='" + requestId + '\'' +
            ", date=" + date +
            ", isins=" + isins +
            ", sourceSystems=" + sourceSystems +
            ", trades=" + trades +
            ", isDelta=" + isDelta +
            '}';
  }
}
