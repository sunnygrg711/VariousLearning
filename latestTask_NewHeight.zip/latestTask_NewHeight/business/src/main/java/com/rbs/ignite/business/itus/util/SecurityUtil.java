package com.rbs.ignite.business.itus.util;

import com.google.common.collect.Sets;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Set;

public class SecurityUtil {

  public static Set<String> toRoleNames(Collection<? extends GrantedAuthority> authorities) {
    Set<String> roleNames = Sets.newHashSetWithExpectedSize(authorities.size());

    for (GrantedAuthority authority : authorities) {
      roleNames.add(authority.getAuthority());
    }

    return roleNames;
  }
}