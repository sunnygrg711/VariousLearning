package com.rbs.ignite.business.itus.service.trade.processor.totv.dave;


import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTaskCallable;
import com.rbs.ignite.business.itus.configurer.totv.TradeSystemToProcessorMapper;
import com.rbs.ignite.business.itus.service.trade.processor.AbstractTradeProcessor;
import com.rbs.ignite.business.itus.service.trade.task.totv.TotvTradeTask;
import com.rbs.ignite.domain.itus.enums.BeanName;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatusHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class TotvDaveTradeProcessor extends AbstractTradeProcessor {

  public static final Logger logger = LoggerFactory.getLogger(TotvDaveTradeProcessor.class);

  public TotvDaveTradeProcessor(ExecutorService executorService, ItusSingleTradeProcessor itusSingleTradeProcessor) {
    super(executorService, itusSingleTradeProcessor);
  }

  @Override
  public TotvTradeStatusHolder processTrades(TotvTradeHolder tradeHolder) throws ItusException {
    ItusTradeSourceSystem tradeSourceSystem = tradeHolder.getTradeSourceSystem();
    Set<TotvTrade> tradeSet = tradeHolder.getTradeSet();

    if (!tradeSourceSystem.equals(ItusTradeSourceSystem.DAVE)) {
      throw new ItusFatalErrorException("Trades were routed to wrong Service " + tradeSourceSystem);
    }

    TotvTradeStatusHolder totvTradeStatusHolder = null;
    if (tradeSet.isEmpty()) {
      logger.info("No trades to process for: " + tradeSourceSystem);
    } else {
      Set<TotvTradeStatus> tradeStatusSet = call(tradeHolder.getTradeSet());
      totvTradeStatusHolder = new TotvTradeStatusHolder(tradeSourceSystem, tradeStatusSet);
    }

    logger.debug("totvTradeStatusHolder: " + totvTradeStatusHolder);
    return totvTradeStatusHolder;
  }
}
