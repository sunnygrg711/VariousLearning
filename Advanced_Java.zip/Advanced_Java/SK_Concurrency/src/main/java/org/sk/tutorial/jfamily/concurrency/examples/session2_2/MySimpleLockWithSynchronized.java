package org.sk.tutorial.jfamily.concurrency.examples.session2_2;

import org.sk.tutorial.jfamily.concurrency.annotation.ThreadSafe;

@ThreadSafe
class MySimpleLockWithSynchronized {
    private boolean locked = false;
    public synchronized boolean lock() {
        if(!locked) {
            locked = true;
            return true;
        }
        return false;
    }
}