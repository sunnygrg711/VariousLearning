package com.rbs.ignite.api.itus.service.trade.processor;


import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;

/**
 * Created by upadkti on 14/11/2017.
 */
public interface ItusWebServiceInterface<Request, Response>{
    String getTradeServiceUrl();
    Class<Response> getResponseClass();
    Response getResponse(Request request);
}
