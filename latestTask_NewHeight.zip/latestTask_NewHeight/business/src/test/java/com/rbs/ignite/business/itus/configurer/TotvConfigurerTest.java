package com.rbs.ignite.business.itus.configurer;

import com.rbs.ignite.business.itus.configurer.totv.TotvConfigurer;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import org.junit.Test;
import org.springframework.context.annotation.PropertySource;

/**
 * Created by kumaunn on 31/03/2018.
 */

public class TotvConfigurerTest {

  TotvConfigurer configurer = new TotvConfigurer();

  @Test
  public void testIgniteTradeUpdateService() throws NoSuchFieldException, IllegalAccessException {
    ReflectionUtil.setPrivateField(TotvConfigurer.class,configurer,"skipTradeAmend", true);
    configurer.igniteTradeUpdateService();
  }
}
