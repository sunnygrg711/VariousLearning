package com.rbs.ignite.business.itus.service.trade.retrieval.odc.totv;

import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusQueryExecutor;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.totv.TotvStarter;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import com.rbs.ignite.business.itus.util.configurer.totv.TotvTestConfigurer;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.odc.access.domain.Transaction;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Created by upadkti on 08/11/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { TotvStarter.class, TotvTestConfigurer.class })
public class OdcTradeRetrievalServiceTest {

  @Autowired
  @InjectMocks
  private OdcTradeRetrievalService testObj;
  @Mock
  private ItusQueryExecutor<Set<Transaction>> itusQueryExecutor;
  @Mock
  private Transaction transaction;
  @Mock
  private ItusTransformer<Set<Transaction>,Set<TotvTrade>> tusTransformer;
  @Mock
  private Future future;
  private TotvTrade trade = new TotvTrade("ISIN1234567","123456789", ItusTradeSourceSystem.DAVE,"GDSLDN");

  @Rule
  public ExpectedException thrown= ExpectedException.none();

  @Before
  public void setup(){
    MockitoAnnotations.initMocks(this);
    try {
      Field executorService = testObj.getClass().getDeclaredField("executorService");
      executorService.setAccessible(true);
      executorService.set(testObj, Executors.newWorkStealingPool(5));
    } catch (Exception e) { }
  }

  @Test
  public void testRetrieveTrades_Success() throws Exception {
    Mockito.when(itusQueryExecutor.executeQuery(Mockito.any())).thenReturn(Sets.newSet(transaction));
    Mockito.when(tusTransformer.transform(Mockito.anySet())).thenReturn(Sets.newSet(trade));
    ReflectionUtil.setPrivateField(OdcTradeRetrievalService.class, testObj,"totvSourceSystem", "DAVE");
    Set<TotvTrade> tradeSet = testObj.retrieveTrades(Sets.newSet("ISIN1234567"), LocalDate.now(), Sets.newSet(),"<EMPTY>");
    Assert.assertTrue(tradeSet!= null && tradeSet.size() == 1);
    Assert.assertTrue(tradeSet.contains(trade));
  }

  @Test
  public void testRetrieveTrades_WhenBatchSizeZero() throws Exception {
    ReflectionUtil.setPrivateField(OdcTradeRetrievalService.class, testObj, "batchSize",0);
    Mockito.when(itusQueryExecutor.executeQuery(Mockito.any())).thenReturn(Sets.newSet());
    Mockito.when(tusTransformer.transform(Mockito.anySet())).thenReturn(Sets.newSet(trade));
    ReflectionUtil.setPrivateField(OdcTradeRetrievalService.class, testObj,"totvSourceSystem", "DAVE");
    Set<TotvTrade> tradeSet = testObj.retrieveTrades(Sets.newSet("ISIN56565"), LocalDate.now(), Sets.newSet(ItusTradeSourceSystem.DAVE),"1233");
    Assert.assertTrue(tradeSet!= null && tradeSet.size() == 1);
  }

  @Test
  public void testRetrieveTrades_WhenTradeSetNULL() throws Exception {
    ReflectionUtil.setPrivateField(OdcTradeRetrievalService.class, testObj, "batchSize",0);
    Mockito.when(itusQueryExecutor.executeQuery(Mockito.any())).thenReturn(null);
    Mockito.when(tusTransformer.transform(Mockito.anySet())).thenReturn(Sets.newSet(trade));
    ReflectionUtil.setPrivateField(OdcTradeRetrievalService.class, testObj,"totvSourceSystem", "DAVE");
    Set<TotvTrade> tradeSet = testObj.retrieveTrades(Sets.newSet("ISIN56565"), LocalDate.now(),null,"1233");
    Assert.assertTrue(tradeSet!= null && tradeSet.size() == 1);
  }

  @Test
  public void testRetrieveTrades_ExceptionForBlankInput() throws Exception {
    thrown.expect(ItusException.class);
    thrown.expectMessage("No input ISINs found to query trades from ODC");
    testObj.retrieveTrades(Sets.newSet(),LocalDate.now(), Sets.newSet(),"<EMPTY>");
  }

  @Test
  public void testRetrieveTrades_ExceptionForNullInput() throws Exception {
    thrown.expect(ItusException.class);
    thrown.expectMessage("No input ISINs found to query trades from ODC");
    testObj.retrieveTrades(null, LocalDate.now(), Sets.newSet(),"<EMPTY>");
  }

  @Test
  public void testRetrieveTrades_IfODCReturnsNull() throws Exception {
    ReflectionUtil.setPrivateField(OdcTradeRetrievalService.class, testObj,"totvSourceSystem", "DAVE");
    Set<TotvTrade> tradeSet = testObj.retrieveTrades(Sets.newSet("ISIN1234567"),LocalDate.now(), Sets.newSet(),"<EMPTY>");
    Assert.assertEquals(tradeSet,null);
  }
}
