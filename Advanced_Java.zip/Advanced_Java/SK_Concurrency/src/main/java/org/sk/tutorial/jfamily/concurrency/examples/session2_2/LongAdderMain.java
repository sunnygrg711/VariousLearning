package org.sk.tutorial.jfamily.concurrency.examples.session2_2;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.LongAdder;
import java.util.stream.IntStream;

/**
 * Created by kshekar on 08/05/2018.
 */
public class LongAdderMain {

    static class MyThreadFactory implements ThreadFactory{

        @Override
        public Thread newThread(Runnable r) {
            return new Thread(r);
        }
    }
    public static void main(String[] args) throws InterruptedException {
        LongAdder longAdder=new LongAdder();
        int numberOfThreads = 8;
        int numberOfIncrements = 100;
        Runnable longAdderAction= () -> {
            IntStream.range(0,numberOfIncrements).forEach(value -> longAdder.increment());
            System.out.println(Thread.currentThread());
        };
        MyThreadFactory myThreadFactory=new MyThreadFactory();
        for(int i=0;i<numberOfThreads;i++){
            myThreadFactory.newThread(longAdderAction).start();
        }
        Thread.sleep(1000);
        System.out.println("Expected count:"+(numberOfThreads*numberOfIncrements)+" and actual count:"+longAdder.sum());
        System.out.println(longAdder.sumThenReset()+"::"+longAdder.sum());
    }
}
