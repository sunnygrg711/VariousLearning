package org.sk.tutorial.jfamily.concurrency.animation;

/**
 * Created by kshekar on 23/03/2018.
 */
public class BubbleSort extends SorterRunnable {
    public BubbleSort(Double[] sortableValues, ArrayPanel arrayPanelToDisplayValues){
        super(sortableValues,arrayPanelToDisplayValues);
    }
    @Override
    void sort() {

        int firstIteratorIndex,secondIteratorIndex;
        double tempSwappingValue;
        boolean swapped;
        for(firstIteratorIndex=0;firstIteratorIndex<sortableValues.length -1;firstIteratorIndex++){
            swapped=false;
            arrayPanelToDisplayValues.setValues(sortableValues, sortableValues[firstIteratorIndex], sortableValues[firstIteratorIndex+1]);
            for (secondIteratorIndex=0;secondIteratorIndex<sortableValues.length -firstIteratorIndex -1;secondIteratorIndex++){
                arrayPanelToDisplayValues.setValues(sortableValues, sortableValues[secondIteratorIndex], sortableValues[secondIteratorIndex+1]);
                try
                {
                    if (run)
                        Thread.sleep(DELAY_IN_MILLISECOND);
                    else
                        semaphorePermits.acquire();
                }
                catch (InterruptedException exception)
                {
                    Thread.currentThread().interrupt();
                }
                if(sortableValues[secondIteratorIndex]>sortableValues[secondIteratorIndex+1]){
                    tempSwappingValue=sortableValues[secondIteratorIndex];
                    sortableValues[secondIteratorIndex]=sortableValues[secondIteratorIndex+1];
                    sortableValues[secondIteratorIndex+1]=tempSwappingValue;
                    swapped=true;

                }
            }
            if(!swapped){
                break;
            }
        }
        arrayPanelToDisplayValues.setValues(sortableValues, null, null);

    }
}
