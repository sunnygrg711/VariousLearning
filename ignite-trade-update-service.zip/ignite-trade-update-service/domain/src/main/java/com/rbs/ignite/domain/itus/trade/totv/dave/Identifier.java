package com.rbs.ignite.domain.itus.trade.totv.dave;

public class Identifier {
  private String siteId;

  private long contractId;

  public String getSiteId() {
    return siteId;
  }

  public void setSiteId(String siteId) {
    this.siteId = siteId;
  }

  public void setContractId(long contractId) {
    this.contractId = contractId;
  }

  public long getContractId() {
    return contractId;
  }

  @Override
  public String toString() {
    return "[ " + contractId + "," + siteId + " ]";
  }
}


			