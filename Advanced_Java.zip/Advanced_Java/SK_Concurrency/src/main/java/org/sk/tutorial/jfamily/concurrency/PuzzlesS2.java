package org.sk.tutorial.jfamily.concurrency;

/**
 * Created by kshekar on 18/04/2018.
 */
public class PuzzlesS2 {

    public static void main(String[] args) {
        short x = 0;
        int i = 123456;
        x += i;
      //  x = x + i;

        Object x1 = "object string ";
        String i1 = "real string";
        x1 += i1; // left-hand side object reference type != String
        System.out.println(x1);
        x1 = x1+ i1;
        System.out.println(x1);


        // \u0022 is the unicode escape for double quote (")
        System.out.println("abc\u0022.length() + \u0022b".length());


      /*  // Note: \u000A is Unicode representation of linefeed (LF);*/
        char c = 0x000A;
        char c1 = 0x0D;
        System.out.print("Hello "+c+"World!");
        System.out.print("Hello");
        System.out.print(c1);
        System.out.print("World! Again");
    }
}
