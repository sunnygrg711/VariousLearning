package org.sk.tutorial.jfamily.concurrency.locks;

import org.sk.tutorial.jfamily.concurrency.locks.Account;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
   A bank with a number of bank accounts.
*/
public class Bank
{
   /**
      Constructs the bank.
      @param n the number of accounts
      @param initialBalance the initial balance
      for each account
   */

   private final Account[] accounts;
   private Lock bankLock;
   private Condition sufficientFunds;

   public Bank(int n, double initialBalance)
   {
      accounts = new Account[n];
      for (int i = 0; i < accounts.length; i++) {
         accounts[i] = new Account(i+1,"Account_"+(i+1),initialBalance);
      }
      bankLock = new ReentrantLock();
      sufficientFunds = bankLock.newCondition();
   }

   public Account[] getAccounts() {
      return accounts;
   }

   /**
      Gets the number of accounts in the bank.
      @return the number of accounts
   */
   public int size()
   {
      return accounts.length;
   }

}
