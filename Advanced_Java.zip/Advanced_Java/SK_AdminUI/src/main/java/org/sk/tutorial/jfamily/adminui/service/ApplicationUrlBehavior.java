package org.sk.tutorial.jfamily.adminui.service;

import org.sk.tutorial.jfamily.adminui.model.Application;

/**
 * Created by kshekar on 09/04/2018.
 */
public class ApplicationUrlBehavior {

    public static String getHeartBeatUrl(Application application){
        StringBuilder url=new StringBuilder();
        url.append("http://")
                .append(application.getHostName())
                .append(":")
                .append(application.getPort())
                .append("/devOps/heartBeat");
        return url.toString();
    }
}
