package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv;

import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.dave.OdcDaveTradeQueryExecutor;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.dynamicquery.lang.FilterLanguage;
import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Set;

/**
 * Created by kumaunn on 02/04/2018.
 */
public class AbstractOdcTradeQueryExecutorTest {

  private AbstractOdcTradeQueryExecutor queryExecutor = new OdcDaveTradeQueryExecutor();
  @Test
  public void testExecuteQueryWhenWhereClausNull() {

    FilterLanguage filterLanguage = null;
    Set<Transaction> transactionSet = queryExecutor.executeQuery(filterLanguage, LocalDate.now(), "12233");
    Assert.assertEquals(transactionSet.size(), 0);
  }
}
