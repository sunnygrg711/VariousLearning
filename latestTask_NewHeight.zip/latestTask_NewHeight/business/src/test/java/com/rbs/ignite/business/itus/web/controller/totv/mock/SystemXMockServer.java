package com.rbs.ignite.business.itus.web.controller.totv.mock;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

public class SystemXMockServer {

  private int mockServerPort;

  private WireMockServer server;


  public SystemXMockServer(String systemX) {
    this.mockServerPort = MockServerUtil.getPortNumber(systemX);
    server = new WireMockServer(mockServerPort);
  }

  public WireMockServer ensureSystemXServerIsDown() {
    server.stop();
    MockServerUtil.waitTillServerStops(server, mockServerPort);
    return server;
  }

  public WireMockServer ensureSystemXResponse(String request1, String response1,String request2, String response2) {

    if (server.isRunning()) {
      server.resetAll();
    } else {
      server.start();
      MockServerUtil.waitTillServerStarts(server, mockServerPort);
    }



    try {
      server.stubFor(
              WireMock.put(WireMock.urlPathEqualTo("/api/v3/totv-amend/source-systems/SystemX/transactions/"+request1))
                      .willReturn(
                              WireMock.aResponse()
                                      .withStatus(HttpStatus.OK.value())
                                      .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                      .withBody(response1)
                      )
      );
      server.stubFor(
              WireMock.put(WireMock.urlPathEqualTo("/api/v3/totv-amend/source-systems/SystemX/transactions/"+request2))
                      .willReturn(
                              WireMock.aResponse()
                                      .withStatus(HttpStatus.OK.value())
                                      .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                      .withBody(response2)
                      )
      );
      return server;
    } catch (Exception e) {
      throw new RuntimeException(e);
    }

  }
}
