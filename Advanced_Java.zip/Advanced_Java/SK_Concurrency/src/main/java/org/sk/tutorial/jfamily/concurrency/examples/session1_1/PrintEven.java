package org.sk.tutorial.jfamily.concurrency.examples.session1_1;

/**
 * Created by kshekar on 07/05/2018.
 */
public class PrintEven extends Thread {
    private EvenOddFlagger evenOddFlagger;

    public PrintEven(EvenOddFlagger evenOddFlagger) {
        this.evenOddFlagger = evenOddFlagger;
    }

    @Override
    public void run() {
        int printCounter = 0;
        while (printCounter++ <= evenOddFlagger.getCounter()) {
            synchronized (evenOddFlagger) {
                try {
                    sleep(evenOddFlagger.getWaitingTimeInMS());
                    if (evenOddFlagger.isEvenTerm()) {
                        System.out.println(getName() + "-Even-" + printCounter);
                        evenOddFlagger.setFlag(false);
                        evenOddFlagger.notify();
                    } else {
                        evenOddFlagger.wait();
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
