package org.sk.tutorial.jfamily.concurrency.examples.session1_3;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by kshekar on 07/05/2018.
 */
public class ThreadIdGenerator {
    private static final AtomicInteger nextId = new AtomicInteger(0);
    private static final ThreadLocal<Integer> threadId=new ThreadLocal<Integer>(){
        @Override
        public Integer  initialValue(){
           return nextId.getAndIncrement();
        }
    };
    public static int get() {
        return threadId.get();
     }
}
