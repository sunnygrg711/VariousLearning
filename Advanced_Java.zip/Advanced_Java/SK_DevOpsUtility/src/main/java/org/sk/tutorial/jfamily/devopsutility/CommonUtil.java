package org.sk.tutorial.jfamily.devopsutility;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by kshekar on 04/04/2018.
 */
public class CommonUtil {
    static String javaHomePath=System.getenv("JAVA_HOME");
    private static final SimpleDateFormat DATE_FORMAT=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    private static final SimpleDateFormat DATE_FORMAT_WITHOUT_SPACE=new SimpleDateFormat("yyyyMMddhhmmss");

    /**
     * Return System date value in default format e.g 2018-03-24 11:35:30
     * @return String
     */
    public static String getDateInDefaultFormat(){
      return  DATE_FORMAT.format(new Date());
    }

    /**
     * Return System date value in default format e.g 2018-03-24 11:35:30
     * @return String
     */
    public static String getDateInKeyFormat(){
        return  DATE_FORMAT_WITHOUT_SPACE.format(new Date());
    }

    public static String getJavaHomePath() {
        if (null == javaHomePath) {
            throw new IllegalArgumentException("JAVA_HOME is not set");
        }
        return System.getenv("JAVA_HOME");
    }
}
