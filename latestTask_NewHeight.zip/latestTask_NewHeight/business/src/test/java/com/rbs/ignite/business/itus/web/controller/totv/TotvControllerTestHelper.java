package com.rbs.ignite.business.itus.web.controller.totv;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbs.ignite.domain.itus.instrument.totv.TotvIsinRetrievalResponse;
import com.rbs.ignite.domain.itus.instrument.totv.TotvResponse;
import com.rbs.ignite.domain.itus.instrument.totv.TotvTradeRetrievalResponse;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;

import java.io.IOException;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TotvControllerTestHelper {

  public static void assertResponseWhenReadOnlyEnabled(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 9);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObjectForReadOnlyMode();

    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED).containsAll(statusMap.get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED)));
    assertAllSystemItusStatusCount(totvResponse, statusMap);

  }
  private static void assertAllSystemItusStatusCount(TotvResponse totvResponse, Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap) {
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getAcceptedCount(), statusMap.get(ItusTradeSourceSystem.GFX).getAcceptedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getRejectedCount(), statusMap.get(ItusTradeSourceSystem.GFX).getRejectedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getAmendSkippedCount(), statusMap.get(ItusTradeSourceSystem.GFX).getAmendSkippedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getThresholdReachedCount(), statusMap.get(ItusTradeSourceSystem.GFX).getThresholdReachedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getRejectedCount(), statusMap.get(ItusTradeSourceSystem.SYSTEMX).getRejectedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getAcceptedCount(), statusMap.get(ItusTradeSourceSystem.SYSTEMX).getAcceptedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getAmendSkippedCount(), statusMap.get(ItusTradeSourceSystem.SYSTEMX).getAmendSkippedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getThresholdReachedCount(), statusMap.get(ItusTradeSourceSystem.SYSTEMX).getThresholdReachedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getRejectedCount(), statusMap.get(ItusTradeSourceSystem.DAVE).getRejectedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getAcceptedCount(), statusMap.get(ItusTradeSourceSystem.DAVE).getAcceptedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getAmendSkippedCount(), statusMap.get(ItusTradeSourceSystem.DAVE).getAmendSkippedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getThresholdReachedCount(), statusMap.get(ItusTradeSourceSystem.DAVE).getThresholdReachedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getAcceptedCount(), statusMap.get(ItusTradeSourceSystem.IGNITE).getAcceptedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getAmendSkippedCount(), statusMap.get(ItusTradeSourceSystem.IGNITE).getAmendSkippedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getRejectedCount(), statusMap.get(ItusTradeSourceSystem.IGNITE).getRejectedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getThresholdReachedCount(), statusMap.get(ItusTradeSourceSystem.IGNITE).getThresholdReachedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getRejectedCount(), statusMap.get(ItusTradeSourceSystem.ICE).getRejectedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getAcceptedCount(), statusMap.get(ItusTradeSourceSystem.ICE).getAcceptedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getAmendSkippedCount(), statusMap.get(ItusTradeSourceSystem.ICE).getAmendSkippedCount());
    assertEquals(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getThresholdReachedCount(), statusMap.get(ItusTradeSourceSystem.ICE).getThresholdReachedCount());

  }

  private static Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> createStatusObject() {

    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();

    TotvResponse.SystemSpecificResponse pabfxSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> pabfxStatusWiseTradeIdentifiers = pabfxSpecificResponse.getTradeIdentifiers();
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("N171219A49E0B"));
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("L171220A40488"));

    TotvResponse.SystemSpecificResponse systemXSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> systemXStatusWiseTradeIdentifiers = systemXSpecificResponse.getTradeIdentifiers();
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("17355LN024844D"));
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("17305LN024728D"));

    TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
    iceStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("192996010"));
    iceStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("192994370"));

    TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
    daveStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("118428069"));
    daveStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("118428070"));

    TotvResponse.SystemSpecificResponse igniteSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> igniteStatusWiseTradeIdentifiers = igniteSpecificResponse.getTradeIdentifiers();
    igniteStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("1117588"));

    result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
    result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
    result.put(ItusTradeSourceSystem.SYSTEMX, systemXSpecificResponse);
    result.put(ItusTradeSourceSystem.GFX, pabfxSpecificResponse);
    result.put(ItusTradeSourceSystem.IGNITE, igniteSpecificResponse);
    return result;
  }

  private static Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> createStatusObjectWhenSourceSystemsAreSpecified() {

    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();

    TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
    iceStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("192996010"));
    iceStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("192994370"));

    TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
    daveStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("118428069"));
    daveStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("118428070"));

    result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
    result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
    return result;
  }

  private static  Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> createStatusObjectForReadOnlyMode() {

    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();

    TotvResponse.SystemSpecificResponse pabfxSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> pabfxStatusWiseTradeIdentifiers = pabfxSpecificResponse.getTradeIdentifiers();
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.TRADE_AMEND_SKIPPED, Arrays.asList("N171219A49E0B", "L171220A40488"));

    TotvResponse.SystemSpecificResponse systemXSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> systemXStatusWiseTradeIdentifiers = systemXSpecificResponse.getTradeIdentifiers();
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.TRADE_AMEND_SKIPPED, Arrays.asList("17305LN024728D", "17355LN024844D"));

    TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
    iceStatusWiseTradeIdentifiers.put(ItusStatus.TRADE_AMEND_SKIPPED, Arrays.asList("192994370", "192996010"));

    TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
    daveStatusWiseTradeIdentifiers.put(ItusStatus.TRADE_AMEND_SKIPPED, Arrays.asList("118428069", "118428070"));

    TotvResponse.SystemSpecificResponse igniteSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> igniteStatusWiseTradeIdentifiers = igniteSpecificResponse.getTradeIdentifiers();
    igniteStatusWiseTradeIdentifiers.put(ItusStatus.TRADE_AMEND_SKIPPED, Arrays.asList("1117588"));

    result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
    result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
    result.put(ItusTradeSourceSystem.SYSTEMX, systemXSpecificResponse);
    result.put(ItusTradeSourceSystem.GFX, pabfxSpecificResponse);
    result.put(ItusTradeSourceSystem.IGNITE, igniteSpecificResponse);
    return result;
  }


  private static Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> createStatusObjectWhenDaveIsDown() {

    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();

    TotvResponse.SystemSpecificResponse pabfxSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> pabfxStatusWiseTradeIdentifiers = pabfxSpecificResponse.getTradeIdentifiers();
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("N171219A49E0B"));
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("L171220A40488"));

    TotvResponse.SystemSpecificResponse systemXSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> systemXStatusWiseTradeIdentifiers = systemXSpecificResponse.getTradeIdentifiers();
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("17355LN024844D"));
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("17305LN024728D"));

    TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
    iceStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("192996010"));
    iceStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("192994370"));

    TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
    daveStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("118428070", "118428069"));

    TotvResponse.SystemSpecificResponse igniteSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> igniteStatusWiseTradeIdentifiers = igniteSpecificResponse.getTradeIdentifiers();
    igniteStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("1117588"));

    result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
    result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
    result.put(ItusTradeSourceSystem.SYSTEMX, systemXSpecificResponse);
    result.put(ItusTradeSourceSystem.GFX, pabfxSpecificResponse);
    result.put(ItusTradeSourceSystem.IGNITE, igniteSpecificResponse);
    return result;
  }

  private static TotvResponse toResponseObject(String responseJson, ObjectMapper jacksonObjectMapper) throws IOException {
    return jacksonObjectMapper.readValue(responseJson, TotvResponse.class);
  }

  private static TotvTradeRetrievalResponse toTradeRetrivalResponseObject(String responseJson, ObjectMapper jacksonObjectMapper) throws IOException {
    return jacksonObjectMapper.readValue(responseJson, TotvTradeRetrievalResponse.class);
  }

  public static String createRequestFromInput(Object input, ObjectMapper jacksonObjectMapper) throws JsonProcessingException {
    String request = jacksonObjectMapper.writeValueAsString(input);
    return request;
  }

  public static void assertResponseWhenODCIsDown(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 0);
    assertTrue(totvResponse.getResult().isEmpty());
  }

  public static void assertResponseWhenIrsIsDown(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 0);
    assertTrue(totvResponse.getResult().isEmpty());
  }

  public static void assertThatResponseIsCorrect(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 9);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObject();
    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertAllSystemItusStatusCount(totvResponse, statusMap);
  }

  public static void assertThatTotvGetTradesResponseIsCorrect(String response, ObjectMapper jacksonObjectMapper) throws IOException {
      TotvTradeRetrievalResponse totvResponse = toTradeRetrivalResponseObject(response, jacksonObjectMapper);
      assertEquals(totvResponse.getStatusCode(), "OK");
      assertEquals(totvResponse.getStatusMessage(), "Success");
      assertEquals(totvResponse.getTotalCount().intValue(), 9);
      Map<ItusTradeSourceSystem, Set<TotvTrade>> statusMap = createTradeStatusObject(totvResponse.getResult());
      assertTrue(statusMap.get(ItusTradeSourceSystem.DAVE).size() == 2);
      assertTrue(statusMap.get(ItusTradeSourceSystem.IGNITE).size() == 1);
      assertTrue(statusMap.get(ItusTradeSourceSystem.ICE).size() == 2);
      assertTrue(statusMap.get(ItusTradeSourceSystem.SYSTEMX).size() == 2);
      assertTrue(statusMap.get(ItusTradeSourceSystem.GFX).size() == 2);
  }

  private static Map<ItusTradeSourceSystem, Set<TotvTrade>> createTradeStatusObject (Set<TotvTrade> trades) {
    Map<ItusTradeSourceSystem, Set<TotvTrade>> result = new HashMap<ItusTradeSourceSystem, Set<TotvTrade>>();
    trades.forEach(trade -> {
      Set<TotvTrade> tradeSet = null;
      ItusTradeSourceSystem key = trade.getItusTradeSourceSystem();
      if (result.get(key) == null) {
        tradeSet = new HashSet<TotvTrade>();
        tradeSet.add(trade);
        result.put(key, tradeSet);
      } else {
        result.get(key).add(trade);
      }
    });
    return result;
  }
  public static void assertResponseWhenDaveThresholdReached(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 9);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObjectWhenDaveThresholdReached();
    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertAllSystemItusStatusCount(totvResponse, statusMap);
  }
  private static Map<ItusTradeSourceSystem,TotvResponse.SystemSpecificResponse> createStatusObjectWhenDaveThresholdReached() {

      Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();

      TotvResponse.SystemSpecificResponse pabfxSpecificResponse = new TotvResponse.SystemSpecificResponse();
      Map<ItusStatus, List<String>> pabfxStatusWiseTradeIdentifiers = pabfxSpecificResponse.getTradeIdentifiers();
      pabfxStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("N171219A49E0B"));
      pabfxStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("L171220A40488"));

      TotvResponse.SystemSpecificResponse systemXSpecificResponse = new TotvResponse.SystemSpecificResponse();
      Map<ItusStatus, List<String>> systemXStatusWiseTradeIdentifiers = systemXSpecificResponse.getTradeIdentifiers();
      systemXStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("17355LN024844D"));
      systemXStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("17305LN024728D"));

      TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
      Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
      iceStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("192996010"));
      iceStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("192994370"));

      TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
      Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
      daveStatusWiseTradeIdentifiers.put(ItusStatus.THRESHOLD_BREACHED, Arrays.asList("118428069","118428070"));

      TotvResponse.SystemSpecificResponse igniteSpecificResponse = new TotvResponse.SystemSpecificResponse();
      Map<ItusStatus, List<String>> igniteStatusWiseTradeIdentifiers = igniteSpecificResponse.getTradeIdentifiers();
      igniteStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("1117588"));

      result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
      result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
      result.put(ItusTradeSourceSystem.SYSTEMX, systemXSpecificResponse);
      result.put(ItusTradeSourceSystem.GFX, pabfxSpecificResponse);
      result.put(ItusTradeSourceSystem.IGNITE, igniteSpecificResponse);
      return result;

  }

  public static void assertThatResponseIsCorrectWhenSourceSystemsAreSpecified(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 4);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObjectWhenSourceSystemsAreSpecified();
    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
  }

  public static void assertResponseWhenDaveIsDown(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 9);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObjectWhenDaveIsDown();
    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));


    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));

    assertAllSystemItusStatusCount(totvResponse, statusMap);

  }

  public static void assertResponseWhenGfxIsDown(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 9);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObjectWhenGfxIsDown();

    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));

    assertAllSystemItusStatusCount(totvResponse, statusMap);

  }
  private static Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> createStatusObjectWhenGfxIsDown() {

    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();
    TotvResponse.SystemSpecificResponse pabfxSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> pabfxStatusWiseTradeIdentifiers = pabfxSpecificResponse.getTradeIdentifiers();
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("N171219A49E0B", "L171220A40488"));

    TotvResponse.SystemSpecificResponse systemXSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> systemXStatusWiseTradeIdentifiers = systemXSpecificResponse.getTradeIdentifiers();
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("17355LN024844D"));
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("17305LN024728D"));

    TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
    iceStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("192996010"));
    iceStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("192994370"));

    TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
    daveStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("118428069"));
    daveStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("118428070"));

    TotvResponse.SystemSpecificResponse igniteSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> igniteStatusWiseTradeIdentifiers = igniteSpecificResponse.getTradeIdentifiers();
    igniteStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("1117588"));

    result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
    result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
    result.put(ItusTradeSourceSystem.SYSTEMX, systemXSpecificResponse);
    result.put(ItusTradeSourceSystem.GFX, pabfxSpecificResponse);
    result.put(ItusTradeSourceSystem.IGNITE, igniteSpecificResponse);
    return result;
  }

  public static  void assertResponseWhenIceIsDown(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 9);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObjectWhenIceIsDown();
    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));

    assertAllSystemItusStatusCount(totvResponse, statusMap);

  }
  private static Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> createStatusObjectWhenIceIsDown() {
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();

    TotvResponse.SystemSpecificResponse pabfxSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> pabfxStatusWiseTradeIdentifiers = pabfxSpecificResponse.getTradeIdentifiers();
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("N171219A49E0B"));
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("L171220A40488"));

    TotvResponse.SystemSpecificResponse systemXSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> systemXStatusWiseTradeIdentifiers = systemXSpecificResponse.getTradeIdentifiers();
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("17355LN024844D"));
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("17305LN024728D"));

    TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
    iceStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("192994370", "192996010"));

    TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
    daveStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("118428069"));
    daveStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("118428070"));

    TotvResponse.SystemSpecificResponse igniteSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> igniteStatusWiseTradeIdentifiers = igniteSpecificResponse.getTradeIdentifiers();
    igniteStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("1117588"));

    result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
    result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
    result.put(ItusTradeSourceSystem.SYSTEMX, systemXSpecificResponse);
    result.put(ItusTradeSourceSystem.GFX, pabfxSpecificResponse);
    result.put(ItusTradeSourceSystem.IGNITE, igniteSpecificResponse);
    return result;
  }

  public static  void assertResponseWhenSystemXIsDown(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 9);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObjectWhenSystemXIsDown();
    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));


    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));

    assertAllSystemItusStatusCount(totvResponse, statusMap);

  }
  private static  Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> createStatusObjectWhenSystemXIsDown() {

    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();

    TotvResponse.SystemSpecificResponse pabfxSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> pabfxStatusWiseTradeIdentifiers = pabfxSpecificResponse.getTradeIdentifiers();
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("N171219A49E0B"));
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("L171220A40488"));

    TotvResponse.SystemSpecificResponse systemXSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> systemXStatusWiseTradeIdentifiers = systemXSpecificResponse.getTradeIdentifiers();
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("17305LN024728D", "17355LN024844D"));

    TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
    iceStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("192996010"));
    iceStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("192994370"));

    TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
    daveStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("118428069"));
    daveStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("118428070"));

    TotvResponse.SystemSpecificResponse igniteSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> igniteStatusWiseTradeIdentifiers = igniteSpecificResponse.getTradeIdentifiers();
    igniteStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("1117588"));

    result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
    result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
    result.put(ItusTradeSourceSystem.SYSTEMX, systemXSpecificResponse);
    result.put(ItusTradeSourceSystem.GFX, pabfxSpecificResponse);
    result.put(ItusTradeSourceSystem.IGNITE, igniteSpecificResponse);
    return result;
  }
  public static void assertResponseWhenAllSystemThrReached(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 9);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObjectWhenAllSystemsThrReached();
    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED).containsAll(statusMap.get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED)));
    assertAllSystemItusStatusCount(totvResponse, statusMap);
  }
  private static Map<ItusTradeSourceSystem,TotvResponse.SystemSpecificResponse> createStatusObjectWhenAllSystemsThrReached() {
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();

    TotvResponse.SystemSpecificResponse pabfxSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> pabfxStatusWiseTradeIdentifiers = pabfxSpecificResponse.getTradeIdentifiers();
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.THRESHOLD_BREACHED, Arrays.asList("N171219A49E0B","L171220A40488"));

    TotvResponse.SystemSpecificResponse systemXSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> systemXStatusWiseTradeIdentifiers = systemXSpecificResponse.getTradeIdentifiers();
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.THRESHOLD_BREACHED, Arrays.asList("17305LN024728D", "17355LN024844D"));

    TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
    iceStatusWiseTradeIdentifiers.put(ItusStatus.THRESHOLD_BREACHED, Arrays.asList("192994370","192996010"));

    TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
    daveStatusWiseTradeIdentifiers.put(ItusStatus.THRESHOLD_BREACHED, Arrays.asList("118428069","118428070"));

    TotvResponse.SystemSpecificResponse igniteSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> igniteStatusWiseTradeIdentifiers = igniteSpecificResponse.getTradeIdentifiers();
    igniteStatusWiseTradeIdentifiers.put(ItusStatus.THRESHOLD_BREACHED, Arrays.asList("1117588"));

    result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
    result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
    result.put(ItusTradeSourceSystem.SYSTEMX, systemXSpecificResponse);
    result.put(ItusTradeSourceSystem.GFX, pabfxSpecificResponse);
    result.put(ItusTradeSourceSystem.IGNITE, igniteSpecificResponse);
    return result;
  }
  public static void assertResponseWhenSystemXThrReached(String response, ObjectMapper jacksonObjectMapper) throws IOException {
    TotvResponse totvResponse = toResponseObject(response, jacksonObjectMapper);
    assertEquals(totvResponse.getStatusCode(), "OK");
    assertEquals(totvResponse.getStatusMessage(), "Success");
    assertEquals(totvResponse.getTotalCount().intValue(), 9);
    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> statusMap = createStatusObjectWhenSystemXThrReached();
    assertEquals(totvResponse.getResult().size(), statusMap.size());
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.DAVE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED).containsAll(statusMap.get(ItusTradeSourceSystem.SYSTEMX).getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.IGNITE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));

    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.ICE).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));


    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.ACCEPTED)));
    assertTrue(totvResponse.getResult().get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED).containsAll(statusMap.get(ItusTradeSourceSystem.GFX).getTradeIdentifiersForStatus(ItusStatus.REJECTED)));

    assertAllSystemItusStatusCount(totvResponse, statusMap);
  }
  private static Map<ItusTradeSourceSystem,TotvResponse.SystemSpecificResponse> createStatusObjectWhenSystemXThrReached() {

    Map<ItusTradeSourceSystem, TotvResponse.SystemSpecificResponse> result = new HashMap<>();

    TotvResponse.SystemSpecificResponse pabfxSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> pabfxStatusWiseTradeIdentifiers = pabfxSpecificResponse.getTradeIdentifiers();
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("N171219A49E0B"));
    pabfxStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("L171220A40488"));

    TotvResponse.SystemSpecificResponse systemXSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> systemXStatusWiseTradeIdentifiers = systemXSpecificResponse.getTradeIdentifiers();
    systemXStatusWiseTradeIdentifiers.put(ItusStatus.THRESHOLD_BREACHED, Arrays.asList("17305LN024728D", "17355LN024844D"));

    TotvResponse.SystemSpecificResponse iceSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> iceStatusWiseTradeIdentifiers = iceSpecificResponse.getTradeIdentifiers();
    iceStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("192996010"));
    iceStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("192994370"));

    TotvResponse.SystemSpecificResponse daveSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> daveStatusWiseTradeIdentifiers = daveSpecificResponse.getTradeIdentifiers();
    daveStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("118428069"));
    daveStatusWiseTradeIdentifiers.put(ItusStatus.REJECTED, Arrays.asList("118428070"));

    TotvResponse.SystemSpecificResponse igniteSpecificResponse = new TotvResponse.SystemSpecificResponse();
    Map<ItusStatus, List<String>> igniteStatusWiseTradeIdentifiers = igniteSpecificResponse.getTradeIdentifiers();
    igniteStatusWiseTradeIdentifiers.put(ItusStatus.ACCEPTED, Arrays.asList("1117588"));

    result.put(ItusTradeSourceSystem.DAVE, daveSpecificResponse);
    result.put(ItusTradeSourceSystem.ICE, iceSpecificResponse);
    result.put(ItusTradeSourceSystem.SYSTEMX, systemXSpecificResponse);
    result.put(ItusTradeSourceSystem.GFX, pabfxSpecificResponse);
    result.put(ItusTradeSourceSystem.IGNITE, igniteSpecificResponse);
    return result;
  }
  public static void assertThatGetIsinsResponseIsCorrect(String response, ObjectMapper jacksonObjectMapper) throws IOException {

    TotvIsinRetrievalResponse isinsRetrivalResponse = jacksonObjectMapper.readValue(response, TotvIsinRetrievalResponse.class);
    assertEquals(isinsRetrivalResponse.getStatusCode(), "OK");
    assertEquals(isinsRetrivalResponse.getStatusMessage(), "Success");
    assertEquals(isinsRetrivalResponse.getTotalCount().intValue(), 5);
    assertTrue(isinsRetrivalResponse.getResult().containsAll(Arrays.asList("XS1234556A","EZ5MCBS7WYK2","EZV7JD6QDWD0","EZ98PRND3G05","DE0001030542")));

  }
}
