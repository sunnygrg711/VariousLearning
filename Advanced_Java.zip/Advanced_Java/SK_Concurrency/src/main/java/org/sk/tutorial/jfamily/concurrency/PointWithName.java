package org.sk.tutorial.jfamily.concurrency;

public class PointWithName extends PointWithDefaultName {
    final String name;
    public  PointWithName(int X, int Y,String name) {
        super(X,Y);
        this.name = name;
    }
   protected String makeName() {
        return super.makeName()+":"+name;
    }
    public static void main(String[] args) {
        PointWithName pointWithName=new PointWithName(255,255,"black");
        System.out.println(pointWithName);
    }
}