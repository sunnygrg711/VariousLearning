package org.sk.tutorial.jfamily.concurrency.annotation;

public @interface GuardedBy {
    String name() default "";
}
