package com.rbs.ignite.domain.itus.instrument.totv;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TotvIsinRetrievalResponse {

  private String statusCode;
  private String statusMessage;
  private Integer totalCount;
  private Set<String> result;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvIsinRetrievalResponse that = (TotvIsinRetrievalResponse) o;

    if (!statusCode.equals(that.statusCode)) return false;
    if (!statusMessage.equals(that.statusMessage)) return false;
    if (!totalCount.equals(that.totalCount)) return false;
    return result.equals(that.result);

  }

  @Override
  public int hashCode() {
    int result1 = statusCode.hashCode();
    result1 = 31 * result1 + statusMessage.hashCode();
    result1 = 31 * result1 + totalCount.hashCode();
    result1 = 31 * result1 + result.hashCode();
    return result1;
  }

  public String getStatusCode() {
    return statusCode;
  }

  public String getStatusMessage() {
    return statusMessage;
  }

  public Integer getTotalCount() {
    return totalCount;
  }

  public Set<String> getResult() {
    return result;
  }

  public TotvIsinRetrievalResponse(@JsonProperty("statusCode") String statusCode,
                                   @JsonProperty("statusMessage") String statusMessage,
                                   @JsonProperty("total") Integer totalCount,
                                   @JsonProperty("result") Set<String> result) {
    this.statusCode = statusCode;
    this.statusMessage = statusMessage;
    this.totalCount = totalCount;
    this.result = result;
  }

}
