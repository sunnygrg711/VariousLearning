package com.rbs.ignite.business.itus.service.trade;

import com.rbs.ignite.business.itus.service.instrument.totv.irs.TotvFileBasedInstrumentService;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvFileBasedInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Created by kumaunn on 01/04/2018.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({TotvFileBasedInstrumentService.class,Files.class})
@PowerMockIgnore({"javax.management.*"})
public class TotvFileBasedInstrumentServiceTest {

  @Mock
  private Stream stream;

  TotvFileBasedInstrumentService service = new TotvFileBasedInstrumentService();

  @Test
  public void testGetInstrumentData() throws ItusException{

    Set<TotvInstrumentData> totvInstrumentData = service.getInstrumentData(new TotvFileBasedInstrumentInput("logback.xml"), "123233", false);
    Assert.assertTrue(totvInstrumentData.size() > 0);
  }

  @Test
  public void testGetInstrumentDataException() throws ItusException, URISyntaxException, IOException{
    PowerMockito.mockStatic(Files.class);
    Files files = PowerMockito.mock(Files.class);
    PowerMockito.when(files.exists(Mockito.any(Path.class))).thenReturn(true);
    PowerMockito.when(files.lines(Mockito.any(Path.class))).thenReturn(stream);

    Set<TotvInstrumentData> totvInstrumentData = service.getInstrumentData(new TotvFileBasedInstrumentInput("logback.xml"), "123233", false);
    Assert.assertTrue(totvInstrumentData.size() == 0);
  }
}
