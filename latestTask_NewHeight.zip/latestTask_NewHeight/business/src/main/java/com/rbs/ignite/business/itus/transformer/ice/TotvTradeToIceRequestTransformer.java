package com.rbs.ignite.business.itus.transformer.ice;


import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;

/**
 * Tranformer class which uses conversion utility to convert totv trade to ICE
 */
public class TotvTradeToIceRequestTransformer implements ItusTransformer<TotvTrade, TotvIceRequest> {

  @Autowired
  ConversionService conversionService;

  @Override
  public TotvIceRequest transform(TotvTrade totvTrade) throws ItusTransformException {
    TypeDescriptor sourceType = TypeDescriptor.valueOf(TotvTrade.class);
    TypeDescriptor targetType = TypeDescriptor.valueOf(TotvIceRequest.class);
    TotvIceRequest totvIceRequest = (TotvIceRequest) conversionService.convert(totvTrade, sourceType, targetType);
    return totvIceRequest;
  }
}
