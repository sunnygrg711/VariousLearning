package org.sk.tutorial.jfamily.adminui.service;

/**
 * Created by kshekar on 03/04/2018.
 */
public interface JMHService {

}
