package com.rbs.ignite.business.itus.service.trade.processor.totv;


import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessingService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessorCallable;
import com.rbs.ignite.business.itus.configurer.totv.TradeSystemToProcessorMapper;
import com.rbs.ignite.business.itus.jmx.TotvJmxProvider;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatusHolder;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class TotvTradeProcessingService implements ItusTradeProcessingService<TotvTrade,ItusTradeStatus> {
  private static final Logger logger = LoggerFactory.getLogger(TotvTradeProcessingService.class);
  @Autowired
  private TradeSystemToProcessorMapper tradeSystemToProcessorMapper;
  @Autowired
  private TotvJmxProvider totvJmxProvider;

  private ExecutorService executorService;

  public TotvTradeProcessingService(ExecutorService executorService) {
    this.executorService = executorService;
  }


  @Override
  public Set<ItusTradeStatus> processTrades(Set<TotvTrade> totvTradeSet, String requestId, Boolean byPassThreshold) throws ItusException {
    Set<ItusTradeStatus> result =  new LinkedHashSet<>();
    if(totvTradeSet == null || totvTradeSet.isEmpty()){
      logger.info(requestId+":"+"No Trades found to process...");
      return result;
    }
    Map<ItusTradeSourceSystem, TotvTradeHolder> tradeSystemToTradesMap = getTradeSystemToTotvTradeHolderMap(totvTradeSet);

    if (totvJmxProvider.getReadOnlyMode()) {
      logger.info(requestId+":"+"Trade Amending is skipped as configured.");
      final Set<TotvTradeStatus> tradeStatusSet = new HashSet<>();
      tradeSystemToTradesMap.forEach( (tradeSystem,tradeHolder)->{
        Set<TotvTrade> tradeSet = tradeHolder.getTradeSet();
        final Set<TotvTradeStatus> tradeStatusSetPerSystem = new HashSet<>();
        tradeSet.forEach((trade)->{
          tradeStatusSet.add(new TotvTradeStatus.TotvTradeStatusBuilder(trade, ItusStatus.TRADE_AMEND_SKIPPED,"-1").build());
        });
      });
      result.addAll(tradeStatusSet);
      return result;
    }
    List<Future<ItusTradeStatusHolder>> futures = new ArrayList<>();
    tradeSystemToTradesMap.keySet().forEach((sourceSystem)->{
      try {
        ItusTradeProcessor processor = tradeSystemToProcessorMapper.getProcessor(sourceSystem);
        Callable<ItusTradeStatusHolder> callableProcessor = new ItusTradeProcessorCallable(processor, tradeSystemToTradesMap.get(sourceSystem),requestId,byPassThreshold);
        Future<ItusTradeStatusHolder> future = executorService.submit(callableProcessor);
        futures.add(future);
      } catch(RuntimeException ex) {
        logger.warn(requestId+":"+"Error occurred while processing trades for " + sourceSystem + ". Skipping..." + ex);
      }
    });

    futures.forEach((future)->{
      ItusTradeStatusHolder totvTradeStatusHolder;
      ItusTradeSourceSystem sourceSystem = null;
      try {
        totvTradeStatusHolder = future.get();
        Set<TotvTradeStatus> tradeStatusSet = totvTradeStatusHolder.getTradeStatusSet();
        sourceSystem = totvTradeStatusHolder.getTradeSourceSystem();

        logger.debug(requestId+":"+"Trades processed for source system {}: {} ", sourceSystem, tradeStatusSet);
        if(tradeStatusSet!=null&&!tradeStatusSet.isEmpty()) {
          result.addAll(tradeStatusSet);
        }
      } catch(ExecutionException | InterruptedException ex) {
        logger.warn(requestId+":"+"Error occurred while processing trades for " + sourceSystem + ". Skipping..." + ex);
      }
    });

    return result;
  }

  private Map<ItusTradeSourceSystem,TotvTradeHolder> getTradeSystemToTotvTradeHolderMap(Set<TotvTrade> totvTradeSet) throws ItusException {
    Map<ItusTradeSourceSystem,Set<TotvTrade>> sourceSystemVsTradesMap = new HashMap<>();
    totvTradeSet.forEach((trade)->{
      Set<TotvTrade> tradeSet = sourceSystemVsTradesMap.get(trade.getItusTradeSourceSystem());
      if(tradeSet == null) {
        tradeSet = new HashSet<>();
        tradeSet.add(trade);
        sourceSystemVsTradesMap.put(trade.getItusTradeSourceSystem(),tradeSet);
      } else {
        sourceSystemVsTradesMap.get(trade.getItusTradeSourceSystem()).add(trade);
      }
    });

    Map<ItusTradeSourceSystem, TotvTradeHolder> result =  new HashMap<>();
    sourceSystemVsTradesMap.keySet().forEach((tradeSystem)->{
      Set<TotvTrade> tradeSet = sourceSystemVsTradesMap.get(tradeSystem);
      TotvTradeHolder tradeHolder = new TotvTradeHolder(tradeSystem,tradeSet);
      result.put(tradeSystem,tradeHolder);
    });
    return result;
  }
}
