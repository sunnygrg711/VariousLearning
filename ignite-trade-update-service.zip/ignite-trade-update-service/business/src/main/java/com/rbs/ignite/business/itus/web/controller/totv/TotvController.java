package com.rbs.ignite.business.itus.web.controller.totv;


import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.rbs.ignite.api.itus.service.trade.IgniteTradeUpdateService;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.*;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by puronaa on 14/09/2017.
 */
@RestController
public class TotvController implements ItusClientController {

  private static Logger logger = LoggerFactory.getLogger(TotvController.class);
  private static final String SUCCESS_MESSAGE = "Success";
  private static final String FAILED_MESSAGE = "Failure";

  public static final String ROOT_PATH = "/totv";
  @Autowired
  private IgniteTradeUpdateService igniteTradeUpdateService;

  @Autowired
  private ItusInstrumentInput instrumentInput;

  @RequestMapping(value = ROOT_PATH + "/updateTradesOnDate", method = RequestMethod.POST)
  public ResponseEntity<TotvResponse> updateTradesOnDate(@Valid @RequestBody TotvInstrumentDateInput dateInput) throws ItusException {
    logger.info("TotvInstrumentDateInput : {}", dateInput);
    Set<TotvTradeStatus> tradeStatusSet = null;
    tradeStatusSet = igniteTradeUpdateService.updateForInstrumentInput(dateInput);
    logger.info("tradeStatusSet:" + tradeStatusSet);
    TotvResponse response = createTotvResponse(tradeStatusSet);
    return ResponseEntity.status(HttpStatus.OK).body(response);
  }


  @RequestMapping(value = ROOT_PATH + "/updateTradesSet", method = RequestMethod.POST)
  public ResponseEntity<TotvResponse> updateTotvTradeSet(@Valid @RequestBody Set<TotvTrade> tradeSet) throws ItusException {
    logger.info("TotvTradeSetInput : {}", tradeSet);
    Set<TotvTradeStatus> tradeStatusSet = null;
    tradeStatusSet = igniteTradeUpdateService.updateForTrades(tradeSet);
    logger.info("tradeStatusSet:" + tradeStatusSet);
    TotvResponse response = createTotvResponse(tradeStatusSet);
    return ResponseEntity.status(HttpStatus.OK).body(response);
  }


  @RequestMapping(value = ROOT_PATH + "/updateTradesOnIsin", method = RequestMethod.POST)
  public ResponseEntity<TotvResponse> updateTotvTradeForGivenIsins(@Valid @RequestBody TotvInstrumentInput instrumentInput) throws ItusException {
    logger.info("TotvInstrumentInput data : {}", instrumentInput);
    Set<TotvTradeStatus> tradeStatusSet = null;
    tradeStatusSet = igniteTradeUpdateService.updateForInstrumentsData(instrumentInput.getIsinDataSet(), instrumentInput.getDate());
    logger.info("tradeStatusSet:" + tradeStatusSet);
    TotvResponse response = createTotvResponse(tradeStatusSet);
    return ResponseEntity.status(HttpStatus.OK).body(response);
  }


  private TotvResponse createTotvResponse(Set<TotvTradeStatus> tradeStatusSet) {
    Map<ItusTradeSourceSystem, Map<ItusStatus, List<String>>> result = Maps.newHashMap();
    for (TotvTradeStatus totvTradeStatus : tradeStatusSet) {
      Map<ItusStatus, List<String>> systemSpecificMap;
      if ((systemSpecificMap = result.get(totvTradeStatus.getTrade().getItusTradeSourceSystem())) == null) {
        systemSpecificMap = Maps.newEnumMap(ItusStatus.class);
        result.put(totvTradeStatus.getTrade().getItusTradeSourceSystem(), systemSpecificMap);
      }
      List<String> ids;
      if ((ids = systemSpecificMap.get(totvTradeStatus.getStatus())) == null) {
        ids = Lists.newArrayList();
        systemSpecificMap.put(totvTradeStatus.getStatus(), ids);
      }
      ids.add(totvTradeStatus.getTrade().getTradeIdentifier());
    }
    TotvResponse response = new TotvResponse(HttpStatus.OK.name(), SUCCESS_MESSAGE, tradeStatusSet.size(), result);
    return response;
  }
}
