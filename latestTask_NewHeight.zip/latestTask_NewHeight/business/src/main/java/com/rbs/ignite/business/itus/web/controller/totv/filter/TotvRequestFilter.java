package com.rbs.ignite.business.itus.web.controller.totv.filter;

/**
 * Created by upadkti on 17/01/2018.
 */

import com.rbs.ignite.business.itus.web.controller.totv.TotvController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

@Component
public class TotvRequestFilter implements Filter {

  private static final Logger logger = LoggerFactory.getLogger(TotvController.class);

  @Value("${totv.fetch.trade.timezone:Europe/London}")
  private String timeZone;

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
    long startTime = System.currentTimeMillis();
    HttpServletRequest httpRequest = (HttpServletRequest) request;
    StringBuilder logMessage = new StringBuilder("Request Received: ");

    logMessage.append("[Request Path: ").append(httpRequest.getServletPath()).append("]")
      .append(getZonedTimestamp())
      .append("[Query String: ").append(httpRequest.getQueryString()).append("]")
      .append("[Method: ").append(httpRequest.getMethod()).append("]");
    logger.info(logMessage.toString());

    filterChain.doFilter(httpRequest, response);

    long timeTaken = System.currentTimeMillis() - startTime;
    logMessage = new StringBuilder("Request Served. ");
    logMessage.append("[Request Path: ").append(httpRequest.getServletPath()).append("]")
      .append(getZonedTimestamp())
      .append("[Query String: ").append(httpRequest.getQueryString()).append("]");
    logMessage.append(" | took=").append(timeTaken);
    logger.info(logMessage.toString());
  }

  private String getZonedTimestamp() {
    ZonedDateTime currentDateTime = LocalDateTime.now().atZone(ZoneId.of(timeZone));
    StringBuilder builder = new StringBuilder("[Zoned Timestamp[dd/mm/yyyy hh:mm:ss]: ");
    builder.append(currentDateTime.getDayOfMonth()).append("/")
      .append(currentDateTime.getMonth().getValue()).append("/")
      .append(currentDateTime.getYear()).append(" ")
      .append(currentDateTime.getHour()).append(":")
      .append(currentDateTime.getMinute()).append(":")
      .append(currentDateTime.getSecond()).append("]");
    return builder.toString();
  }

  @Override
  public void init(FilterConfig arg0) throws ServletException {
    logger.debug("Initialized TotvRequestFilter...");
  }

  @Override
  public void destroy() {
    logger.debug("Destroyed TotvRequestFilter...");
  }
}
