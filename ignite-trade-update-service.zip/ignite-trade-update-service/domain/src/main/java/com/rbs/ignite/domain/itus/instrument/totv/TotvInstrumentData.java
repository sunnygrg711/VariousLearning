package com.rbs.ignite.domain.itus.instrument.totv;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentData;

import javax.validation.constraints.NotNull;

/**
 * Created by puronaa on 14/09/2017.
 */
public class TotvInstrumentData implements ItusInstrumentData {

  @NotNull
  String isin;

  public TotvInstrumentData(@JsonProperty("isin") String isin) {
    this.isin = isin;
  }

  @Override
  public String getIsin() {
    return isin;
  }

  @Override
  public String toString() {
    return "TotvInstrumentData{" +
            "isin='" + isin + '\'' +
            '}';
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof TotvInstrumentData)) return false;

    TotvInstrumentData that = (TotvInstrumentData) o;

    return isin.equals(that.isin);
  }

  @Override
  public int hashCode() {
    return isin.hashCode();
  }
}
