package org.sk.tutorial.jfamily.concurrency.animation;

/**
 * Created by kshekar on 23/03/2018.
 */
public class QuickSort extends SorterRunnable {
    public QuickSort(Double[] sortableValues, ArrayPanel arrayPanelToDisplayValues){
        super(sortableValues,arrayPanelToDisplayValues);
    }

    private int partition( int lowerIndex, int highIndex){
        double pivotValue = sortableValues[highIndex];
        int indexOfSmallerElement= (lowerIndex-1);
        for ( int firstIteratorIndex =lowerIndex; firstIteratorIndex<highIndex;firstIteratorIndex++) {
            paintPanel( highIndex,firstIteratorIndex);
            if (checkIfCurrentElementLEThanPivot(sortableValues[firstIteratorIndex], pivotValue)) {
                swapSmallerElementWithCurrentValue(firstIteratorIndex, ++indexOfSmallerElement);
            }
        }
        swapSmallerElementWithPivotValue(indexOfSmallerElement+1,highIndex);
        paintPanel(highIndex,indexOfSmallerElement+1);
        return indexOfSmallerElement+1;
    }

    private void swapSmallerElementWithPivotValue(int firstIndex, int secondIndex) {
        swap(firstIndex,secondIndex);
    }

    private void paintPanel(int pivotIndex, int otherIndex) {
        arrayPanelToDisplayValues.setValues(sortableValues, sortableValues[pivotIndex], sortableValues[otherIndex]);
        try {
            if (run)
                Thread.sleep(DELAY_IN_MILLISECOND);
            else
                semaphorePermits.acquire();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        }
    }

    private void swapSmallerElementWithCurrentValue( int firstIndex, int secondIndex) {
        swap(firstIndex,secondIndex);
    }

    private void swap(int firstIndex, int secondIndex) {
        double temp = sortableValues[firstIndex];
        sortableValues[firstIndex] = sortableValues[secondIndex];
        sortableValues[secondIndex] = temp;
    }

    private boolean checkIfCurrentElementLEThanPivot(double subsetOfSortableValue, double pivotValue) {
        return Double.compare(subsetOfSortableValue,pivotValue)<=0 ;
    }
    void sort(int lowerIndex, int highIndex)
    {
        if (lowerIndex < highIndex)
        {
            int partitioningIndex = partition(lowerIndex, highIndex);
            sort(lowerIndex, partitioningIndex-1);
            sort(partitioningIndex+1, highIndex);
        }
    }
    @Override
    void sort() {

        sort(0,sortableValues.length-1);
        arrayPanelToDisplayValues.setValues(sortableValues, null, null);
        System.out.println("Done!");
    }
}
