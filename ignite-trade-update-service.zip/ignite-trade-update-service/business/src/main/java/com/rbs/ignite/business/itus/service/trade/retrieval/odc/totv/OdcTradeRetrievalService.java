package com.rbs.ignite.business.itus.service.trade.retrieval.odc.totv;


import com.google.common.base.Stopwatch;
import com.google.common.collect.Sets;
import com.rbs.ignite.api.itus.service.trade.retrieval.ItusTradeRetrievalService;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusQueryExecutor;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.OdcQueryExecutorHelper;
import com.rbs.ignite.domain.itus.enums.QueryParamName;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentData;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

/**
 * Created by puronaa on 15/09/2017.
 */
public class OdcTradeRetrievalService implements ItusTradeRetrievalService<TotvInstrumentData, TotvTrade> {

  public static final Logger logger = LoggerFactory.getLogger(OdcTradeRetrievalService.class);

  @Autowired
  private ConversionService conversionService;

  @Autowired
  private ItusQueryExecutor<Set<Transaction>> itusQueryExecutor;

  @Autowired
  ItusTransformer<Set<Transaction>,Set<TotvTrade>> transactionToTotvTradeTransformer;

  @Value("${totv.source.systems}")
  private String totvSourceSystem;

  @Override
  public Set<TotvTrade> retrieveTrades(Set<TotvInstrumentData> financialInstrumentDataSet,LocalDate date) throws ItusException {
    if(financialInstrumentDataSet == null || financialInstrumentDataSet.isEmpty()){
      throw new ItusException("No Isins found");
    }
    Set<String> isinSet = getIsinSetFromTotvDataSet(financialInstrumentDataSet);
    logger.info("Got {} ISIN from TotvDataSet", isinSet.size());

    Set<Transaction> transactionSet = getTransactionSetForIsinSet(isinSet,date);
    Set<TotvTrade> totvTradeSet = transactionToTotvTradeTransformer.transform(transactionSet);

    if(logger.isDebugEnabled()) {
      logger.debug("isinSet : {} ", isinSet);
      logger.debug("totvTradeSet : {} " + totvTradeSet);
    }
    return totvTradeSet;
  }

  private Set<Transaction> getTransactionSetForIsinSet(Set<String> isinSet, LocalDate date) throws ItusException {
    ConcurrentMap<ItusInstrumentData,Set<ItusTrade>> result = new ConcurrentHashMap<>();
    return getTransactionsFromOdc(isinSet,date);
  }

  private Set<Transaction> getTransactionsFromOdc(Set<String> isinSet,LocalDate date) throws ItusException {
    //TODO need to move this criteria generation logic to helper class
    ConcurrentMap<QueryParamName, Object> paramaterMap = new ConcurrentHashMap<>();
    paramaterMap.put(QueryParamName.ISINSET,isinSet);
    paramaterMap.put(QueryParamName.SOURCE_SYSTEM, OdcQueryExecutorHelper.getSourceSystemsSetFromString(totvSourceSystem));
    paramaterMap.put(QueryParamName.BUSINESS_DATE, date);
    paramaterMap.put(QueryParamName.ELIGIBLE,false);
    paramaterMap.put(QueryParamName.TRANSACTION_STATE, TransactionState.Cancelled);
    return itusQueryExecutor.executeQuery(paramaterMap);
  }

  private Set<String> getIsinSetFromTotvDataSet(Set<TotvInstrumentData> financialInstrumentDataSet) {
    Set<String> isinSet = new LinkedHashSet<>();
    for(ItusInstrumentData data: financialInstrumentDataSet){
      isinSet.add(data.getIsin());
    }
    return isinSet;
  }
}
