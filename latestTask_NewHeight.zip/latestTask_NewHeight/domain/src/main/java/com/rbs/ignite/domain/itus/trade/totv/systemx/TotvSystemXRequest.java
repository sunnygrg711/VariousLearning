package com.rbs.ignite.domain.itus.trade.totv.systemx;

/**
 * Created by kumaunn on 13/11/2017.
 */
public class TotvSystemXRequest {

  private String transactionIdentifier;

  public String getTransactionIdentifier() {
    return transactionIdentifier;
  }

  public void setTransactionIdentifier(String transactionIdentifier) {
    this.transactionIdentifier = transactionIdentifier;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvSystemXRequest that = (TotvSystemXRequest) o;

    if (!transactionIdentifier.equals(that.transactionIdentifier)) return false;
    return transactionIdentifier.equals(that.transactionIdentifier);
  }

  @Override
  public int hashCode() {
    int result = transactionIdentifier.hashCode();
    result = 31 * result + transactionIdentifier.hashCode();
    return result;
  }

  @Override
  public String toString() {
    return "TotvSystemxRequest [transactionIdentifier = " + transactionIdentifier;
  }
}
