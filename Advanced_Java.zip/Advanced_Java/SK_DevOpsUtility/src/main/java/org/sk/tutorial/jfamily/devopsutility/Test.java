package org.sk.tutorial.jfamily.devopsutility;

import org.sk.tutorial.jfamily.devopsutility.model.OsInfo;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.StringJoiner;
import java.util.concurrent.ForkJoinPool;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by kshekar on 06/04/2018.
 */
public class Test {
    public static void main(String[] args) {
        List<Athletes> athletesList= Arrays.asList(
                new Athletes("Bob",190,"basketball"),
                new Athletes("Sam",175,"basketball"),
                new Athletes("Tom",170,"soccer"),
                new Athletes("Bas",185,"soccer"),
                new Athletes("Jane",185,"cricket"));
      //  Collection<String> names=athletesList.stream().map(Athletes::getGame).distinct().collect(Collectors.toList());
        ForkJoinPool myPool = new ForkJoinPool(8);
        athletesList.parallelStream().forEach(System.out::println);
        System.out.println("###########");
        athletesList.stream().parallel().forEach(System.out::println);
        System.out.println("###########");
        athletesList.stream().parallel().forEach(System.out::println);
        System.out.println("###########");
        athletesList.stream().parallel().forEach(System.out::println);
        //System.out.println(names);
       // athletesList.forEach(athletes -> System.out.println(athletes));
        System.out.println(OsInfo.getInstance());
       Integer[] numbers={1,3,5,4};
        StringJoiner stringJoiner=new StringJoiner("^");
       int missingNumber=1^numbers[0];
        stringJoiner.add(String.valueOf(1)).add(String.valueOf(numbers[0]));
       for (int i=2;i<=numbers.length;i++){
           missingNumber^=i^numbers[i-1];
           stringJoiner.add(String.valueOf(i)).add(String.valueOf(numbers[i-1]));
       }
        missingNumber^=numbers.length+1;
        stringJoiner.add(String.valueOf(numbers.length+1));
        System.out.println(missingNumber);
        System.out.println(stringJoiner);
    }
}

class Athletes {
    private String name;
    private Integer height;
    private String game;

    public Athletes(String name, Integer height, String game) {
        this.name = name;
        this.height = height;
        this.game = game;
    }

    public String getName() {
        return name;
    }

    public Integer getHeight() {
        return height;
    }

    public String getGame() {
        return game;
    }

    @Override
    public String toString() {
        return "Athletes{" +
                "name='" + name + '\'' +
                ", height=" + height +
                ", game='" + game + '\'' +
                '}';
    }
}
