package com.rbs.ignite.business.itus.transformer.gfx;


import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;

/**
 * Tranformer class which uses conversion utility to convert totv trade to gfx
 */
public class TotvTradeToGfxReqTransformer implements ItusTransformer<TotvTrade, TotvGfxRequest> {

  @Autowired
  ConversionService conversionService;

  @Override
  public TotvGfxRequest transform(TotvTrade totvTrade) throws ItusTransformException {
    TypeDescriptor sourceType = TypeDescriptor.valueOf(TotvTrade.class);
    TypeDescriptor targetType = TypeDescriptor.valueOf(TotvGfxRequest.class);
    TotvGfxRequest totvGfxRequest = (TotvGfxRequest) conversionService.convert(totvTrade, sourceType, targetType);
    return totvGfxRequest;
  }
}
