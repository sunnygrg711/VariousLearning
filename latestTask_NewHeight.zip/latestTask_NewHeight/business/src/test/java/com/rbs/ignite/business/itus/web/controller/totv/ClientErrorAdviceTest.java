package com.rbs.ignite.business.itus.web.controller.totv;

import com.rbs.ignite.business.itus.web.controller.totv.error.ClientErrorAdvice;
import com.rbs.ignite.business.itus.web.controller.totv.error.ErrorMessage;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by kumaunn on 02/04/2018.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(SecurityContextHolder.class)
@PowerMockIgnore("javax.management.*")

public class ClientErrorAdviceTest {

  @Mock
  private HttpServletRequest request;

  @Mock
  private SecurityContext context;

  @Mock
  private Authentication authentication;

  @InjectMocks
  private ClientErrorAdvice clientErrorAdvice;

  @Test
  public void testGetCurrentUser_NullAuthentication() {

    ErrorMessage message = clientErrorAdvice.restErrorHandler(request, new SecurityException());
    Assert.assertEquals(message.getHttpStatus(), HttpStatus.INTERNAL_SERVER_ERROR.value());
  }

  @Test
  public void testGetCurrentUser_AuthenticationNotNull() {
    PowerMockito.mockStatic(SecurityContextHolder.class);
    PowerMockito.when(SecurityContextHolder.getContext()).thenReturn(context);
    PowerMockito.when(context.getAuthentication()).thenReturn(authentication);

    ErrorMessage message = clientErrorAdvice.restErrorHandler(request, new SecurityException());
    Assert.assertEquals(message.getHttpStatus(), HttpStatus.INTERNAL_SERVER_ERROR.value());
  }
}
