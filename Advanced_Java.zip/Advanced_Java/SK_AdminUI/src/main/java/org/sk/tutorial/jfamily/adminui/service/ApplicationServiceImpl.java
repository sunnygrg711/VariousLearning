package org.sk.tutorial.jfamily.adminui.service;

import org.sk.tutorial.jfamily.devopsutility.service.AbstractApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by kshekar on 06/04/2018.
 */
@Service
public class ApplicationServiceImpl extends AbstractApplicationService {



    @Override
    public void initApplicationDetail() {

    }
}
