package org.sk.tutorial.jfamily.concurrency.locks.synch;

import org.sk.tutorial.jfamily.concurrency.locks.Bank;
import org.sk.tutorial.jfamily.concurrency.locks.Transferable;

/**
 * Created by kshekar on 22/03/2018.
 */
public class TransactionHandler implements Transferable {
   private Bank bank;
   private BankLockingImpl bankLocking;



    public TransactionHandler(Bank bank, BankLockingImpl bankLocking) {
        this.bank = bank;
        this.bankLocking = bankLocking;
    }


    public void transfer(int fromBankAccountId, int toBankAccountId, double amount) throws InterruptedException {
        bankLocking.getBankLock().lock();
        try
        {
            while (bank.getAccounts()[fromBankAccountId].getBalanceAmount() < amount) {
                System.out.print(Thread.currentThread());
                System.out.printf("%10.2f can not be transferred from %s due to insufficient fund.\n",amount, bank.getAccounts()[fromBankAccountId]);
                bankLocking.getSufficientFunds().await();
            }
            if(fromBankAccountId!=toBankAccountId){
                System.out.print(Thread.currentThread());
                bank.getAccounts()[fromBankAccountId].setBalanceAmount(bank.getAccounts()[fromBankAccountId].getBalanceAmount()-amount);
                System.out.printf("%10.2f is transferring from %s to %s\n", amount,  bank.getAccounts()[fromBankAccountId],  bank.getAccounts()[toBankAccountId]);
                bank.getAccounts()[toBankAccountId].setBalanceAmount(bank.getAccounts()[toBankAccountId].getBalanceAmount()+amount);
                System.out.print(Thread.currentThread());
                System.out.printf("%10.2f is received by  %s\n", amount,   bank.getAccounts()[toBankAccountId]);
            }
            bankLocking.getSufficientFunds().signalAll();
        }
        finally
        {
            bankLocking.getBankLock().unlock();
        }
    }
}
