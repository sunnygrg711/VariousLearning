package com.rbs.ignite.domain.itus.instrument;

/**
 * Created by puronaa on 14/09/2017.
 */
public interface ItusInstrumentInput {

}
