package com.rbs.ignite.business.itus.web.controller.totv;

/**
 * Interface created for client side error handling. Classes need to implement this interface, in case custom error message is to
 * be shown, for any error.
 */
public interface ItusClientController {

}
