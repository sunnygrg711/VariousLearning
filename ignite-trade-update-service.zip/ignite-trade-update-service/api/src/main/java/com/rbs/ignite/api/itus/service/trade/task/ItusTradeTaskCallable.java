package com.rbs.ignite.api.itus.service.trade.task;


import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;

/**
 * Created by puronaa on 03/10/2017.
 */
public class ItusTradeTaskCallable implements Callable<ItusTradeStatus>{
    private static final Logger logger = LoggerFactory.getLogger(ItusTradeTaskCallable.class);

    private ItusTradeTask<ItusTrade, ItusTradeStatus> itusTradeTask;

    public ItusTradeTaskCallable(ItusTradeTask<ItusTrade, ItusTradeStatus> itusTradeTask) {
        this.itusTradeTask = itusTradeTask;
    }

    public ItusTradeTask<ItusTrade, ItusTradeStatus> getItusTradeTask() {
        return itusTradeTask;
    }

    /**
     * Computes a result, or throws an exception if unable to do so.
     *
     * @return computed result
     * @throws Exception if unable to compute a result
     */
    @Override
    public ItusTradeStatus call() throws ItusException {
        ItusTradeStatus status = null;
        try {
            logger.info("Started task:"+itusTradeTask);
            status =  itusTradeTask.execute();
        }finally {
            logger.info("finished Task:"+itusTradeTask);
            logger.info("status:"+status);
            return status;
        }
    }
}
