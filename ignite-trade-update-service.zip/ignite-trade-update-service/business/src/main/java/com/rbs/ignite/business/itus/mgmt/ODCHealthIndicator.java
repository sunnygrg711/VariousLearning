package com.rbs.ignite.business.itus.mgmt;

import com.fasterxml.jackson.databind.JsonNode;
import com.rbs.gbm.rates.core.auth.security.SSOAuthenticationService;
import com.rbs.gbm.rates.core.auth.security.SsoTokenProviderService;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * Created by kumaunn on 12/12/2017.
 */
@Component
public class ODCHealthIndicator extends AbstractHealthIndicator {

  @Autowired
  private RestTemplate restTemplate;

  @Value("${odc.health.url}")
  private String odcUrl;

  @Override
  protected void doHealthCheck(Health.Builder builder) throws Exception {

    try {

      SsoTokenProviderService servic = new SsoTokenProviderService("app-ignite", "Family$123", "ODC-Http-Api-ReadOnly", new SSOAuthenticationService("https://uatwebservices.fm.rbsgrp.net/webservices/ssoclient.asmx"));
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.add("Authorization",new String("SSO " + new String(Base64.encodeBase64(("SSOTOKEN:" + servic.getToken()).getBytes()))));
      HttpEntity entity = new HttpEntity(headers);
      // headers.set("Authorization", "Bearer "+accessToken);

      ResponseEntity res = restTemplate.exchange(odcUrl, HttpMethod.GET, entity,JsonNode.class);
      // JsonNode resp = restTemplate.getForObject(odcUrl, entity, JsonNode.class);
      /*if (resp.get("status").asText().equalsIgnoreCase("UP")) {
        builder.withDetail("ODC is always up ", "").status(Status.UP);
      } else {
        builder.status(Status.DOWN);
      }*/
    } catch (Exception e) {
      builder.withDetail(e.getMessage(), "").status(Status.DOWN);
    }
  }
}
