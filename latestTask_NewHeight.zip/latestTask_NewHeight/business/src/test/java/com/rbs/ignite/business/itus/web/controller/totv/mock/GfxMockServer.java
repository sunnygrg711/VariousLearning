package com.rbs.ignite.business.itus.web.controller.totv.mock;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import org.springframework.boot.test.context.TestComponent;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

public class GfxMockServer {

  private int mockServerPort;

  private WireMockServer server;

  private ObjectMapper objectMapper;

  public GfxMockServer(String gfxUrl) {
    this.mockServerPort = MockServerUtil.getPortNumber(gfxUrl);
    server = new WireMockServer(mockServerPort);
  }

  public WireMockServer ensureGfxServerIsDown() {
    server.stop();
    MockServerUtil.waitTillServerStops(server, mockServerPort);
    return server;
  }

  public WireMockServer ensureGfxResponse(String request1, String response1,String request2, String response2) {

    if (server.isRunning()) {
      server.resetAll();
    } else {
      server.start();
      MockServerUtil.waitTillServerStarts(server, mockServerPort);
    }



    try {
      server.stubFor(
              WireMock.put(WireMock.urlPathEqualTo("/api/v3/totv-amend/source-systems/PabFX/transactions/"+request1))
                      .willReturn(
                              WireMock.aResponse()
                                      .withStatus(HttpStatus.OK.value())
                                      .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                      .withBody(response1)
                      )
      );
      server.stubFor(
              WireMock.put(WireMock.urlPathEqualTo("/api/v3/totv-amend/source-systems/PabFX/transactions/"+request2))
                      .willReturn(
                              WireMock.aResponse()
                                      .withStatus(HttpStatus.OK.value())
                                      .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                      .withBody(response2)
                      )
      );
      return server;
    } catch (Exception e) {
      throw new RuntimeException(e);
    }

  }
}
