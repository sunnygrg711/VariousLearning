package com.rbs.ignite.business.itus.service.trade.retrieval.odc.totv;


import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.rbs.ignite.api.itus.service.trade.retrieval.ItusTradeRetrievalService;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusQueryExecutor;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.OdcQueryExecutorHelper;
import com.rbs.ignite.domain.itus.enums.QueryParamName;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionState;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

/**
 * Created by puronaa on 15/09/2017.
 */
public class OdcTradeRetrievalService implements ItusTradeRetrievalService<String, TotvTrade> {

  private static final Logger logger = LoggerFactory.getLogger(OdcTradeRetrievalService.class);



  @Autowired
  private ConversionService conversionService;


  private ExecutorService executorService;

  @Autowired
  private ItusQueryExecutor<Set<Transaction>> itusQueryExecutor;

  @Autowired
  ItusTransformer<Set<Transaction>, Set<TotvTrade>> transactionToTotvTradeTransformer;

  public OdcTradeRetrievalService(ExecutorService executorService) {
    this.executorService = executorService;
  }

  @Value("${totv.source.systems}")
  private String totvSourceSystem;

  @Value("${totv.fetch.batch.size}")
  private int batchSize;

  @Override
  public Set<TotvTrade> retrieveTrades(Set<String> isinSet, LocalDate date,
                                       Set<ItusTradeSourceSystem> sourceSystems,String requestId) throws ItusException {
    Set<Transaction> transactionSet = new HashSet<>();

    if (CollectionUtils.isEmpty(isinSet)) {
      throw new ItusException(requestId + ":" + "No input ISINs found to query trades from ODC");
    }

    if(batchSize <= 0) {
      batchSize = 1000;
    }
    logger.info(requestId+":"+"ISIN batch size to get trades from ODC(totv.fetch.batch.size)={}",batchSize);

    Iterable<List<String>> partitionedISINSet = Iterables.partition(isinSet, batchSize);
    List<Future<Set<Transaction>>> futures = Lists.newArrayList();
    partitionedISINSet.forEach((isinList)-> {
      futures.add(executorService.submit(() -> {
        Set<Transaction> odcTrades = getTransactionSetForIsinSet(Sets.newHashSet(isinList), date, sourceSystems,requestId);
        Set <String> tradeIdSet = new LinkedHashSet<>();
        logger.info((requestId+":"+odcTrades==null||odcTrades.isEmpty()) ?
          "No Trades Found in ODC" : "Total trades Found in ODC: "+ odcTrades.size());
        odcTrades.forEach(odcTrade->{
          tradeIdSet.add(odcTrade.getId().getSourceSystemTransactionId());
        });
        logger.info(requestId+":"+"ISIN batch and Trades: ISINs[{}];Trades[{}]",isinList,tradeIdSet);
        return odcTrades;
      }));
    });

    futures.forEach((future)->{
      try {
        Set<Transaction>  odcTrades = future.get();
        if (odcTrades != null && !odcTrades.isEmpty()) {
          transactionSet.addAll(odcTrades);
        }
      } catch (RuntimeException | ExecutionException| InterruptedException e) {
        logger.error(requestId+":"+"Exception occurred while retrieving trades from ODC for date {}:", date, e);
      }
    });

    Set<TotvTrade> totvTradeSet = transactionToTotvTradeTransformer.transform(transactionSet);
    logger.info(requestId+":"+"ToTv trades found from ODC: {}", totvTradeSet);
    return totvTradeSet;
  }

  private Set<Transaction> getTransactionSetForIsinSet(Set<String> isinSet, LocalDate date, Set<ItusTradeSourceSystem> sourceSystems, String requestId) throws ItusException {
    return getTransactionsFromOdc(isinSet, date, sourceSystems,requestId);
  }

  private Set<Transaction> getTransactionsFromOdc(Set<String> isinSet, LocalDate date, Set<ItusTradeSourceSystem> sourceSystems,String requestId) throws ItusException {
    //TODO need to move this criteria generation logic to helper class
    ConcurrentMap<QueryParamName, Object> parameterMap = new ConcurrentHashMap<>();
    parameterMap.put(QueryParamName.ISINSET, isinSet);
    if (sourceSystems!=null && !sourceSystems.isEmpty()) {
      parameterMap.put(QueryParamName.SOURCE_SYSTEM, sourceSystems);
    } else {
      parameterMap.put(QueryParamName.SOURCE_SYSTEM, OdcQueryExecutorHelper.getSourceSystemsSetFromString(totvSourceSystem));
    }
    parameterMap.put(QueryParamName.BUSINESS_DATE, date);
    parameterMap.put(QueryParamName.ELIGIBLE, false);
    parameterMap.put(QueryParamName.TRANSACTION_STATE, TransactionState.Cancelled);
    parameterMap.put(QueryParamName.REQUEST_ID,requestId);
    return itusQueryExecutor.executeQuery(parameterMap);
  }
}
