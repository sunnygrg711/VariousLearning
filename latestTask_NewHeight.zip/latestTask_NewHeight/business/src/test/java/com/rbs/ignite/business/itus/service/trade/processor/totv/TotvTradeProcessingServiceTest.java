package com.rbs.ignite.business.itus.service.trade.processor.totv;

import com.rbs.ignite.business.itus.configurer.totv.TradeSystemToProcessorMapper;
import com.rbs.ignite.business.itus.jmx.TotvJmxProvider;
import com.rbs.ignite.business.itus.service.trade.processor.totv.ignitebonds.TotvIgniteBondsTradeProcessor;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatusHolder;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Set;
import java.util.concurrent.*;

/**
 * Created by upadkti on 10/11/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class TotvTradeProcessingServiceTest {

  @InjectMocks
  private TotvTradeProcessingService testObj;
  @Mock
  private TotvTrade totvTrade;
  @Mock
  private TradeSystemToProcessorMapper tradeSystemToProcessorMapper;
  @Mock
  private TotvIgniteBondsTradeProcessor totvIgniteBondsTradeProcessor;
  @Mock
  private ExecutorService executorService;
  @Mock
  private Future future;
  @Mock
  private TotvJmxProvider totvJmxProvider;

  @Before
  public void setup(){
    MockitoAnnotations.initMocks(this);
  }

  @After
  public void tearDown() {
    testObj = null;
  }

  @Test
  public void testoricessTradesForIgnite_Success() throws Exception {
    Mockito.when(tradeSystemToProcessorMapper.getProcessor(ItusTradeSourceSystem.IGNITE)).thenReturn(totvIgniteBondsTradeProcessor);
    Mockito.when(totvTrade.getItusTradeSourceSystem()).thenReturn(ItusTradeSourceSystem.IGNITE);
    TotvTradeHolder tradeHolder = new TotvTradeHolder(ItusTradeSourceSystem.IGNITE,Sets.newSet(totvTrade));
    TotvTradeStatus tradeStatus = new TotvTradeStatus.TotvTradeStatusBuilder(totvTrade, ItusStatus.ACCEPTED,"200").build();
    TotvTradeStatusHolder statusHolder = new TotvTradeStatusHolder(ItusTradeSourceSystem.IGNITE,Sets.newSet(tradeStatus));
    Mockito.when(executorService.submit((Callable<? extends Object>) Mockito.any())).thenReturn(future);
    Mockito.when(future.get()).thenReturn(statusHolder);
    Mockito.when(totvJmxProvider.getReadOnlyMode()).thenReturn(Boolean.FALSE);
    Set<ItusTradeStatus> tradeStatusSet = testObj.processTrades(Sets.newSet(totvTrade),"<EMPTY>", false);
    Assert.assertTrue(tradeStatusSet != null && tradeStatusSet.size() ==1);
    Assert.assertTrue(tradeStatusSet.contains(tradeStatus));
  }

  @Test
  public void testProcessTradesForIgnite_Exception() throws Exception {
    Mockito.when(tradeSystemToProcessorMapper.getProcessor(ItusTradeSourceSystem.IGNITE)).thenReturn(totvIgniteBondsTradeProcessor);
    Mockito.when(totvTrade.getItusTradeSourceSystem()).thenReturn(ItusTradeSourceSystem.IGNITE);
    TotvTradeHolder tradeHolder = new TotvTradeHolder(ItusTradeSourceSystem.IGNITE,Sets.newSet(totvTrade));
    TotvTradeStatus tradeStatus = new TotvTradeStatus.TotvTradeStatusBuilder(totvTrade, ItusStatus.ACCEPTED,"200").build();
    TotvTradeStatusHolder statusHolder = new TotvTradeStatusHolder(ItusTradeSourceSystem.IGNITE,Sets.newSet(tradeStatus));
    Mockito.when(executorService.submit((Callable<? extends Object>) Mockito.any())).thenReturn(future);
    Mockito.when(future.get()).thenThrow(ExecutionException.class);
    Mockito.when(totvIgniteBondsTradeProcessor.processTrades(tradeHolder,"<EMPTY>", false)).thenReturn(statusHolder);
    Mockito.when(totvJmxProvider.getReadOnlyMode()).thenReturn(Boolean.FALSE);
    Set<ItusTradeStatus> tradeStatusSet = testObj.processTrades(Sets.newSet(totvTrade),"<EMPTY>", false);
    Assert.assertTrue(tradeStatusSet.isEmpty() && tradeStatusSet.size() ==0);
  }

  @Test
  public void testoricessTradesWithNoInput() throws Exception {
    Set<ItusTradeStatus> tradeStatusSet = testObj.processTrades(Sets.newSet(),"<EMPTY>", false);
    Assert.assertTrue(tradeStatusSet != null && tradeStatusSet.size() ==0);
  }
}
