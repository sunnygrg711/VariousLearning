package com.rbs.ignite.business.itus.web.controller.totv.mock;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.ValidatableResponse;
import org.springframework.http.HttpStatus;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Objects;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

public class MockServerUtil
{

	public static int getPortNumber(String url) {
        try {
            return new URL(url).getPort();
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

	public static void waitTillServerStarts(WireMockServer server, int port)
	{
		server.stubFor(get(urlEqualTo("/")).willReturn(aResponse().withStatus(HttpStatus.OK.value()).withBody("{}")));
		boolean ready = false;
		while (!ready)
		{
			ValidatableResponse response = RestAssured.given().when().get("http://localhost:" + port + "/").then();
			ready = response.extract().statusCode() == HttpStatus.OK.value();

		}
	}

	public static void waitTillServerStops(WireMockServer server, int port)
	{
		server.stubFor(get(urlEqualTo("/")).willReturn(aResponse().withStatus(HttpStatus.OK.value()).withBody("{}")));
		boolean ready = true;
		while (ready)
		{
			try
			{
				RestAssured.given().when().get("http://localhost:" + port + "/").then();
			}
			catch (Exception ex)
			{
				ready = false;
			}
		}
	}

	public static void sleep() {
		final String delayInMilliSeconds = System.getProperty("delay.ms");
		if(Objects.nonNull(delayInMilliSeconds)) {
			try
			{
				Thread.sleep(Long.parseLong(delayInMilliSeconds));
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
