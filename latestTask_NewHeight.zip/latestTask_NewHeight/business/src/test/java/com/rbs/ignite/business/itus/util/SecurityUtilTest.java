package com.rbs.ignite.business.itus.util;

import com.google.common.collect.Sets;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.GrantedAuthority;

/**
 * Created by kumaunn on 02/04/2018.
 */
public class SecurityUtilTest {

  @Mock
  private GrantedAuthority authority;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testToRoleNames() {
    Assert.assertEquals(SecurityUtil.toRoleNames(Sets.newHashSet()).size(), 0);
    Assert.assertEquals(SecurityUtil.toRoleNames(Sets.newHashSet(authority)).size(), 1);
  }
}
