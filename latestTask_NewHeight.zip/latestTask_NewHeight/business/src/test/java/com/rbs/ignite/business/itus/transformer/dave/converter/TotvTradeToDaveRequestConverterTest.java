package com.rbs.ignite.business.itus.transformer.dave.converter;

import com.rbs.ignite.business.itus.transformer.dave.converter.TotvTradeToDaveReqConverter;
import com.rbs.ignite.business.itus.transformer.ice.converter.TotvTradeToIceRequestConverter;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveRequest;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by upadkti on 20/12/2017.
 */
public class TotvTradeToDaveRequestConverterTest {

  private TotvTradeToDaveReqConverter testObj;

  @Before
  public void setup() {
    testObj = new TotvTradeToDaveReqConverter();
  }

  @Test
  public void testConvert() {
    TotvTrade inputTrade = new TotvTrade("ISIN12345","12345", ItusTradeSourceSystem.DAVE,"LDN");
    TotvDaveRequest outputRequet = testObj.convert(inputTrade);

    Assert.assertEquals(outputRequet.getIsin(),"ISIN12345");
    Assert.assertEquals(outputRequet.getTarget().getContractId(),12345L);
  }

  @Test
  public void testConvert_NoIsin() {
    TotvTrade inputTrade = new TotvTrade(null,"12345", ItusTradeSourceSystem.DAVE,"LDN");
    TotvDaveRequest outputRequet = testObj.convert(inputTrade);

    Assert.assertEquals(outputRequet.getIsin(),"");
    Assert.assertEquals(outputRequet.getTarget().getContractId(),12345L);
  }
}
