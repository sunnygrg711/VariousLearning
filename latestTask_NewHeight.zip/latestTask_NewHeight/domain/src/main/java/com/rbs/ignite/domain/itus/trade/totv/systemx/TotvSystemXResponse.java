package com.rbs.ignite.domain.itus.trade.totv.systemx;

/**
 * Created by kumaunn on 09/11/2017.
 */
public class TotvSystemXResponse {

  private String sourceSystem;
  private String transaction;
  private String correlationId;
  private String success;
  private String errorMessage;

  public String getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(String sourceSystem) {
    this.sourceSystem = sourceSystem;
  }

  public String getTransaction() {
    return transaction;
  }

  public void setTransaction(String transaction) {
    this.transaction = transaction;
  }

  public String getCorrelationId() {
    return correlationId;
  }

  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  public String getSuccess() {
    return success;
  }

  public void setSuccess(String success) {
    this.success = success;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  @Override
  public String toString() {
    return "TotvSystemXResponse{" +
            "sourceSystem=" + sourceSystem +
            ", transaction=" + transaction +
            ", correlationId=" + correlationId +
            ", success=" + success +
            ", errorMessage=" + errorMessage +
            '}';
  }
}
