package com.rbs.ignite.business.itus.transformer.gfx;

import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.eq;

@RunWith(SpringJUnit4ClassRunner.class)
public class TotvTradeToGfxReqTransformerTest {

  @InjectMocks
  private TotvTradeToGfxReqTransformer gfxTradeTransformerObj;
  @Mock
  ConversionService conversionService;
  @Mock
  private TotvTrade totvTrade;
  private TotvGfxRequest totvGfxRequest;
  private TypeDescriptor sourceType;
  private TypeDescriptor targetType;


  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    totvGfxRequest = new TotvGfxRequest();
    totvGfxRequest.setTransactionIdentifier("gfxIdentifier");
    sourceType = TypeDescriptor.valueOf(TotvTrade.class);
    targetType = TypeDescriptor.valueOf(TotvGfxRequest.class);
  }

  @After
  public void tearDown() {
    gfxTradeTransformerObj = null;
  }

  @Test
  public void testTransform() throws ItusTransformException {

    Mockito.when(conversionService.convert(Mockito.anyObject(), eq(sourceType), eq(targetType))).thenReturn(totvGfxRequest);
    TotvGfxRequest gfxRequest = gfxTradeTransformerObj.transform(totvTrade);
    assertEquals("gfxIdentifier", gfxRequest.getTransactionIdentifier());
  }

}
