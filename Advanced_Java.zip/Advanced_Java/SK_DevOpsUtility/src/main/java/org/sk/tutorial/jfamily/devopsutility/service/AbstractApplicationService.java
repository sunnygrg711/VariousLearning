package org.sk.tutorial.jfamily.devopsutility.service;

import org.sk.tutorial.jfamily.devopsutility.CommonUtil;
import org.sk.tutorial.jfamily.devopsutility.exceptions.JFamilyException;
import org.sk.tutorial.jfamily.devopsutility.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.lang.management.*;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Created by kshekar on 04/04/2018.
 */
public  abstract class AbstractApplicationService implements ApplicationService {

    private static final Logger LOGGER= LoggerFactory.getLogger(ApplicationService.class);


    @Override
    public List<ThreadInfo> getThreadDump() {
        ThreadMXBean threadMXBean=ManagementFactory.getThreadMXBean();
        List<ThreadInfo> threadInfos= Arrays.asList(threadMXBean.dumpAllThreads(true,true));
        return threadInfos;
    }


    @Override
    public String downloadHeapDump(String processId) {
        String fileName=new HeapDumpInfo().getFileName();
        String command="\"" + CommonUtil.getJavaHomePath()+ File.separator+"bin"+File.separator+"jmap\"  -F -dump:live,format=b,file=\""+fileName+"\" "+processId;
        try {
            Runtime.getRuntime().exec(command) ;
        } catch (IOException e) {
            if(isFileCreated(fileName)){
                LOGGER.warn("Found some issue while creating heapdump");
            }
            else{
                LOGGER.error("Failed to create heap dump due to {}",e.getMessage());
                throw new JFamilyException("Failed to create heap dump due to "+e.getMessage(),e);

            }
        }
        return fileName;
    }

    private  boolean isFileCreated(String fileName){
        return Files.exists(new File(fileName).toPath());
    }

    @Override
    public MemoryDetail getMemoryDetail() {
      MemoryMXBean memoryMXBean=  ManagementFactory.getMemoryMXBean();
        MemoryUsage heapMemoryUsage=  memoryMXBean.getHeapMemoryUsage();
        MemoryUsage nonHeapMemoryUsage=  memoryMXBean.getNonHeapMemoryUsage();
        MemoryDetail memoryDetail=new MemoryDetail();
        memoryDetail.setInitialHeap(heapMemoryUsage.getInit());
        memoryDetail.setInitialNonHeap(nonHeapMemoryUsage.getInit());
        memoryDetail.setMaximumHeap(heapMemoryUsage.getMax());
        memoryDetail.setMaximumNonHeap(nonHeapMemoryUsage.getMax());
        memoryDetail.setHeapUsedMemoryPercentage(getMemoryUsedPercentage(heapMemoryUsage));
        memoryDetail.setNonHeapUsedMemoryPercentage(getMemoryUsedPercentage(nonHeapMemoryUsage));
        return memoryDetail;
    }

    private  long getMemoryUsedPercentage(MemoryUsage memoryUsage){
        return memoryUsage.getUsed()*100/memoryUsage.getMax();
    }


    @Override
    public Gc getGcDetail() {
        List<GarbageCollectorMXBean> garbageCollectorMXBeen=  ManagementFactory.getGarbageCollectorMXBeans();
        Optional<GarbageCollectorMXBean> majorGc= garbageCollectorMXBeen.stream().filter(garbageCollectorMXBean -> null!=GCCollectors.oldGCC(garbageCollectorMXBean.getName())).findFirst();
        Optional<GarbageCollectorMXBean> minorGc= garbageCollectorMXBeen.stream().filter(garbageCollectorMXBean -> null!=GCCollectors.getYoungGCC(garbageCollectorMXBean.getName())).findFirst();
        Gc gc=new Gc();
        if(majorGc.isPresent()){
            gc.setMajorGcCount(majorGc.get().getCollectionCount());
            gc.setMajorGcName(majorGc.get().getName());
            gc.setMajorGcTime(majorGc.get().getCollectionTime());
        }
        if(minorGc.isPresent()){
            gc.setMinorGcCount(minorGc.get().getCollectionCount());
            gc.setMinorGcName(minorGc.get().getName());
            gc.setMinorGcTime(minorGc.get().getCollectionTime());
        }
        return gc;
    }


    @Override
    public JVMInfo getJvmInfo() {
        ClassLoadingMXBean classLoadingMXBean= ManagementFactory.getClassLoadingMXBean();
        ClassesInfo classesInfo=new ClassesInfo();
        classesInfo.setCurrentLoaded(classLoadingMXBean.getLoadedClassCount());
        classesInfo.setTotalLoaded(classLoadingMXBean.getTotalLoadedClassCount());
        classesInfo.setUnloaded(classLoadingMXBean.getUnloadedClassCount());
        ThreadsInfo threadsInfo=new ThreadsInfo();
        ThreadMXBean threadMXBean=ManagementFactory.getThreadMXBean();
        threadsInfo.setCurrentThreadCpuTime(threadMXBean.getCurrentThreadCpuTime());
        threadsInfo.setCurrentThreadUserTime(threadMXBean.getCurrentThreadUserTime());
        threadsInfo.setDaemonThreadCount(threadMXBean.getDaemonThreadCount());
        threadsInfo.setPeakThreadCount(threadMXBean.getPeakThreadCount());
        threadsInfo.setTotalStartedThreadCount(threadMXBean.getTotalStartedThreadCount());
        OperatingSystemMXBean operatingSystemMXBean= ManagementFactory.getOperatingSystemMXBean();
        JVMInfo jvmInfo=new JVMInfo();
        jvmInfo.setAvailableProcessors(operatingSystemMXBean.getAvailableProcessors());
        jvmInfo.setClassesInfo(classesInfo);
        jvmInfo.setThreadsInfo(threadsInfo);
        jvmInfo.setCpuName(operatingSystemMXBean.getArch());
        jvmInfo.setOsName(operatingSystemMXBean.getName());
        jvmInfo.setOsVersion(operatingSystemMXBean.getVersion());
        return jvmInfo;
    }


    @Override
    public OsInfo getOsInfo() {
        return OsInfo.getInstance();
    }
}
