package org.sk.tutorial.jfamily.adminui.web;

import org.sk.tutorial.jfamily.devopsutility.DevOpsManager;
import org.sk.tutorial.jfamily.devopsutility.exceptions.ExceptionUtil;
import org.sk.tutorial.jfamily.devopsutility.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;

/**
 * Created by kshekar on 03/04/2018.
 */
@Controller
@RequestMapping("/devOps/")
public class DevOpsController {

    @Autowired
    ApplicationService applicationService;

    @RequestMapping(value = "/services", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody  ResponseEntity<String> getServices() {
        return new ResponseEntity(DevOpsManager.get().getAllDevOpsData(),HttpStatus.OK);
    }

    @RequestMapping(value = "/heartBeat", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody  ResponseEntity<Boolean> isAlive() {
        return new ResponseEntity(Boolean.TRUE,HttpStatus.OK);
    }

    @RequestMapping(value = "/heapDump/{processId}", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<String> download(@PathVariable("processId") String processId) {
        String fileName=  ExceptionUtil.execute(()-> applicationService.downloadHeapDump(processId));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json; charset=UTF-8");
        headers.add("Content-Disposition", "attachment; filename=\""+fileName+"\"");
       return fileName==null?new ResponseEntity(GsonFactory.toJson("Failed to download heapdump"), HttpStatus.EXPECTATION_FAILED):new ResponseEntity(GsonFactory.toJson(fileName),headers,HttpStatus.OK);
    }

    @RequestMapping(value = "/threadDump", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody  ResponseEntity<String> getThreadDump()  {
        return new ResponseEntity(GsonFactory.toJson(applicationService.getThreadDump()),HttpStatus.OK);
    }
    @RequestMapping(value = "/memoryDetail", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody  ResponseEntity<String> getMemoryDetail() {
        return new ResponseEntity(GsonFactory.toJson(applicationService.getMemoryDetail()),HttpStatus.OK);
    }

    @RequestMapping(value = "/jvmInfo", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody  ResponseEntity<String> getJvmInfo() {
        return new ResponseEntity(GsonFactory.toJson(applicationService.getJvmInfo()),HttpStatus.OK);
    }

    @RequestMapping(value = "/osInfo", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody  ResponseEntity<String> getOsInfo() {
        return new ResponseEntity(GsonFactory.toJson(applicationService.getOsInfo()),HttpStatus.OK);
    }

    @RequestMapping(value = "/gc", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody  ResponseEntity<String> getGcDetail() {
        return new ResponseEntity(GsonFactory.toJson(applicationService.getGcDetail()),HttpStatus.OK);
    }
}
