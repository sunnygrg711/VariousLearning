package com.rbs.ignite.business.itus.transformer.dave;


import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;

/**
 * Tranformer class which uses conversion utility to convert totv trade to dave
 */
public class TotvTradeToDaveReqTransformer implements ItusTransformer<TotvTrade, TotvDaveRequest> {

  @Autowired
  ConversionService conversionService;


  @Override
  public TotvDaveRequest transform(TotvTrade totvTrade) throws ItusTransformException {
    TypeDescriptor sourceType = TypeDescriptor.valueOf(TotvTrade.class);
    TypeDescriptor targetType = TypeDescriptor.valueOf(TotvDaveRequest.class);
    TotvDaveRequest toTvdaveRequest = (TotvDaveRequest) conversionService.convert(totvTrade, sourceType, targetType);
    return toTvdaveRequest;
  }
}
