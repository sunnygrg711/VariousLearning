package org.sk.tutorial.jfamily.concurrency.examples.session2_3;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Created by kshekar on 08/05/2018.
 */
public class AlienMethod {

    public static void alienMethod() throws InterruptedException{
        ExecutorService es = Executors.newSingleThreadExecutor();
        es.submit(() -> modifyLines());
        es.shutdown();
        es.awaitTermination(Long.MAX_VALUE, TimeUnit.SECONDS);
    }
    private static void modifyLines() {
    }
}
