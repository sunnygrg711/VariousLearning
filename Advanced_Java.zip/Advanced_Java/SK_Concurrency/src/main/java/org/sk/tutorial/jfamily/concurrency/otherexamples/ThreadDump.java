package org.sk.tutorial.jfamily.concurrency.otherexamples;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;

public class ThreadDump implements Runnable {
    public static void main(String[] args)
        throws Exception {

        long time = System.nanoTime();
        ThreadDump test = new ThreadDump();
        synchronized (test) {
            new Thread(test).start();
            while (test.cpu == -1) {
                test.wait();
                }
            }
        System.out.println("time: " + (System.nanoTime() - time));
        System.out.println("cpu: " + test.cpu);
        }

    private long cpu = -1;

    public synchronized void run() {
        try {
            ThreadMXBean thread = ManagementFactory.getThreadMXBean();
            for(long threadId:thread.getAllThreadIds()){
                System.out.println(thread.getThreadInfo(threadId));
            }
            long cpu = thread.getCurrentThreadCpuTime();
            Thread.sleep(300);
            long time = System.nanoTime();
            while (System.nanoTime() - time < 700000000);
            this.cpu = thread.getCurrentThreadCpuTime() - cpu;
            }
        catch (InterruptedException _) {}
        finally {
            notify();
            }
        }
    }