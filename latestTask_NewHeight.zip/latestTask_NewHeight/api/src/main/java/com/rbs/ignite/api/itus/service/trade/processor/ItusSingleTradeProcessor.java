package com.rbs.ignite.api.itus.service.trade.processor;


import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;

/**
 * Created by puronaa on 27/09/2017.
 */
public interface ItusSingleTradeProcessor<Trade extends ItusTrade>{
    ItusTradeStatus processTrade(Trade trade, String requestId) throws ItusException;
}
