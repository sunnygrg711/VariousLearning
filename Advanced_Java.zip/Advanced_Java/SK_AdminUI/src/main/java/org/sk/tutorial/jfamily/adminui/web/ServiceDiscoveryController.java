package org.sk.tutorial.jfamily.adminui.web;

import org.sk.tutorial.jfamily.adminui.model.Application;
import org.sk.tutorial.jfamily.adminui.model.State;
import org.sk.tutorial.jfamily.adminui.service.ApplicationUrlBehavior;
import org.sk.tutorial.jfamily.adminui.service.ServiceDiscoveryService;
import org.sk.tutorial.jfamily.devopsutility.exceptions.ExceptionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.*;

/**
 * Created by kshekar on 09/04/2018.
 */
@Controller
@RequestMapping("/ds/")
public class ServiceDiscoveryController {

    @Autowired
    private ServiceDiscoveryService discoveryService;

    @RequestMapping(value = "/application/{applicationName}", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<String> getApplicationByName( @PathVariable("applicationName") String applicationName) {
        Optional<Application> application=Optional.ofNullable(discoveryService.getApplicationByName(applicationName));
        ResponseEntity<String> entity;
        if(application.isPresent()){
            entity=new ResponseEntity(discoveryService.getApplicationByName(applicationName), HttpStatus.OK);
        }
        else{
            entity=new ResponseEntity<String>("Application is not found by given name :"+applicationName,HttpStatus.NOT_FOUND);
        }

        return entity;
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<String> register( @RequestBody Application application) {
       Boolean registerStatus= discoveryService.register(application);
        ResponseEntity<String> entity;
        if(registerStatus){
            entity=new ResponseEntity("Registered successfully!!!.", HttpStatus.OK);
        }
        else{
            entity=new ResponseEntity<String>("Application is not register ",HttpStatus.INSUFFICIENT_STORAGE);
        }
        return entity;
    }

    @RequestMapping(value = "/allApplications", method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<List<Application>> getAllActiveApplications() {
        List<Application> applications= discoveryService.getAllActiveApplications();
        ResponseEntity<List<Application>> entity;
        if(null!=applications){
            entity=new ResponseEntity(applications, HttpStatus.OK);
        }
        else{
            entity=new ResponseEntity<List<Application>>(new ArrayList<>(null),HttpStatus.PARTIAL_CONTENT);
        }
        return entity;
    }

    @Bean
   private  RestTemplate getRestTemplate(){
        return new RestTemplate();
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<List<Application>> updateStatus() {
        List<Application> applications= new ArrayList<>(discoveryService.getAllActiveApplications());
        final RestTemplate restTemplate=getRestTemplate();
        applications.stream().filter(application -> !application.getState().equals(State.TERMINATED)).forEach(application -> {
            HttpHeaders httpHeaders=new HttpHeaders();
            httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON_UTF8));
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            ResponseEntity responseEntity= ExceptionUtil.execute(()->restTemplate.exchange(ApplicationUrlBehavior.getHeartBeatUrl(application), HttpMethod.GET,new HttpEntity<String>("param",httpHeaders),Boolean.class));
        if(responseEntity==null || !responseEntity.getStatusCode().equals(HttpStatus.OK)){
            discoveryService.updateState(application.getApplicationName());
        }
        });
        ResponseEntity<List<Application>> entity=new ResponseEntity(discoveryService.getAllActiveApplications(), HttpStatus.OK);
        return entity;
    }

    @RequestMapping(value = "/remove", method = RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<String> remove( @RequestBody Application application) {
        Boolean registerStatus= Optional.ofNullable(discoveryService.unregister(application.getApplicationName())).isPresent();
        ResponseEntity<String> entity;
        if(registerStatus){
            entity=new ResponseEntity("Unregistered successfully!!!.", HttpStatus.OK);
        }
        else{
            entity=new ResponseEntity<String>("Application is not unregister ",HttpStatus.INSUFFICIENT_STORAGE);
        }
        return entity;
    }

}
