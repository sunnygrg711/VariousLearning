package com.rbs.ignite.domain.itus.trade.totv.dave;

public class TotvDaveRequest {
  private Identifier target;
  private String isin;

  public Identifier getTarget() {
    return target;
  }

  public void setTarget(Identifier target) {
    this.target = target;
  }

  public String getIsin() {
    return isin;

  }
  public void setIsin(String isin) {
    this.isin = isin;
  }
  @Override
  public String toString() {
    return "TotvDaveRequest{" +
            "target=" + target +
            ", isin='" + isin + '\'' +
            '}';
  }
}