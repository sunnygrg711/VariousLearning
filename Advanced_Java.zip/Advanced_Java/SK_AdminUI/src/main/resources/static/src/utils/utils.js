define([], function() {

	var utils = function() {},setDataForClipboard="";

	String.prototype.toProperCase = function () {
    return this.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
};
	utils.mergeAndStripObject = function(obj1, obj2) {
		var clone = {};

		if (obj2 === null) {
			clone = $.extend(true, clone, obj1);
		} else {
			clone = $.extend(true, clone, obj1, obj2);
		}

		return utils.stripObject(clone);
	};

	/**
	 * Strip inbound object
	 * @param objIn
	 * @returns
	 */
	utils.stripObject = function(objIn) {
		// Zap named attr

		delete objIn.$$hashKey;
		delete objIn.__ng_selected__;

		// Zap null attrs

		var attrIdx;

		for (attrIdx in objIn) {
			var attr = objIn[attrIdx];

			if (attr === null || attr === "null" || attr === "undefined") {
				delete objIn[attrIdx];
			} else if (attr instanceof Function) {
				// Do nothing
			} else if (attr instanceof Object) {
				utils.stripObject(attr);
			} else if (attrIdx.charAt(0) == '$') {
				// Client-side attribute only!
				delete objIn[attrIdx];
			}
		}

		return objIn;
	};
	utils.isValidEmail = function(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
	utils.getBaseAppUrl= function()
		{
			var pathArray = window.location.pathname.split('/');
			var origin = window.location.origin;

			// IE work around
			if (origin === null) {
				var url = window.location + "";
				var parts = url.split('/');

				origin = parts[0] + "//" + parts[2];
			}
			return origin + "/" + pathArray[1];
		};
		utils.getCookie = function(cname){
			var name = cname + "=",
                ca = document.cookie.split(';');
            for(var i=0; i<ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0)==' ') c = c.substring(1);
                if (c.indexOf(name) != -1) return c.substring(name.length,c.length);
            }
            return "";
        };
        utils.mergeAndStripObject = function(obj1, obj2) {
        		var clone = {};

        		if (obj2 === null) {
        			clone = $.extend(true, clone, obj1);
        		} else {
        			clone = $.extend(true, clone, obj1, obj2);
        		}

        		return utils.stripObject(clone);
        	};

        	/**
        	 * Strip inbound object
        	 * @param objIn
        	 * @returns
        	 */
        	utils.stripObject = function(objIn) {
        		// Zap named attr

        		delete objIn.$$hashKey;
        		delete objIn.__ng_selected__;

        		// Zap null attrs

        		var attrIdx;

        		for (attrIdx in objIn) {
        			var attr = objIn[attrIdx];

        			if (attr === null || attr === "null" || attr === "undefined") {
        				delete objIn[attrIdx];
        			} else if (attr instanceof Function) {
        				// Do nothing
        			} else if (attr instanceof Object) {
        				utils.stripObject(attr);
        			} else if (attrIdx.charAt(0) == '$') {
        				// Client-side attribute only!
        				delete objIn[attrIdx];
        			}
        		}

        		return objIn;
        	};
        	utils.getCookie = function (name) {
                                var re = new RegExp(name + "=([^;]+)");
                                var value = re.exec(document.cookie);
                                return (value != null) ? decodeURIComponent(value[1]) : null;
                    };
            utils.getUserId=function() {
            			var SSOTokenAlt = utils.getCookie('SSOTOKEN');
            			var userId = unescape(SSOTokenAlt).split("|");
            			return userId[2];
            		};
            var metricsEach = function(d, i) {
                    				/*self.nowShowingCount = d.rows.length;
                    				var selectedQueue = _.filter(self.$scope.queueObj, function(item) {
                    					return item.id === self.$scope.genericData.queueSelected;
                    				})[0];
                    				self.nowShowing(selectedQueue);
                    				self.$scope.safeApply();*/
                    			};

             var metrics = function (s) {
                    				s.each(metricsEach);
                    			};

             utils.createMetrics= function() {
                    				return metrics;
                    			}
utils.initCopyToClipboard = function(id){
                     document.getElementById(id)
                                    			 .addEventListener('copy', function (e) {
                                                       if (e.clipboardData) {
                                                           e.preventDefault();
                                                           e.clipboardData.setData('text/plain',  getDataForClipboard());
                                                       }
                                                       if (window.clipboardData) {
                                                           e.returnValue = false;
                                                           window.clipboardData.setData('text/plain', getDataForClipboard());
                                                       }
                                                   }, false)


};
utils.JSONToCSVConvertor =function (JSONData, ReportTitle, ShowLabel, excludePropsKeys) {
    //If JSONData is not an object then JSON.parse will parse the JSON string in an Object
    var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;

    var CSV = '';
    //Set Report title in first row or line

    //CSV += ReportTitle + '\r\n\n';

    //This condition will generate the Label/Header
    if (ShowLabel) {
        var row = "";

        //This loop will extract the label from 1st index of on array
        for (var index in arrData[0]) {


            if(!excludePropsKeys || !excludePropsKeys.length){
                row += index + ',';
            }else{
                    for( var key=0; key<excludePropsKeys.length; key++){
                            if(index !== excludePropsKeys[key]){
                                row += index + ',';
                            }
                        }
                      }
            //Now convert each value to string and comma-seprated

        }

        row = row.slice(0, -1);

        //append Label row with line break
        CSV += row + '\r\n';
    }

    //1st loop is to extract each row
    for (var i = 0; i < arrData.length; i++) {
        var row = "";

        //2nd loop will extract each column and convert it in string comma-seprated
        for (var index in arrData[i]) {

            if(!excludePropsKeys || !excludePropsKeys.length){
                  row += '"' + arrData[i][index] + '",';
             }else{
                for( var key=0; key<excludePropsKeys.length; key++){
                                if(index !== excludePropsKeys[key]){
                                   row += '"' + arrData[i][index] + '",';
                                }
                            }
             }

        }

        row = row.slice(0, row.length - 1);

        //add a line break after each row
        CSV += row + '\r\n';
    }

    if (CSV == '') {
        alert("Invalid data");
        return;
    }

    //Generate a file name
    var fileName = "MyReport_";
    //this will remove the blank-spaces from the title and replace it with an underscore
    fileName += ReportTitle.replace(/ /g,"_");
utils.CSVOtherMethod(CSV, fileName)

};
utils.CSVOtherMethod= function(data, fileName ){
var csvData = data,fileName = fileName + ".csv";
        var blob = new Blob([ csvData ], {
            type : "application/csv;charset=utf-8;"
        });

        if (window.navigator.msSaveBlob) {
            // FOR IE BROWSER
            navigator.msSaveBlob(blob, fileName);
        } else {
            // FOR OTHER BROWSERS
            var link = document.createElement("a");
            var csvUrl = URL.createObjectURL(blob);
            link.href = csvUrl;
            link.style = "visibility:hidden";
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
}
};

utils.setDataForClipboard = function(data){
setDataForClipboard = data;
};
var getDataForClipboard = function(){
        return setDataForClipboard;
};
utils.sortObject =function(obj) {
                     return Object.keys(obj).sort().reduce(function (result, key) {
                         result[key] = obj[key];
                         return result;
                     }, {});
                 };
Array.prototype.getIndexBy = function (name, value) {
          for (var i = 0; i < this.length; i++) {
              if (this[i]['id'] === name) {
                  return i;
              }
          }
          return -1;
      }
	return utils;

});
