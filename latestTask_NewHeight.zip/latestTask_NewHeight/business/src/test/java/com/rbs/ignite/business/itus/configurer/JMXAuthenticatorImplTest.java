package com.rbs.ignite.business.itus.configurer;

import com.rbs.gbm.rates.core.auth.security.AuthenticationService;
import com.rbs.ignite.business.itus.util.CommonConstantsUtil;
import com.rbs.ignite.business.itus.util.SecurityUtil;
import com.rbs.rates.foundation.security.SecurityProvider;
import com.rbs.rates.foundation.security.rss.RssClient;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.security.auth.Subject;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by kumaunn on 31/03/2018.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ SecurityContextHolder.class, SecurityUtil.class})
@PowerMockIgnore({"javax.management.*", "javax.security.*"})
public class JMXAuthenticatorImplTest {

  private JMXAuthenticatorImpl jmxAuthenticator ;

  private SecurityProvider serviceProvider;

  @Mock
  private SecurityContext context;

  @Mock
  private AuthenticationService service;

  @Mock
  private RssClient client;

  @Mock
  private Authentication authentication;

  @Mock
  private Collection<GrantedAuthority> grantedAuthorities;

  private String [] credentials;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    PowerMockito.mockStatic(SecurityContextHolder.class);
    serviceProvider = new SecurityProvider(service, client, "TOTV");
    jmxAuthenticator = new JMXAuthenticatorImpl(serviceProvider);
  }

  @Test(expected = SecurityException.class)
  public void testValidateCredentialsSecurityException() {
    jmxAuthenticator.authenticate("TOTV");
  }

  @Test(expected = SecurityException.class)
  public void testAuthenticateSecurityException() {
    credentials = new String [] {"TOTV", "TOTV"};
    jmxAuthenticator.authenticate(credentials);
  }

  @Test
  public void testAuthenticate() {
    PowerMockito.when(SecurityContextHolder.getContext()).thenReturn(context);
    PowerMockito.when(context.getAuthentication()).thenReturn(authentication);
    credentials = new String [] {"TOTV", "TOTV"};
    Subject sub = jmxAuthenticator.authenticate(credentials);
    Assert.assertNotNull(sub);
  }

  @Test
  public void testCreateSubject() {
    Set<String> values = new HashSet<>();
    values.add(CommonConstantsUtil.WRITE_ROLE_NAME);
    PowerMockito.mockStatic(SecurityUtil.class);
    PowerMockito.when(SecurityUtil.toRoleNames(Mockito.anyCollection())).thenReturn(values);
    PowerMockito.when(SecurityContextHolder.getContext()).thenReturn(context);
    PowerMockito.when(context.getAuthentication()).thenReturn(authentication);
    credentials = new String [] {"TOTV", "TOTV"};
    Subject sub = jmxAuthenticator.authenticate(credentials);
    Assert.assertNotNull(sub);
  }
}
