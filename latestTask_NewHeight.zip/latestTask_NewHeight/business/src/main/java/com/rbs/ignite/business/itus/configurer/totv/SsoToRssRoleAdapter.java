package com.rbs.ignite.business.itus.configurer.totv;

import com.google.common.collect.Sets;
import com.rbs.gbm.rates.core.auth.security.AuthenticationService;
import com.rbs.rates.foundation.security.domain.RssUserResponse;
import com.rbs.rates.foundation.security.exception.AuthorisationException;
import com.rbs.rates.foundation.security.rss.RssClient;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class SsoToRssRoleAdapter implements RssClient {

  private static final String WRITE_ROLE_NAME = "ROLE_WRITE";
  private static final String READ_ROLE_NAME = "ROLE_TRADE_WRITE";
  private final AuthenticationService authenticationService;
  private final String ssoReadPermissionName;
  private final String ssoWritePermissionName;
  private Map<String, Set<String>> roleVsTokenDataMap = new ConcurrentHashMap<String, Set<String>>();

  public SsoToRssRoleAdapter(AuthenticationService authenticationService, String ssoReadPermissionName,
                             String ssoWritePermissionName) {
    this.authenticationService = authenticationService;
    this.ssoReadPermissionName = ssoReadPermissionName;
    this.ssoWritePermissionName = ssoWritePermissionName;
  }

  @Override
  public Set<String> getRoleNames(String userName, String token) throws AuthorisationException {
    Set<String> roleNames = Sets.newHashSet();

    if (!roleVsTokenDataMap.isEmpty() && roleVsTokenDataMap.containsKey(token)) {
      return roleVsTokenDataMap.get(token);
    }

    // does this token encapsulate the read permission? 
    if (authenticationService.isValidToken(token, ssoReadPermissionName)) {
      roleNames.add(READ_ROLE_NAME);
    }

    // does this token encapsulate the write permission? 
    if (authenticationService.isValidToken(token, ssoWritePermissionName)) {
      roleNames.add(WRITE_ROLE_NAME);
    }

    // before returning , lets cache permissions against roleVsTokenDataMap.
    roleVsTokenDataMap.put(token,roleNames);
    return roleNames;
  }

  @Override
  public RssUserResponse getPermissions(String userName, String token) {
    RssUserResponse rssUserResponse = new RssUserResponse();
    rssUserResponse.getRoleNames().addAll(getRoleNames(userName, token));
    rssUserResponse.setUserName(userName);
    return rssUserResponse;
  }

}