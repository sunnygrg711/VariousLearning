package com.rbs.ignite.domain.itus.trade.totv;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import javax.validation.constraints.NotNull;

/**
 * Created by puronaa on 19/09/2017.
 */
public class TotvTrade implements ItusTrade {

  private String isin;
  @NotNull
  private String tradeIdentifier;
  @NotNull
  private ItusTradeSourceSystem sourceSystem;
  @NotNull
  private String location;

  public TotvTrade(@JsonProperty("isin") String isin, @JsonProperty("tradeIdentifier") String tradeIdentifier,
                   @JsonProperty("sourceSystem") ItusTradeSourceSystem sourceSystem, @JsonProperty("location") String location) {
    this.isin = isin;
    this.tradeIdentifier = tradeIdentifier;
    this.sourceSystem = sourceSystem;
    this.location = location;
  }

  @Override
  public String getIsin() {
    return isin;
  }

  @Override
  public String getTradeIdentifier() {
    return tradeIdentifier;
  }

  @JsonProperty("sourceSystem")
  @Override
  public ItusTradeSourceSystem getItusTradeSourceSystem() {
    return sourceSystem;
  }

  @Override
  public String getLocation() {
    return location;
  }
  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvTrade totvTrade = (TotvTrade) o;

    if (!tradeIdentifier.equals(totvTrade.tradeIdentifier)) return false;
    if (sourceSystem != totvTrade.sourceSystem) return false;
    return location.equals(totvTrade.location);
  }
  @Override
  public int hashCode() {
    int result = tradeIdentifier.hashCode();
    result = 31 * result + sourceSystem.hashCode();
    result = 31 * result + location.hashCode();
    return result;
  }
  @Override
  public String toString() {
    return "TotvTrade{" +
            "isin='" + isin + '\'' +
            ", tradeIdentifier='" + tradeIdentifier + '\'' +
            ", itusTradeSourceSystem=" + sourceSystem +
            ", location='" + location + '\'' +
            '}';
  }
}
