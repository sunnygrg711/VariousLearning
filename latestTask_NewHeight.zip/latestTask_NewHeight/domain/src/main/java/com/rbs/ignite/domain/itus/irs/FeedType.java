package com.rbs.ignite.domain.itus.irs;

public enum FeedType {

  FULL("full"), DELTA("delta");

  private String type;

  private FeedType(String type) {
    this.type = type;
  }

  public String getType() {
    return type;
  }

}
