package com.rbs.ignite.business.itus.configurer.totv;



import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessor;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import java.util.concurrent.ConcurrentMap;

/**
 * Created by puronaa on 06/10/2017.
 */
public class TradeSystemToProcessorMapper {
    ConcurrentMap<ItusTradeSourceSystem,ItusTradeProcessor> map;

    public TradeSystemToProcessorMapper(ConcurrentMap<ItusTradeSourceSystem, ItusTradeProcessor> map) {
        this.map = map;
    }

    public ItusTradeProcessor getProcessor(ItusTradeSourceSystem itusTradeSourceSystem){
        return map.get(itusTradeSourceSystem);
    }
}
