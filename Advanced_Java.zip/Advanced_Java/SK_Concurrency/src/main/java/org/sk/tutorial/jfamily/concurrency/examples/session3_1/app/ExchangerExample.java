package org.sk.tutorial.jfamily.concurrency.examples.session3_1.app;

import org.sk.tutorial.jfamily.concurrency.examples.session3_1.Ping;
import org.sk.tutorial.jfamily.concurrency.examples.session3_1.Pong;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;

public class ExchangerExample {

    public static void main(String[] args) throws InterruptedException {
        Exchanger<String> exchanger=new Exchanger<>();
       Ping ping=new Ping(exchanger);
       Pong pong=new Pong(exchanger);
        new Thread(ping,"Thread-Ping").start();
        new Thread(pong,"Thread-Pong").start();

    }
}
