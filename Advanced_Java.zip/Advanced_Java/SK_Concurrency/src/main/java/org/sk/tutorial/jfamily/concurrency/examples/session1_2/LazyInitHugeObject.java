package org.sk.tutorial.jfamily.concurrency.examples.session1_2;


import org.sk.tutorial.jfamily.concurrency.annotation.NotThreadSafe;

@NotThreadSafe(reason = "check-then-act")
public class LazyInitHugeObject {

    private HugeObject hugeObject;

    public  HugeObject getHugeObject(){
        if(hugeObject==null){
            hugeObject= new HugeObject();
        }
        return hugeObject;
    }
    public void reset(){
        hugeObject=null;
    }
}
