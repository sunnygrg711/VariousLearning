package com.rbs.ignite.business.itus.service.trade.processor.totv.gfx;


import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.business.itus.jmx.TotvJmxProvider;
import com.rbs.ignite.business.itus.service.trade.processor.AbstractTradeProcessor;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatusHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;

public class TotvGfxTradeProcessor extends AbstractTradeProcessor {

  private static final Logger logger = LoggerFactory.getLogger(TotvGfxTradeProcessor.class);

  @Autowired
  private TotvJmxProvider totvJmxProvider;

  public TotvGfxTradeProcessor(ExecutorService executorService, ItusSingleTradeProcessor itusSingleTradeProcessor) {
    super(executorService, itusSingleTradeProcessor);
  }

  @Override
  public TotvTradeStatusHolder processTrades(TotvTradeHolder tradeHolder, String requestId, Boolean byPassThreshold) throws ItusException {
    ItusTradeSourceSystem tradeSourceSystem = tradeHolder.getTradeSourceSystem();
    logger.info(requestId+":"+"Processing Trades for " + tradeSourceSystem);
    Set<TotvTrade> tradeSet = tradeHolder.getTradeSet();

    if (!tradeSourceSystem.equals(ItusTradeSourceSystem.GFX)) {
      throw new ItusFatalErrorException("Trades were routed to wrong Service " + tradeSourceSystem);
    }

    TotvTradeStatusHolder totvTradeStatusHolder = null;
    Set<TotvTradeStatus> tradeStatusSet;
    if (tradeSet.isEmpty()) {
      logger.info(requestId+":"+"No trades to process for: " + tradeSourceSystem);
      tradeStatusSet= new HashSet<>();
    } else if (byPassThreshold || totvJmxProvider.getGfxThresholdLimit() >= tradeSet.size()){
      tradeStatusSet = call(tradeHolder.getTradeSet(),requestId);
    }else{
      logger.error("Threshold limit {} for {} source system has reached .Hence trades cannot be send for amendment." , totvJmxProvider.getGfxThresholdLimit(),tradeSourceSystem);
      tradeStatusSet = new HashSet<>();
      tradeSet.forEach((trade)->{
        tradeStatusSet.add(new TotvTradeStatus.TotvTradeStatusBuilder(trade, ItusStatus.THRESHOLD_BREACHED,"-1").build());
      });
    }

    totvTradeStatusHolder=new TotvTradeStatusHolder(tradeSourceSystem,tradeStatusSet);
    logger.info(requestId+":"+"totvTradeStatusHolder: " + totvTradeStatusHolder);
    return totvTradeStatusHolder;
  }

}
