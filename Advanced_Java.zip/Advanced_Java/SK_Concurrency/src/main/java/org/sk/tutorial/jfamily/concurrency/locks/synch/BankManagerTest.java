package org.sk.tutorial.jfamily.concurrency.locks.synch;


import org.sk.tutorial.jfamily.concurrency.locks.Bank;
import org.sk.tutorial.jfamily.concurrency.locks.TransferRunnable;

/**
   This program shows how multiple threads can safely access a data structure.
*/
public class BankManagerTest
{
   public static final int NO_OF_ACCOUNTS = 4;
   public static final double INITIAL_BALANCE = 1000;
   public static void main(String[] args)
   {  
      BankManager bankManager = new BankManager(NO_OF_ACCOUNTS, INITIAL_BALANCE);
      int i;
      for (i = 0; i < NO_OF_ACCOUNTS; i++)
      {  
         TransferRunnable r = new TransferRunnable(bankManager, i, INITIAL_BALANCE);
         Thread t = new Thread(r);
          t.start();
      }
   }
}

