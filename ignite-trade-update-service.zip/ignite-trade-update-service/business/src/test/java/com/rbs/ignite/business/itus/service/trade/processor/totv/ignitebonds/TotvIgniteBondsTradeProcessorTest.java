package com.rbs.ignite.business.itus.service.trade.processor.totv.ignitebonds;

import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatusHolder;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.concurrent.ExecutorService;

/**
 * Created by upadkti on 10/11/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class TotvIgniteBondsTradeProcessorTest {
  @Mock
  private ExecutorService executorService;
  @Mock
  private ItusSingleTradeProcessor itusSingleTradeProcessor;
  @Mock
  private TotvTradeHolder totvTradeHolder;
  @Mock
  private TotvTrade totvTrade;
  @Mock
  private TotvTradeStatus totvTradeStatus;

  @Rule
  public ExpectedException thrown= ExpectedException.none();

  private TotvIgniteBondsTradeProcessor testObj;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    testObj = new TotvIgniteBondsTradeProcessor(itusSingleTradeProcessor);
  }

  @After
  public void tearDown() {
    testObj = null;
  }

  @Test
  public void testProcessingOneTrade() throws Exception {
    Mockito.when(totvTradeHolder.getTradeSourceSystem()).thenReturn(ItusTradeSourceSystem.IGNITE);
    Mockito.when(totvTradeHolder.getTradeSet()).thenReturn(Sets.newSet(totvTrade));
    Mockito.when(itusSingleTradeProcessor.processTrade(totvTrade)).thenReturn(totvTradeStatus);
    TotvTradeStatusHolder tradeStatus = testObj.processTrades(totvTradeHolder);
    Assert.assertEquals(tradeStatus.getTradeSourceSystem(),ItusTradeSourceSystem.IGNITE);
    Assert.assertTrue(tradeStatus.getTradeStatusSet().contains(totvTradeStatus));
  }

  @Test
  public void testProcessingNoTrade() throws Exception {
    Mockito.when(totvTradeHolder.getTradeSourceSystem()).thenReturn(ItusTradeSourceSystem.IGNITE);
    Mockito.when(totvTradeHolder.getTradeSet()).thenReturn(Sets.newSet());
    TotvTradeStatusHolder tradeStatus = testObj.processTrades(totvTradeHolder);
    Assert.assertTrue(tradeStatus.getTradeStatusSet().size()==0);
  }

  @Test
  public void testProcessorThrowsExceptionIfSourceSystemIsNotIgniteBonds() throws Exception {
    Mockito.when(totvTradeHolder.getTradeSourceSystem()).thenReturn(ItusTradeSourceSystem.DAVE);
    Mockito.when(totvTradeHolder.getTradeSet()).thenReturn(Sets.newSet());
    thrown.expect(ItusFatalErrorException.class);
    thrown.expectMessage("Trades were routed to wrong Service ItusTradeSourceSystem{name='DAVE'}");
    TotvTradeStatusHolder tradeStatus = testObj.processTrades(totvTradeHolder);
  }
}

