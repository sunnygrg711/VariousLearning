package org.sk.tutorial.jfamily.concurrency.examples.session1_2;


public class HugeObject {
    @Override
    public String toString() {
        return "HugeObject{"+super.hashCode()+"}";
    }
}
