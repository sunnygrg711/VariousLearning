package org.sk.tutorial.jfamily.concurrency.otherexamples;

/**
 * Created by kshekar on 22/03/2018.
 */
public class PrintSleep {

    public static void main(String[] args) {
        long startSleepTime = System.currentTimeMillis();
        try {
            Thread.sleep(1000);   // sleep for 5 seconds (5000 milliseconds)
        } catch (InterruptedException ie) {
            System.out.println("Oh no!");
        }
        long endSleepTime = System.currentTimeMillis();
        System.out.println("Finished sleeping. Slept for " + (endSleepTime - startSleepTime) + " milliseconds");
    }
}
