package org.sk.tutorial.jfamily.adminui.model;

import org.sk.tutorial.jfamily.devopsutility.model.OurMap;

/**
 * Created by kshekar on 25/04/2018.
 */
public class MyRunnable implements Runnable {

    @Override
    public void run() {
        try{
            int timer=100;
            while(timer-->0){
                Thread.sleep(1000);
                System.out.println(Thread.currentThread()+"Timer..."+timer);
            }
            System.out.println(new OurMap().getMapString());
        }
        catch (Exception e){

        }
    }
}
