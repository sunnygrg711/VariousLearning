package org.sk.tutorial.jfamily.devopsutility;

import org.sk.tutorial.jfamily.devopsutility.service.AbstractApplicationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by kshekar on 02/04/2018.
 */
public class Devopsutility {
   static protected Logger logger;
  static AtomicInteger counter=new AtomicInteger(1);
    public static void main(String[] args) throws InterruptedException {

        System.setProperty("LOG.FILE","DevOpsUtility");
        System.setProperty("PlatformName",  ManagementFactory.getRuntimeMXBean().getName());
        System.setProperty("log4j.configuration", Devopsutility.class.getClassLoader().getResource("log4j-service.xml").toString());
        logger = LoggerFactory.getLogger(Devopsutility.class);
        DevOpsManager.get().initialise();

        final List<String> iAmCauseForOutOfMemoryIssue=new ArrayList<>();
        new Thread(()->{
            while(true){
                try {
                    Thread.sleep(5000);
                    if( counter.getAndIncrement()%10==5){
                        AbstractApplicationService abstractApplicationService=new AbstractApplicationService() {
                            @Override
                            public void initApplicationDetail() {

                            }
                        };
                        System.out.println(abstractApplicationService.downloadHeapDump(System.getProperty("PlatformName").split("@")[0]));
                        System.out.println( abstractApplicationService.getGcDetail());
                    }
                   ;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println( DevOpsManager.get().getAllDevOpsData());
                iAmCauseForOutOfMemoryIssue.add(new Object().toString());
            }
        }).start();

        new Thread() {
            final Object sticky = new Object();

            @Override
            public void run() {
                synchronized (sticky) {
                    try {
                        sticky.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();

    }
}
