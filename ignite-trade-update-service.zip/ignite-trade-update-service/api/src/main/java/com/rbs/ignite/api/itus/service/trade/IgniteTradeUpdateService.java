package com.rbs.ignite.api.itus.service.trade;

import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentData;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentInput;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;

import java.time.LocalDate;
import java.util.Set;

public interface IgniteTradeUpdateService<Data extends ItusInstrumentData, Trade extends ItusTrade,Status extends ItusTradeStatus> {
    Set<Status> updateForInstrumentInput(ItusInstrumentInput instrumentInput) throws ItusException;
    Set<Status> updateForTrades(Set<Trade> tradeSet);
    Set<Status> updateForInstrumentsData(Set<Data> instrumentDataSet, LocalDate localDate);
}