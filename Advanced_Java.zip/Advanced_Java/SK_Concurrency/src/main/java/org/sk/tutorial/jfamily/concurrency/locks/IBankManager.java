package org.sk.tutorial.jfamily.concurrency.locks;

/**
 * Created by kshekar on 22/03/2018.
 */
public interface IBankManager {
     Bank getBank();
     BalanceViewable getBalanceViewable();
     Transferable getTransferable();
}
