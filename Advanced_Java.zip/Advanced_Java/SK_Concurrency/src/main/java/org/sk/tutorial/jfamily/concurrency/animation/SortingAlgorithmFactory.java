package org.sk.tutorial.jfamily.concurrency.animation;

import com.rbs.collateral.microservice.base.common.exceptions.ExceptionUtil;

/**
 * Created by kshekar on 23/03/2018.
 */
public class SortingAlgorithmFactory {
    private static SortingAlgorithmFactory sortingAlgorithmFactory=new SortingAlgorithmFactory();
    private  SortingAlgorithmFactory(){}

    public static SortingAlgorithmFactory getInstance() {
        return sortingAlgorithmFactory;
    }
    public SorterRunnable getSortingAlgorithm(Double[] sortableValues, ArrayPanel arrayPanelToDisplayValues,String sortingAlgorithmName){
        SortingAlgorithmTypes type= ExceptionUtil.execute(()->SortingAlgorithmTypes.valueOf(sortingAlgorithmName));
            if(SortingAlgorithmTypes.JAVA_DEFAULT_API.equals(type)){
                return  new JavaApiSort(sortableValues,arrayPanelToDisplayValues);
            }else if(SortingAlgorithmTypes.BUBBLE.equals(type)){
                return  new BubbleSort(sortableValues,arrayPanelToDisplayValues);
            }
            else if(SortingAlgorithmTypes.SELECTION.equals(type)){
                return  new SelectionSort(sortableValues,arrayPanelToDisplayValues);
            }
            else if(SortingAlgorithmTypes.QUICK.equals(type)){
                return  new QuickSort(sortableValues,arrayPanelToDisplayValues);
            }
            else if(SortingAlgorithmTypes.HEAP.equals(type)){
                return  new HeapSort(sortableValues,arrayPanelToDisplayValues);
            }
        return new JavaApiSort(sortableValues,arrayPanelToDisplayValues);
    }
}
