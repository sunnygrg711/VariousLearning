package com.rbs.ignite.business.itus.transformer.systemx;


import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.systemx.TotvSystemXRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;

/**
 * Tranformer class which uses conversion utility to convert totv trade to systemx
 */
public class TotvTradeToSystemXReqTransformer implements ItusTransformer<TotvTrade, TotvSystemXRequest> {

  @Autowired
  ConversionService conversionService;

  @Override
  public TotvSystemXRequest transform(TotvTrade totvTrade) throws ItusTransformException {
    TypeDescriptor sourceType = TypeDescriptor.valueOf(TotvTrade.class);
    TypeDescriptor targetType = TypeDescriptor.valueOf(TotvSystemXRequest.class);
    TotvSystemXRequest totvSystemxRequest = (TotvSystemXRequest) conversionService.convert(totvTrade, sourceType, targetType);
    return totvSystemxRequest;
  }
}
