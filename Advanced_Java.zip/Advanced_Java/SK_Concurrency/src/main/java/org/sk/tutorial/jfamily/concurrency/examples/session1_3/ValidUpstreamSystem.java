package org.sk.tutorial.jfamily.concurrency.examples.session1_3;

import org.sk.tutorial.jfamily.concurrency.annotation.Immutable;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by kshekar on 01/05/2018.
 */
@Immutable
public final class ValidUpstreamSystem {

    private final Set<String> upstreamSystems = new HashSet<>();

    public ValidUpstreamSystem(){
        upstreamSystems.add("ODC" );
        upstreamSystems.add("MDX" );
        upstreamSystems.add("RDX" );
        upstreamSystems.add("ARGON" );
    }
    public boolean isValidSystem(String name){
        return  upstreamSystems.contains(name);
    }
}
