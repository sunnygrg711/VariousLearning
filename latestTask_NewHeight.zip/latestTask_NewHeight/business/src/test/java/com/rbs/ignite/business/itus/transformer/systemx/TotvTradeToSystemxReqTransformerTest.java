package com.rbs.ignite.business.itus.transformer.systemx;

import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.systemx.TotvSystemXRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.eq;

@RunWith(SpringJUnit4ClassRunner.class)
public class TotvTradeToSystemxReqTransformerTest {

  @InjectMocks
  private TotvTradeToSystemXReqTransformer systemxTradeTransformerObj;
  @Mock
  ConversionService conversionService;
  @Mock
  private TotvTrade totvTrade;
  private TotvSystemXRequest totvSystemxRequest;
  private TypeDescriptor sourceType;
  private TypeDescriptor targetType;


  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    totvSystemxRequest = new TotvSystemXRequest();
    totvSystemxRequest.setTransactionIdentifier("systemxIdentifier");
    sourceType = TypeDescriptor.valueOf(TotvTrade.class);
    targetType = TypeDescriptor.valueOf(TotvSystemXRequest.class);
  }

  @After
  public void tearDown() {
    systemxTradeTransformerObj = null;
  }

  @Test
  public void testTransform() throws ItusTransformException {
    Mockito.when(conversionService.convert(Mockito.anyObject(), eq(sourceType), eq(targetType))).thenReturn(totvSystemxRequest);
    TotvSystemXRequest systemXRequest = systemxTradeTransformerObj.transform(totvTrade);
    assertEquals("systemxIdentifier", systemXRequest.getTransactionIdentifier());
  }

}
