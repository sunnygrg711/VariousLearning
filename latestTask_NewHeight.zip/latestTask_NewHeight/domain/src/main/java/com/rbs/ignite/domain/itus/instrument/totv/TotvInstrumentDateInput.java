package com.rbs.ignite.domain.itus.instrument.totv;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentDateInput;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

public class TotvInstrumentDateInput implements ItusInstrumentDateInput {

  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
  private LocalDate date;

  @Override
  public LocalDate getDate() {
    return date;
  }

  public TotvInstrumentDateInput(@JsonProperty("date") LocalDate date) {
    this.date = date;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof TotvInstrumentDateInput)) return false;

    TotvInstrumentDateInput that = (TotvInstrumentDateInput) o;

    return date.equals(that.date);
  }

  @Override
  public int hashCode() {
    return date.hashCode();
  }

  @Override
  public String toString() {
    return "TotvInstrumentDateInput{" +
            "date=" + date +
            '}';
  }
}
