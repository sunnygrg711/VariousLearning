package org.sk.tutorial.jfamily.adminui.model;

/**
 * Created by kshekar on 25/04/2018.
 */
public class ThreadManager {

  public  static void start(int noOfThread, int noOfRunnable){
        for(int i=1;i<noOfThread;i++){
            new MyThread("MyThread-"+i).start();
        }

        for(int i=1;i<noOfRunnable;i++){
            new Thread(new MyRunnable(),"MyRunnable-"+i).start();
        }
    }
}
