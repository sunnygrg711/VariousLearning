package com.rbs.ignite.business.itus.mgmt;

import com.rbs.ignite.business.itus.configurer.totv.util.TotvConfigurationUtil;
import com.rbs.ignite.domain.itus.odc.OdcConnectionInput;
import com.rbs.odc.access.ODC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Component;

/**
 * Created by kumaunn on 12/12/2017.
 */
@Component
public class OdcHealthIndicator extends AbstractHealthIndicator {

  private @Value("${odc.environment}")
  String odcEnvironment;
  private @Value("${odc.user.id}")
  String odcUser;
  private @Value("${odc.password}")
  String odcPassword;
  private @Value("${odc.initialisationTimeoutMillis}") String odcInitialisationTimeoutMillis;
  private @Value("${odc.retryCount}")
  String odcRetryCount;
  private @Value("${odc.executionTimeoutMillis}") String odcExecutionTimeoutMillis;
  private @Value("${odc.blender.enabled}")
  String odcBlenderEnabled;
  private @Value("${odc.osl.http.host}")
  String odcOslHost;
  private @Value("${odc.osl.http.port}")
  String odcOslPort;
  private static final Logger logger = LoggerFactory.getLogger(TotvConfigurationUtil.class);

  @Override
  protected void doHealthCheck(Health.Builder builder) throws Exception {

    OdcConnectionInput odcConnectionInput= new OdcConnectionInput(odcEnvironment,odcUser,odcPassword,odcInitialisationTimeoutMillis,odcRetryCount,odcExecutionTimeoutMillis,odcBlenderEnabled,odcOslHost,odcOslPort);

    try {
      ODC odc= new TotvConfigurationUtil().getOdcObject(odcConnectionInput);
      if (odc !=null) {
        builder.withDetail("Env " ,"Odc").status(Status.UP);
      }else{
        builder.withDetail("Env " ,"Odc").status(Status.DOWN);

      }
    } catch (Exception e) {
      builder.withDetail(e.getMessage(), "").status(Status.DOWN);
    }
  }
}
