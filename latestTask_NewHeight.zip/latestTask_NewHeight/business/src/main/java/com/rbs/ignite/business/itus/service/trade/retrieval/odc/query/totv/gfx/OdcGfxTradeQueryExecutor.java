package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.gfx;

import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.AbstractOdcTradeQueryExecutor;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.domain.*;
import com.rbs.odc.core.domain.TransactionIdImpl;
import com.rbs.odc.core.domain.TransactionImpl;
import com.rbs.odc.core.util.Literals;
import com.rbs.odc.dynamicquery.lang.FilterLanguage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDate;
import java.util.*;

import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.collection;
import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.transaction;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.and;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.valueOf;

/**
 * Created by upadkti on 08/12/2017.
 */
public class OdcGfxTradeQueryExecutor extends AbstractOdcTradeQueryExecutor {
  private static final Logger logger = LoggerFactory.getLogger(OdcGfxTradeQueryExecutor.class);
  private static final ItusTradeSourceSystem SOURCE_SYSTEM = ItusTradeSourceSystem.GFX;
  private @Value("${totv.odc.gfx.system.instance.ids}") String systemInstanceIds;
  private @Value("${totv.odc.gfx.exclude.trade.status}") String tradeStatusStr;
  private static final String TRANSACTION_REPORTING = "Transaction Reporting";
  private static final String POST_TRADE_TRANSPARENCY = "Post Trade Transparency";

  @Override
  public Set<Transaction> executeQuery(Set<String> isinSet, LocalDate businessDate,String requestId) {
    Set<Transaction> transactions = new LinkedHashSet<>();
    Set<SystemInstanceId> systemInstanceIdSet = getSystemInstanceIdsFromString(systemInstanceIds, SOURCE_SYSTEM,requestId);
    Set<TransactionState> tradeStatuses = getTransactionStatesFromString(tradeStatusStr, SOURCE_SYSTEM,requestId);

    // Non-Fx Swaps excluding Spots:
    FilterLanguage whereClause = and
      (
        valueOf(transaction().getId().getSourceSystemId()).in(systemInstanceIdSet),
        valueOf(transaction().getUnderlyingProductClass()).notEqualTo(ProductClass.Foreign_Exchange_Swap),
        valueOf(transaction().getTransactionState()).notIn(tradeStatuses),
        valueOf(transaction().getProductId().getAtomicProductIdentifier()).notEqualTo("SPT"),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Post_Trade_Transparency),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Transaction_Reporting),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Transaction Reporting"),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Post Trade Transparency"),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getReportableInstruments()).getInstrumentScheme()).equalTo
          (SecurityInstrumentIdentifierClassificationScheme.ISIN),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getReportableInstruments()).getInstrumentId()).in(isinSet));

    logger.debug(requestId+":"+" ODC Query Criteria for GFX Non-Swaps excluding Spots: " + whereClause.toString() );
    transactions.addAll(executeQuery(whereClause,businessDate,requestId));

    // For Swap Deals firstly fetch all trades for these ISINs.
    List<Transaction> totalSwapTransactions = new ArrayList<>();
    whereClause = and
      (
        valueOf(transaction().getId().getSourceSystemId()).in(systemInstanceIdSet),
        valueOf(transaction().getUnderlyingProductClass()).equalTo(ProductClass.Foreign_Exchange_Swap),
        valueOf(transaction().getTransactionState()).notIn(tradeStatuses),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getReportableInstruments()).getInstrumentScheme()).equalTo
          (SecurityInstrumentIdentifierClassificationScheme.ISIN),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getReportableInstruments()).getInstrumentId()).in(isinSet));
    logger.debug(requestId+":"+" ODC Query Criteria for GFX Swap: " + whereClause.toString() );
    totalSwapTransactions.addAll(executeQuery(whereClause, businessDate,requestId));

    // And remove all those which are not related
    Collection<Transaction> filteredTransactions = new ArrayList<>();
    Collection<String> regimeImpactTypes = Literals.setWith(TRANSACTION_REPORTING, POST_TRADE_TRANSPARENCY);
    Collection<RegimeImpactType> reportableRegimeImpactTypes = Literals.setWith(RegimeImpactType.Post_Trade_Transparency, RegimeImpactType.Transaction_Reporting);
    for (Transaction transaction : totalSwapTransactions) {
      Map<String, Transaction> legIdentifiers = new HashMap<>();
      Collection<RegulatoryRegimeImpact> regulatoryRegimeImpacts = transaction.getRegulatoryRegimeImpact();
      regulatoryRegimeImpacts.stream().forEach(regulatoryRegimeImpact -> {
        String legIdentifier = regulatoryRegimeImpact.getLegIdentifier();
        if (legIdentifier != null) {
          Collection<ReportableInstrument> reportableInstruments = regulatoryRegimeImpact.getReportableInstruments();
          reportableInstruments.stream().forEach(reportableInst -> {
            if (isinSet.contains(reportableInst.getInstrumentId())) {
              legIdentifiers.put(legIdentifier, transaction);
            }
          });
        }
        Collection<TransactionRegimeImpactTypes> transactionRegimeImpactTypes = regulatoryRegimeImpact.getTransactionRegimeImpactTypes();
        transactionRegimeImpactTypes.stream().forEach(transactionRegimeImpactType -> {
          if (regimeImpactTypes.contains(transactionRegimeImpactType.getRegimeImpactType())) {
            legIdentifiers.remove(legIdentifier);
          }
        });
      });
      Collection<ReportableTransactionState> reportableTransactionStates = transaction.getReportableTransactionStates();
      reportableTransactionStates.stream().forEach(reportableTransactionState -> {
        String legIdentifier = reportableTransactionState.getReportableTransactionReference();
        if (reportableRegimeImpactTypes.contains(reportableTransactionState.getRegimeImpactType()) && legIdentifier != null) {
          legIdentifiers.remove(legIdentifier);
        }
      });

      for (Map.Entry<String, Transaction> legTransaction : legIdentifiers.entrySet()) {
        TransactionImpl transactionImpl = (TransactionImpl) legTransaction.getValue();
        TransactionImpl transactionObj = new TransactionImpl();
        TransactionIdImpl id = (TransactionIdImpl) transactionImpl.getId();
        transactionObj.setId(new TransactionIdImpl(id.getSourceSystemId(), legTransaction.getKey()));
        transactionObj.setLocation(transactionImpl.getLocation());
        transactionObj.setTransactionLegs(transactionImpl.getTransactionLegs());
        transactionObj.setVersion(transactionImpl.getVersion());
        filteredTransactions.add(transactionObj);
      }
    }

    transactions.addAll(filteredTransactions);
    //Non-Fx Swaps but NDF Spots:
    whereClause = and
      (
        valueOf(transaction().getId().getSourceSystemId()).in(systemInstanceIdSet),
        valueOf(transaction().getUnderlyingProductClass()).notEqualTo(ProductClass.Foreign_Exchange_Swap),
        valueOf(transaction().getTransactionState()).notIn(tradeStatuses),
        valueOf(transaction().getProductId().getAtomicProductIdentifier()).equalTo("SPT"),
        valueOf(collection(transaction().getTransactionLegs()).getFxLeg().getFxLegSubType()).equalTo(FXLegSubType.nonDeliverableForward),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Post_Trade_Transparency),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Transaction_Reporting),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Transaction Reporting"),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Post Trade Transparency"),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getReportableInstruments()).getInstrumentScheme()).equalTo
          (SecurityInstrumentIdentifierClassificationScheme.ISIN),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getReportableInstruments()).getInstrumentId()).in(isinSet));
    logger.debug(requestId+":"+" ODC Query Criteria for GFX Non-Swaps but NDF Spots: " + whereClause.toString() );
    transactions.addAll(executeQuery(whereClause,businessDate,requestId));
    return transactions;
  }
}
