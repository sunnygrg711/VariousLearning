package org.sk.tutorial.jfamily.concurrency.examples.session3_1.app;

import org.sk.tutorial.jfamily.concurrency.examples.session3_1.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class CyclicBarrierExample {
    public static void main(String[] args) throws InterruptedException, BrokenBarrierException {
        System.out.println("Reserving tennis court \n As soon as four players arrive,game will start");
        ThreadFactory threadFactory=(r)->new Thread(r);
        CyclicBarrier cyclicBarrier=new CyclicBarrier(4,threadFactory.newThread(()->System.out.println("All four players ready, game starts \n Love all...")));
        List<Player> players= Arrays.asList(new Player("Maria",cyclicBarrier),
                new Player("Sania",cyclicBarrier),
                new Player("Roger",cyclicBarrier),
                new Player("Rohan",cyclicBarrier));
        players.forEach(player -> threadFactory.newThread(player).start());

        TimeUnit.MILLISECONDS.sleep(1000);
        System.out.println("Second round...");
        cyclicBarrier.reset();
        players.forEach(player -> threadFactory.newThread(player).start());

        TimeUnit.MILLISECONDS.sleep(1000);
        System.out.println("Third round...");
        cyclicBarrier.reset();
        players=new ArrayList<>(players);
        players.remove(3);
        players.add(new Player("Mahesh",cyclicBarrier));
        players.forEach(player -> threadFactory.newThread(player).start());
        cyclicBarrier.reset();

    }
}
