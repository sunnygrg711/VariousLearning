package com.rbs.ignite.business.itus.service.trade.task.totv;


import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTask;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;

/**
 * Created by puronaa on 03/10/2017.
 */
public class TotvTradeTask implements ItusTradeTask<TotvTrade,TotvTradeStatus> {

    private TotvTrade trade;
    private ItusSingleTradeProcessor singleTradeProcessor;
    private Long taskSequence;

    public TotvTradeTask(TotvTrade trade, ItusSingleTradeProcessor singleTradeProcessor, Long taskSequence) {
        this.trade = trade;
        this.singleTradeProcessor = singleTradeProcessor;
        this.taskSequence = taskSequence;
    }

    @Override
    public TotvTrade getTrade() {
        return trade;
    }

    @Override
    public TotvTradeStatus execute() throws ItusException {
        return (TotvTradeStatus) singleTradeProcessor.processTrade(getTrade());
    }

    public ItusSingleTradeProcessor getSingleTradeProcessor() {
        return singleTradeProcessor;
    }

    public Long getTaskSequence() {
        return taskSequence;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TotvTradeTask)) return false;

        TotvTradeTask that = (TotvTradeTask) o;

        return trade.equals(that.trade);
    }

    @Override
    public int hashCode() {
        return trade.hashCode();
    }

    @Override
    public String toString() {
        return "TotvTradeTask{" +
                "trade=" + trade +
                ", singleTradeProcessor=" + singleTradeProcessor +
                ", taskSequence=" + taskSequence +
                '}';
    }
}
