package com.rbs.ignite.domain.itus.irs;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

public class TotvIrsRequest {

  private LocalDate feedDate;
  private FeedType feedType;

  public FeedType getFeedType() { return feedType; }
  public void setFeedType(FeedType feedType) { this.feedType = feedType; }
  public LocalDate getFeedDate() {
    return feedDate;
  }
  public void setFeedDate(LocalDate feedDate) {
    this.feedDate = feedDate;
  }

  @Override
  public String toString() {
    return "TotvIrsRequest{" +
            "feedDate=" + feedDate +
            ", feedType=" + feedType +
            '}';
  }
}
