package org.sk.tutorial.jfamily.concurrency.examples.session1_3;

import java.util.ArrayList;
import java.util.List;

public class DataRegistry {
    private List<IData> iDatas=new ArrayList<>();
    public void register(IData iData){
        iDatas.add(iData);
    }

    public void unregister(IData iData){
        iDatas.remove(iData);
    }

    public List<IData> getiDatas() {
        return iDatas;
    }
}