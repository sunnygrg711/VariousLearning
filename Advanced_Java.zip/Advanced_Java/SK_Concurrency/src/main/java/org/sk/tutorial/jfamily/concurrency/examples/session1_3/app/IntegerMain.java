package org.sk.tutorial.jfamily.concurrency.examples.session1_3.app;

import org.sk.tutorial.jfamily.concurrency.examples.session1_3.IntegerPojo;

/**
 * Created by kshekar on 23/04/2018.
 */
public class IntegerMain {

    public static void main(String[] args) {
        int counter=2000;
        while(counter-->0){
            final IntegerPojo integerPojo=new IntegerPojo();
            Thread threadSetter=new Thread(()->{
                integerPojo.setValue(10);
            },"Setter"+counter);
            Thread threadGetter=new Thread(()->{
                System.out.println(Thread.currentThread()+":"+integerPojo.getValue());
            },"Getter"+counter);
            threadSetter.start();
            threadGetter.start();
        }

    }
}
