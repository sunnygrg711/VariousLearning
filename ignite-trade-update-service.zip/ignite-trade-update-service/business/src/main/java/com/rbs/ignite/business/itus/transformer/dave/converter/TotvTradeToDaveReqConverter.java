package com.rbs.ignite.business.itus.transformer.dave.converter;


import com.rbs.ignite.domain.itus.trade.totv.dave.Identifier;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

/**
 * Conversion class which convert trades
 */
public class TotvTradeToDaveReqConverter implements Converter<TotvTrade, TotvDaveRequest> {
  private static Logger logger = LoggerFactory.getLogger(TotvTradeToDaveReqConverter.class);

  @Override
  public TotvDaveRequest convert(TotvTrade totvTrade) {
    TotvDaveRequest totvDaveRequest = new TotvDaveRequest();

    // Set identifier
    Identifier identifier = new Identifier();
    identifier.setContractId(Long.valueOf(totvTrade.getTradeIdentifier()));
    identifier.setSiteId(totvTrade.getLocation());
    totvDaveRequest.setTarget(identifier);
    totvDaveRequest.setIsin(totvTrade.getIsin());
    logger.debug("Converted dave Request is : {}", totvDaveRequest);
    return totvDaveRequest;
  }
}
