package org.sk.tutorial.jfamily.concurrency.examples.session2_4;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.StampedLock;

import static java.lang.Thread.sleep;
import static java.util.concurrent.Executors.*;

/**
 * Created by kshekar on 08/05/2018.
 */
public class StampedLockMain {

    public static void main(String[] args) {
        ExecutorService executor = newFixedThreadPool(2);
        Map<String, String> map = new HashMap<>();
        StampedLock lock = new StampedLock();

        executor.submit(() -> {
            long stamp = lock.writeLock();
            try {
                sleep1();
                map.put("A", "AClass");
            } finally {
                lock.unlockWrite(stamp);
            }
        });

        Runnable readTask = () -> {
            long stamp = lock.readLock();
            try {
                System.out.println(map.get("A") + "::" + map.get("B"));
                sleep1();
            } finally {
                lock.unlockRead(stamp);
            }
        };

        executor.submit(readTask);
        executor.submit(readTask);
        executor.submit(readTask);

        executor.submit(() -> {
            long stamp = lock.tryOptimisticRead();
            try {
                System.out.println("Optimistic Lock Valid: " + lock.validate(stamp));
                sleep1();
                System.out.println("Optimistic Lock Valid: " + lock.validate(stamp));
                sleep1();
                System.out.println("Optimistic Lock Valid: " + lock.validate(stamp));
            } finally {
                lock.unlock(stamp);
            }
        });

        executor.submit(() -> {
            long stamp = lock.writeLock();
            try {
                System.out.println("Write Lock acquired");
                sleep1();
            } finally {
                lock.unlock(stamp);
                System.out.println("Write done");
            }
        });
        executor.shutdown();
    }

    private static void sleep1() {
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
