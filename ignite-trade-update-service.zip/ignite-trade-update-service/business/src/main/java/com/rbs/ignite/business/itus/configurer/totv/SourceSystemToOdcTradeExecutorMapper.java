package com.rbs.ignite.business.itus.configurer.totv;



import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusTradeQueryExecutor;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import java.util.concurrent.ConcurrentMap;

/**
 * Created by upadkti on 08/12/2017.
 */
public class SourceSystemToOdcTradeExecutorMapper {
  ConcurrentMap<ItusTradeSourceSystem,ItusTradeQueryExecutor> map;

  public SourceSystemToOdcTradeExecutorMapper(ConcurrentMap<ItusTradeSourceSystem, ItusTradeQueryExecutor> map) {
    this.map = map;
  }

  public ItusTradeQueryExecutor getExecutor(ItusTradeSourceSystem itusTradeSourceSystem){
    return map.get(itusTradeSourceSystem);
  }
}
