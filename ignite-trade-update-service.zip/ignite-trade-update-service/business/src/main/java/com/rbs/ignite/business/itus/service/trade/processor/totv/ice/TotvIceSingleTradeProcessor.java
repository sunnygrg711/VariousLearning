package com.rbs.ignite.business.itus.service.trade.processor.totv.ice;

import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.api.itus.service.trade.processor.ItusWebServiceInterface;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.util.WebServiceUtil;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveRequest;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceRequest;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static com.rbs.ignite.business.itus.util.CommonConstantsUtil.CORRELATION.DAVE;
import static com.rbs.ignite.business.itus.util.CommonConstantsUtil.CORRELATION.ICE;
import static com.rbs.ignite.business.itus.util.CommonConstantsUtil.CORRELATION.SYSX;

/**
 * Created by upadkti on 02/12/2017.
 */
public class TotvIceSingleTradeProcessor implements ItusWebServiceInterface<TotvIceRequest,TotvIceResponse>, ItusSingleTradeProcessor<TotvTrade> {

  private static final Logger logger = LoggerFactory.getLogger(TotvIceSingleTradeProcessor.class);

  private static final String TRANSACTION_IDENTIFIER = "transactionIdentifier";
  private String tradeServiceUrl;
  private Class<TotvIceResponse> responseClass;
  private TokenProviderService ssoTokenProviderService;

  @Autowired
  private ItusTransformer totvTradeToIceRequestTransformer;
  @Autowired
  private RestTemplate restTemplate;
  public TotvIceSingleTradeProcessor(String tradeServiceUrl, Class<TotvIceResponse> responseClass, TokenProviderService ssoTokenProviderService) {
    this.tradeServiceUrl = tradeServiceUrl;
    this.responseClass = responseClass;
    this.ssoTokenProviderService = ssoTokenProviderService;
  }

  @Override
  public String getTradeServiceUrl() {
    return tradeServiceUrl;
  }

  @Override
  public Class<TotvIceResponse> getResponseClass() {
    return responseClass;
  }

  @Override
  public TotvIceResponse getResponse(TotvIceRequest totvIceRequest) {
    if (StringUtils.isEmpty(totvIceRequest.getTransactionIdentifier())){
      throw new ItusFatalErrorException("Invalid tradeId received from Odc");
    }
    HttpHeaders headers  =WebServiceUtil.getHttpHeaders("Authorisation", ssoTokenProviderService, ICE);
    HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
    logger.info("Calling ICE Service {} : {} , Target {} ", ICE.getKey(), entity.getHeaders().get(ICE.getKey()), totvIceRequest != null ? totvIceRequest.toString() : " ");
    logger.info("Calling ICE Web Service with transactionId {} ", totvIceRequest.getTransactionIdentifier());
    String actualUrl = tradeServiceUrl + totvIceRequest.getTransactionIdentifier() + "/" + "XS1234556A";
    ResponseEntity<TotvIceResponse> responseEntity = restTemplate.exchange(actualUrl ,HttpMethod.GET, entity, responseClass);
    logger.info("{} : {}, ICE response {}",ICE.getKey(), entity.getHeaders().get(ICE.getKey()), responseEntity);
    return responseEntity.getBody();
  }

  @Override
  public TotvTradeStatus processTrade(TotvTrade totvTrade) throws ItusException {
    logger.info("Processing ICE Trade {} ", totvTrade);
    TotvTradeStatus status = null;
    TotvIceRequest totvIceRequest = (TotvIceRequest) totvTradeToIceRequestTransformer.transform(totvTrade);
    try {
      TotvIceResponse response = getResponse(totvIceRequest);
      status = getItusTradeStatus(totvTrade, response);
      logger.info("Trade status: {}", status);
    } catch (Exception e) {
      logger.error(e.getMessage(), e);
      status = new TotvTradeStatus.TotvTradeStatusBuilder(totvTrade, ItusStatus.REJECTED, HttpStatus.SERVICE_UNAVAILABLE.toString())
              .exceptions(e.getMessage()).build();
    }
    return status;
  }

  private TotvTradeStatus getItusTradeStatus(TotvTrade trade, TotvIceResponse totvICEResponse) throws ItusException {
    if (totvICEResponse == null) {
      throw new ItusException("Invalid Response from trade system");
    }
    String code = totvICEResponse.getResponseCode();
    String errorMessage = totvICEResponse.getExceptionMessage();
    String responseMessage = totvICEResponse.getResponseMessage();
    if (code != null && !StringUtils.isEmpty(code))
      code = code.trim();
    ItusStatus itusStatus;
    switch (code) {
      case "0":
        itusStatus = ItusStatus.ACCEPTED;
        break;
      default:
        itusStatus = ItusStatus.REJECTED;
    }
    TotvTradeStatus.TotvTradeStatusBuilder totvTradeStatus = new TotvTradeStatus.TotvTradeStatusBuilder(trade, itusStatus, code);
    if (errorMessage != null && !StringUtils.isEmpty(errorMessage))
      totvTradeStatus.exceptions(errorMessage);
    if (responseMessage != null && !StringUtils.isEmpty(responseMessage))
      totvTradeStatus.message(responseMessage);
    return totvTradeStatus.build();
  }
}
