package org.sk.tutorial.jfamily.concurrency.animation;

/**
 * Created by kshekar on 23/03/2018.
 */
public class SelectionSort extends SorterRunnable {
    public SelectionSort(Double[] sortableValues, ArrayPanel arrayPanelToDisplayValues){
        super(sortableValues,arrayPanelToDisplayValues);
    }
    @Override
    void sort() {

        int firstIteratorIndex,secondIteratorIndex;
        double tempSwappingValue;
        int  minIndexToSwap;
        for(firstIteratorIndex=0;firstIteratorIndex<sortableValues.length -1;firstIteratorIndex++){
            minIndexToSwap=firstIteratorIndex;
            arrayPanelToDisplayValues.setValues(sortableValues, sortableValues[firstIteratorIndex], sortableValues[firstIteratorIndex+1]);
            for (secondIteratorIndex=firstIteratorIndex+1;secondIteratorIndex<sortableValues.length ;secondIteratorIndex++){
                if(sortableValues[secondIteratorIndex]<sortableValues[minIndexToSwap]){
                    minIndexToSwap=secondIteratorIndex;
                }
            }
            arrayPanelToDisplayValues.setValues(sortableValues, sortableValues[minIndexToSwap], sortableValues[firstIteratorIndex]);
            try
            {
                if (run)
                    Thread.sleep(DELAY_IN_MILLISECOND);
                else
                    semaphorePermits.acquire();
            }
            catch (InterruptedException exception)
            {
                Thread.currentThread().interrupt();
            }
            tempSwappingValue=sortableValues[minIndexToSwap];
            sortableValues[minIndexToSwap]=sortableValues[firstIteratorIndex];
            sortableValues[firstIteratorIndex]=tempSwappingValue;
        }
        arrayPanelToDisplayValues.setValues(sortableValues, null, null);

    }
}
