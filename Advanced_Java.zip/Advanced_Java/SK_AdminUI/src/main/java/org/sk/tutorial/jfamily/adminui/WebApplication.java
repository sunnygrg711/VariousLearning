package org.sk.tutorial.jfamily.adminui;

import org.sk.tutorial.jfamily.adminui.model.ThreadManager;
import org.sk.tutorial.jfamily.devopsutility.Devopsutility;
import org.sk.tutorial.jfamily.devopsutility.DevOpsManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import java.lang.management.ManagementFactory;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootApplication()
@ComponentScan(basePackages = "org.sk.tutorial.jfamily.adminui")
public class WebApplication  {
    static private Logger logger;


    public static void main(String[] args) throws Exception {
        System.setProperty("LOG.FILE","AdminUI_"+new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()));
        System.setProperty("PlatformName",  ManagementFactory.getRuntimeMXBean().getName());
        System.setProperty("log4j.configuration", Devopsutility.class.getClassLoader().getResource("log4j-service.xml").toString());
        logger = LoggerFactory.getLogger(Devopsutility.class);
        DevOpsManager.get().initialise();
        SpringApplication.run(WebApplication.class, args);
        ThreadManager.start(5,2);
        List<Object[]> objects=new ArrayList<>();
        while(true){
            objects.add(new Object[10000]);
            Thread.sleep(10);
            if(objects.size()>1000)
                break;

        }


    }
}