package com.rbs.ignite.api.itus.service.trade.processor;



import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;

import java.util.Set;

public interface ItusTradeProcessingService<Trade extends ItusTrade,Status extends ItusTradeStatus> {
    Set<Status> processTrades(Set<Trade> tradeSet) throws ItusException;
}
