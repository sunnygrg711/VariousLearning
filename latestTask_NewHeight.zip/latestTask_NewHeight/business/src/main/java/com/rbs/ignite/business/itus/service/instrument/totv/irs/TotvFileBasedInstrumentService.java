package com.rbs.ignite.business.itus.service.instrument.totv.irs;



import com.rbs.ignite.api.itus.service.instrument.ItusInstrumentService;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvFileBasedInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Created by puronaa on 14/09/2017.
 */
public class TotvFileBasedInstrumentService implements ItusInstrumentService<TotvFileBasedInstrumentInput, TotvInstrumentData> {
    private static final Logger logger = LoggerFactory.getLogger(TotvFileBasedInstrumentService.class);


    @Override
    public Set<TotvInstrumentData> getInstrumentData(TotvFileBasedInstrumentInput instrumentInput, String requestId, Boolean isDelta) throws ItusException {
        Set<TotvInstrumentData> totvDataSet = new LinkedHashSet<>();
        String fileName = instrumentInput.getFileName();
        logger.info(requestId+":"+"fileName:"+fileName);
        Path path = Paths.get(fileName);
        logger.info(requestId+":"+"path from fileName:"+path);
        if(!Files.exists(path)){
            try {
                path = Paths.get(ClassLoader.getSystemResource(fileName).toURI());
                logger.info(requestId+":"+"path from classloader:"+path);
            } catch (URISyntaxException e) {
                throw new ItusException("Problems while fetching Isin file", e);
            }
        }
        if(!Files.exists(path)){
            throw new ItusException("Problems while fetching Isin file");
        }
        //read file into stream, try-with-resources
        try (Stream<String> stream = Files.lines(path)) {
            stream.forEach((line) -> {
                        line = line.trim();
                        TotvInstrumentData totvData = new TotvInstrumentData(line);
                        totvDataSet.add(totvData);
                    }

            );

        } catch (IOException e) {
            throw new ItusException("Problems while fetching Isin file", e);
        }
        return totvDataSet;
    }

}
