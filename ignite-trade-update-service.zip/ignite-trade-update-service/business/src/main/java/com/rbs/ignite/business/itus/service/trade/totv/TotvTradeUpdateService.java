package com.rbs.ignite.business.itus.service.trade.totv;

import com.rbs.ignite.api.itus.service.instrument.ItusInstrumentService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessingService;
import com.rbs.ignite.api.itus.service.trade.retrieval.ItusTradeRetrievalService;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.util.Set;

public class TotvTradeUpdateService extends AbstractTradeUpdateService<TotvTradeStatus> {

  public static final Logger logger = LoggerFactory.getLogger(TotvTradeUpdateService.class);

  @Autowired
  private ItusInstrumentService instrumentService;

  @Autowired
  private ItusTradeRetrievalService tradeRetrievalService;

  @Autowired
  private ItusTradeProcessingService tradeProcessingService;

  @Override
  public Set<TotvInstrumentData> getInstrumentData(ItusInstrumentInput instrumentInput) {
    Set<TotvInstrumentData> dataSet = null;
    try {
      dataSet = instrumentService.getInstrumentData(instrumentInput);
    } catch (ItusException ex) {
      logger.error("Error occurred while retreiving ISINs form MDX ", ex);
    }
    return dataSet;
  }

  @Override
  public Set<TotvTrade> getTradeFromODC(Set<TotvInstrumentData> dataSet, LocalDate date) {
    Set<TotvTrade> tradeSet = null;
    try{
      tradeSet = tradeRetrievalService.retrieveTrades(dataSet,date);
    } catch (ItusException ex) {
      logger.error("Error occurred while retreiving trades from ODC for ISINs {}", dataSet, ex);
    }
    return tradeSet;
  }

  @Override
  public Set<TotvTradeStatus> processTrades(Set<TotvTrade> tradeSet) {
    Set<TotvTradeStatus> tradeStatusSet = null;
    try {
      tradeStatusSet = tradeProcessingService.processTrades(tradeSet);
    } catch (ItusException ex) {
      logger.error("Error occurred while processing trades {}", tradeSet);
    }
    return tradeStatusSet;
  }
}