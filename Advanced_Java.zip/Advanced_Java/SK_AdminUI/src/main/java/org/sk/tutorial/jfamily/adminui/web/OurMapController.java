package org.sk.tutorial.jfamily.adminui.web;

import org.sk.tutorial.jfamily.devopsutility.DevOpsManager;
import org.sk.tutorial.jfamily.devopsutility.model.OurMap;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by kshekar on 25/04/2018.
 */
@Controller
@RequestMapping("/map")
public class OurMapController {
    @RequestMapping( method = RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<String> getServices() {
        return new ResponseEntity(new OurMap().getMapString(), HttpStatus.OK);
    }
}
