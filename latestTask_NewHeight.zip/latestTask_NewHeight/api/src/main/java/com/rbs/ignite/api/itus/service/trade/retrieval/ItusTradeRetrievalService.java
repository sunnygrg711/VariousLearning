package com.rbs.ignite.api.itus.service.trade.retrieval;



import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentData;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;

import java.time.LocalDate;
import java.util.Set;

/**
 * Created by puronaa on 24/08/2017.
 */
public interface ItusTradeRetrievalService<Input, Output extends ItusTrade> {
  public Set<Output> retrieveTrades(Set<Input> isinSet, LocalDate date, Set<ItusTradeSourceSystem> sourceSystems, String requestId) throws ItusException;
}
