package org.sk.tutorial.jfamily.devopsutility.model;

/**
 * Created by kshekar on 25/04/2018.
 */
public class OurMap {

    public String getMapString()
    {
        int a =10, b = 0, c = 10;
        String s1="TFy!QJu ROo TNn(ROo)SLq SLq ULo+UHs UJq TNn*RPn/QP,\n"
                + "bEWS_JSWQAIJO^NBELPeHBFHT}TnALVlBLOFAkHFOuFETpHCStHAUFAgcEAelc,\n"
                + "lcn^r^r\\tZvYxXyT|S~Pn SPm SOn TNn ULo0ULo#ULo-WHq!WFs XDt!";
        a=s1.charAt(b);
       StringBuilder stringBuilder=new StringBuilder();
        while (a != 0)
        {
            if (b < 170)
            {
                a = s1.charAt(b);
                b++;
                while (a-- > 64)
                {
                    if (++c=='Z')
                    {
                        c/=9;
                        stringBuilder.append((char)(c));
                    }
                    else
                        System.out.print((char)(33 ^ (b & 0x01)));
                    stringBuilder.append((char)(33 ^ (b & 0x01)));
                }
            }
            else
                break;
        }
        return  stringBuilder.toString();
    }
}
