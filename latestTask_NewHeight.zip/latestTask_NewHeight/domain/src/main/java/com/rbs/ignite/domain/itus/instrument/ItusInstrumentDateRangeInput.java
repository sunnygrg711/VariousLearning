package com.rbs.ignite.domain.itus.instrument;

import java.time.LocalDate;

public interface ItusInstrumentDateRangeInput extends ItusInstrumentInput {
    LocalDate getFromDate();
    LocalDate getToDate();
}
