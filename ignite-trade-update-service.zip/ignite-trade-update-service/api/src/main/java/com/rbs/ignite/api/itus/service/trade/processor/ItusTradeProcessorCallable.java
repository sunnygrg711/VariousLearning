package com.rbs.ignite.api.itus.service.trade.processor;

import com.rbs.ignite.domain.itus.trade.ItusTradeHolder;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatusHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Callable;

/**
 * Created by upadkti on 28/11/2017.
 */
public class ItusTradeProcessorCallable implements Callable<ItusTradeStatusHolder> {
  private static final Logger logger = LoggerFactory.getLogger(ItusTradeProcessorCallable.class);
  private ItusTradeProcessor tradeProcessor;
  private ItusTradeHolder tradeHolder;

  public ItusTradeProcessorCallable(ItusTradeProcessor tradeProcessor, ItusTradeHolder tradeHolder) {
    this.tradeProcessor = tradeProcessor;
    this.tradeHolder = tradeHolder;
  }

  @Override
  public ItusTradeStatusHolder call() throws Exception {
    logger.info("Started processing trades for: "+tradeHolder.getTradeSourceSystem());
    ItusTradeStatusHolder tradeStatusHolder = tradeProcessor.processTrades(tradeHolder);
    return tradeStatusHolder;
  }
}
