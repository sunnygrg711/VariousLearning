package org.sk.tutorial.jfamily.concurrency.animation;

import java.util.concurrent.Semaphore;

/**
 *  This runnable executes a sort algorithm.
 *  When two elements are compared, the algorithm
 *  pauses and updates a panel.
 * Created by kshekar on 23/03/2018.
 */
public abstract class SorterRunnable implements Runnable{
    protected Semaphore semaphorePermits;
    protected Double[] sortableValues;
    protected ArrayPanel arrayPanelToDisplayValues;
    protected static final int DELAY_IN_MILLISECOND = 100;
    protected boolean run;

    public SorterRunnable(Double[] sortableValues, ArrayPanel arrayPanelToDisplayValues) {
        this.sortableValues = sortableValues;
        this.arrayPanelToDisplayValues = arrayPanelToDisplayValues;
        this.semaphorePermits = new Semaphore(1);
        this.run=false;
    }
    /**
     Sets the sorter to "run" mode.
     */
    public void setRun()
    {
        run = true;
        semaphorePermits.release();
    }

    /**
     Sets the sorter to "step" mode.
     */
    public void setStep()
    {
        run = false;
        semaphorePermits.release();
    }
    abstract void sort();

    public void run() {
        sort();
    }
}
