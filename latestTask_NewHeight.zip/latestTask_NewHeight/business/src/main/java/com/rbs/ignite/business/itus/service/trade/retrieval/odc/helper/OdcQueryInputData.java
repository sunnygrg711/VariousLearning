package com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper;

import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.domain.TransactionState;

import java.time.LocalDate;
import java.util.Set;

/**
 * Created by upadkti on 07/11/2017.
 */
public class OdcQueryInputData {

  private Set<String> iSin;
  private Set<ItusTradeSourceSystem> sourceSystems;
  private LocalDate businessDate;
  private TransactionState transactionState = TransactionState.Cancelled;
  private boolean eligible;

  public OdcQueryInputData() {
  }

  public OdcQueryInputData(Set<String> iSin, Set<ItusTradeSourceSystem> sourceSystems, LocalDate businessDate, TransactionState transactionState, boolean eligible) {
    this.iSin = iSin;
    this.sourceSystems = sourceSystems;
    this.businessDate = businessDate;
    this.transactionState = transactionState;
    this.eligible = eligible;
  }

  public Set<String> getiSin() {
    return iSin;
  }

  public void setiSin(Set<String> iSin) {
    this.iSin = iSin;
  }

  public Set<ItusTradeSourceSystem> getSourceSystems() {
    return sourceSystems;
  }

  public void setSourceSystems(Set<ItusTradeSourceSystem> sourceSystems) {
    this.sourceSystems = sourceSystems;
  }

  public LocalDate getBusinessDate() {
    return businessDate;
  }

  public void setBusinessDate(LocalDate businessDate) {
    this.businessDate = businessDate;
  }

  public TransactionState getTransactionState() {
    return transactionState;
  }

  public void setTransactionState(TransactionState transactionState) {
    this.transactionState = transactionState;
  }

  public boolean isEligible() {
    return eligible;
  }

  public void setEligible(boolean eligible) {
    this.eligible = eligible;
  }

  @Override
  public boolean equals(Object o) {
    if(this==o) return true;
    if(o==null||getClass()!=o.getClass()) return false;

    OdcQueryInputData that = (OdcQueryInputData) o;
    if(eligible!=that.eligible) return false;
    if(iSin!=null ? !iSin.equals(that.iSin) : that.iSin!=null) return false;
    if(sourceSystems!=null ? !sourceSystems.equals(that.sourceSystems) : that.sourceSystems!=null) return false;
    if(businessDate!=null ? !businessDate.equals(that.businessDate) : that.businessDate!=null) return false;
    return transactionState!=null ? transactionState.equals(that.transactionState) : that.transactionState==null;
  }

  @Override
  public int hashCode() {
    int result = iSin!=null ? iSin.hashCode() : 0;
    result = 31*result+(sourceSystems!=null ? sourceSystems.hashCode() : 0);
    result = 31*result+(businessDate!=null ? businessDate.hashCode() : 0);
    result = 31*result+(transactionState!=null ? transactionState.hashCode() : 0);
    result = 31*result+(eligible ? 1 : 0);
    return result;
  }

  @Override
  public String toString() {
    return "OdcQueryInputData{"+
      "iSin="+iSin+
      ", sourceSystems="+sourceSystems+
      ", businessDate="+businessDate+
      ", transactionState="+transactionState+
      ", eligible="+eligible+
      '}';
  }
}
