package org.sk.tutorial.jfamily.concurrency.examples.session1_2;

/**
 * Created by kshekar on 23/04/2018.
 */
public class SpecialEmployee extends Employee {
    public synchronized int  getDefaultBonus(){
        System.out.println(Thread.currentThread().getName()+" ->Inside getDefaultBonus::"+this);
        return super.getDefaultBonus()+10000+5000;
    }
}
