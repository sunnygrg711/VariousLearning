package com.rbs.ignite.business.itus.transformer.totv;

import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.collections.Sets;
import org.springframework.core.convert.ConversionService;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Set;

import static org.junit.Assert.assertTrue;

/**
 * Created by kumaunn on 09/02/2018.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class TotvInstrumentDataToISINTransformerTest {

  @InjectMocks
  private TotvInstrumentDataToISINTransformer testObj = new TotvInstrumentDataToISINTransformer();

  @Mock
  private ConversionService conversionService;

  @Mock
  private TotvInstrumentData instrumentData;

  @After
  public void tearDown() {
    testObj = null;
  }

  @Test
  public void testTransform() throws ItusTransformException {
    Set<TotvInstrumentData> input = Sets.newSet(instrumentData);
    Mockito.when(conversionService.convert(Mockito.anyObject() , Mockito.anyObject()
    , Mockito.anyObject())).thenReturn(null);
    Set<String> totvISINSet = testObj.transform(input);
    assertTrue(totvISINSet ==null);
  }
}
