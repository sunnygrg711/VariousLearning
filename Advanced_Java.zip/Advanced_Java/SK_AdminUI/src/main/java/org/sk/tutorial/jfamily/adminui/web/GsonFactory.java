package org.sk.tutorial.jfamily.adminui.web;

import com.google.gson.Gson;

/**
 * Created by kshekar on 06/04/2018.
 */
public class GsonFactory {

    static String toJson(Object t){
        return new Gson().toJson(t);
    }
}
