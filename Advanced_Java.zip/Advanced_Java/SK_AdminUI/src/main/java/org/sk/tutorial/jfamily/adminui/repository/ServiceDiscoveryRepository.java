package org.sk.tutorial.jfamily.adminui.repository;

import org.sk.tutorial.jfamily.adminui.model.Application;

import java.util.List;

/**
 * Created by kshekar on 02/04/2018.
 */
public interface ServiceDiscoveryRepository {
    /**
     * Get Application details by Name
     * @param applicationName
     * @return
     */
    Application getApplicationByName(String applicationName);

    /**
     * Register Application on Service Discovery
     * @param application
     * @return
     */
    boolean register(Application application);

    /**
     * Check status of registered application on ServiceDiscovery
     * @param applicationName
     * @return Application
     */
    Application status(String applicationName);

    /**
     * List All active application
     * @return List of Application
     */
    List<Application> getAllActiveApplications();

    /**
     * Get Application details by Name
     * @param applicationName
     * @return
     */
    Application unregister(String applicationName);

}
