package com.rbs.ignite.business.itus.transformer.gfx.converter;


import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxRequest;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

/**
 * Created by kumaunn on 10/11/2017.
 */
public class TotvTradeToGfxReqConverter implements Converter<TotvTrade, TotvGfxRequest> {
  private static final Logger logger = LoggerFactory.getLogger(TotvTradeToGfxReqConverter.class);

  @Override
  public TotvGfxRequest convert(TotvTrade totvTrade) {

    TotvGfxRequest totvGfxRequest = new TotvGfxRequest();
    if (totvTrade.getTradeIdentifier() != null)
      totvGfxRequest.setTransactionIdentifier(totvTrade.getTradeIdentifier());
    else {
      totvGfxRequest.setTransactionIdentifier("");
    }

    logger.debug("Converted gfx Request is : {}", totvGfxRequest);
    return totvGfxRequest;
  }
}
