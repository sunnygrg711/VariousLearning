package org.sk.tutorial.jfamily.concurrency.locks.synch;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Locking Tool for Bank
 * Created by kshekar on 22/03/2018.
 */
public class BankLockingImpl {
    private Lock bankLock;
    private Condition sufficientFunds;

    public BankLockingImpl() {
        bankLock = new ReentrantLock();
        sufficientFunds = bankLock.newCondition();
    }

    public Lock getBankLock() {
        return bankLock;
    }

    public Condition getSufficientFunds() {
        return sufficientFunds;
    }
}
