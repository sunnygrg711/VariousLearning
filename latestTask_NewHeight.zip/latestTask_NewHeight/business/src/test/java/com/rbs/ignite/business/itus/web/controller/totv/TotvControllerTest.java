package com.rbs.ignite.business.itus.web.controller.totv;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Sets;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.rbs.ignite.api.itus.service.trade.retrieval.ItusTradeRetrievalService;
import com.rbs.ignite.business.itus.jmx.TotvJmxProvider;
import com.rbs.ignite.business.itus.totv.TotvStarter;
import com.rbs.ignite.business.itus.util.configurer.totv.TotvTestConfigurer;
import com.rbs.ignite.business.itus.web.controller.totv.mock.*;
import com.rbs.ignite.business.itus.web.controller.totv.util.TotvControllerUtil;
import com.rbs.ignite.domain.itus.instrument.totv.*;

import com.rbs.ignite.domain.itus.irs.FeedType;
import com.rbs.ignite.domain.itus.irs.TotvIrsInstrumentIdentifier;
import com.rbs.ignite.domain.itus.irs.TotvIrsRequest;
import com.rbs.ignite.domain.itus.irs.TotvIrsResponse;
import com.rbs.ignite.domain.itus.request.RequestEntity;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.dave.*;
import com.rbs.ignite.domain.itus.trade.totv.dave.Exception;
import com.rbs.ignite.domain.itus.trade.totv.gfx.TotvGfxResponse;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceRequest;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceResponse;
import com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds.Event;
import com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds.IgniteRequestEntity;
import com.rbs.ignite.domain.itus.trade.totv.systemx.TotvSystemXResponse;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import javax.jms.Message;
import javax.jms.Session;
import java.time.LocalDate;
import java.util.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {TotvStarter.class, TotvTestConfigurer.class})
public class TotvControllerTest {

  @Autowired
  private ObjectMapper jacksonObjectMapper;
  @Autowired
  private IrsMockServer irsMockServer;
  @Autowired
  private DaveMockServer daveMockServer;
  @Autowired
  private IceMockServer iceMockServer;
  @Autowired
  private SystemXMockServer systemXMockServer;
  @Autowired
  private GfxMockServer gfxMockServer;
  @Autowired
  private ApplicationContext context;
  @Autowired
  private TotvJmxProvider jmxProvider;
  @Autowired
  private WebApplicationContext webApplicationContext;

  private @Value("${totv.ignitebonds.messaging.header.key}")
  String messagingHeaderKey;
  private @Value("${totv.ignitebonds.messaging.header.value}")
  String messagingHeaderValue;
  private @Value("${totv.ignite.event.type}")
  String igniteBondsEventType;
  private @Value("${totv.ignite.site.id}")
  String igniteBondsSiteId;
  private @Value("${totv.ignitebonds.messaging.event.topic}")
  String messagingEventTopic;

  @MockBean
  private JmsTemplate jmsTemplate;
  private static MockMvc mockMvc;
  @MockBean
  private ItusTradeRetrievalService tradeRetrievalService;
  private static Set<TotvIrsInstrumentIdentifier> isins;
  private static String  date = "21/12/2017";

  static {
    System.setProperty("env", "ci");
  }

  @BeforeClass
  public static void setup() throws NoSuchFieldException, IllegalAccessException {
    isins = new HashSet<>();
    isins.add(new TotvIrsInstrumentIdentifier("EZ5MCBS7WYK2", "", "", ""));
    isins.add(new TotvIrsInstrumentIdentifier("DE0001030542", "", "", ""));
    isins.add(new TotvIrsInstrumentIdentifier("EZ98PRND3G05", "", "", ""));
    isins.add(new TotvIrsInstrumentIdentifier("EZV7JD6QDWD0", "", "", ""));
    isins.add(new TotvIrsInstrumentIdentifier("XS1234556A", "", "", ""));
  }

  @Before
  public void before() {
    mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext).build();
    MockitoAnnotations.initMocks(this);
  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request
   *
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and return 5 isins
   *     - ODC will give the trades for the isins fetched from IRS
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testupdateTradesForDate() throws java.lang.Exception {
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedIceData();
    mockedSystemXData();
    mockedGfxData();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertThatResponseIsCorrect(response, jacksonObjectMapper);
  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request except DAVE source system
   *
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and return 5 isins
   *     - ODC will give the trades for the isins fetched from IRS
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */

  @Test
  public void testupdateTradesForDateWhenDaveIsDown() throws java.lang.Exception {
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    daveMockServer.ensureDaveServerIsDown();
    mockedIceData();
    mockedSystemXData();
    mockedGfxData();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenDaveIsDown(response, jacksonObjectMapper);

  }


  TotvIrsResponse mockedIrsData(TotvInstrumentDateInput input) throws JsonProcessingException {
    TotvIrsResponse totvIRSResponse = new TotvIrsResponse(isins, Lists.newArrayList());
    TotvIrsRequest totvIrsRequest = new TotvIrsRequest();
    totvIrsRequest.setFeedType(FeedType.DELTA);
    totvIrsRequest.setFeedDate(input.getDate());
    String response = jacksonObjectMapper.writeValueAsString(totvIRSResponse);
    irsMockServer.ensureIrsServerReturnsValidIsins(totvIrsRequest, response);
    return totvIRSResponse;
  }

  private MessageCreator mockedIgniteData(TotvTrade totvTrade) {
    return createMessage(totvTrade);
  }

  private MessageCreator createMessage(TotvTrade totvTrade) {
    String payload = getStringMessage(totvTrade);
    MessageCreator messageCreator = (Session arg0) -> {
      Message msg = arg0.createTextMessage(payload);
      msg.setStringProperty(messagingHeaderKey, messagingHeaderValue);
      return msg;
    };
    return messageCreator;
  }

  private String getStringMessage(TotvTrade totvTrade) {
    com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds.Identifier identifier = new com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds.Identifier(igniteBondsSiteId, totvTrade.getTradeIdentifier());
    Event event = new Event(igniteBondsEventType, totvTrade.getIsin());
    RequestEntity requestEntity = new IgniteRequestEntity(identifier, event);
    return new Gson().toJson(requestEntity);
  }

  protected void mockedIceData() throws JsonProcessingException {
    TotvIceRequest iceRequest1 = new TotvIceRequest();
    iceRequest1.setIsin("EZ98PRND3G05");
    iceRequest1.setTransactionIdentifier("192996010");
    TotvIceRequest iceRequest2 = new TotvIceRequest();
    iceRequest2.setIsin("EZ98PRND3G05");
    iceRequest2.setTransactionIdentifier("192994370");

    TotvIceResponse iceResponse1 = new TotvIceResponse();
    iceResponse1.setResponseCode("0");
    iceResponse1.setResponseMessage("Processed Successfully");
    iceResponse1.setExceptionMessage("");
    TotvIceResponse iceResponse2 = new TotvIceResponse();
    iceResponse2.setResponseCode("1");
    iceResponse2.setResponseMessage("Processing failed");
    iceResponse2.setExceptionMessage("Invalid transaction id");

    iceMockServer.ensureIceResponse(iceRequest1, jacksonObjectMapper.writeValueAsString(iceResponse1), iceRequest2, jacksonObjectMapper.writeValueAsString(iceResponse2));

  }

  private void mockedSystemXData() throws JsonProcessingException {

    String systemXRequest1 = "17355LN024844D";
    String systemXRequest2 = "17305LN024728D";
    TotvSystemXResponse response1 = new TotvSystemXResponse();
    response1.setSuccess("true");
    response1.setSourceSystem("SystemX");

    TotvSystemXResponse response2 = new TotvSystemXResponse();
    response2.setSuccess("false");
    response2.setErrorMessage("Invalid request");

    systemXMockServer.ensureSystemXResponse(systemXRequest1, jacksonObjectMapper.writeValueAsString(response1), systemXRequest2, jacksonObjectMapper.writeValueAsString(response2));

  }

  private void mockedGfxData() throws JsonProcessingException {

    String gfxRequest1 = "N171219A49E0B";
    String gfxRequest2 = "L171220A40488";
    TotvGfxResponse response1 = new TotvGfxResponse();
    response1.setSuccess("true");
    response1.setSourceSystem("Gfx");

    TotvGfxResponse response2 = new TotvGfxResponse();
    response2.setSuccess("false");
    response2.setErrorMessage("Invalid request");

    gfxMockServer.ensureGfxResponse(gfxRequest1, jacksonObjectMapper.writeValueAsString(response1), gfxRequest2, jacksonObjectMapper.writeValueAsString(response2));

  }


  private void mockedDaveData() throws JsonProcessingException {
    TotvDaveRequest daveRequest1 = new TotvDaveRequest();
    daveRequest1.setIsin("EZ5MCBS7WYK2");
    Identifier identifier1 = new Identifier();
    identifier1.setContractId(118428069);
    identifier1.setSiteId("GBLO");
    daveRequest1.setTarget(identifier1);
    TotvDaveRequest daveRequest2 = new TotvDaveRequest();
    daveRequest2.setIsin("EZ5MCBS7WYK2");
    Identifier identifier2 = new Identifier();
    identifier2.setContractId(118428070);
    identifier2.setSiteId("GBLO");
    daveRequest2.setTarget(identifier2);

    TotvDaveResponse daveResponse1 = new TotvDaveResponse();
    ResponseDto responseObj = new ResponseDto();
    responseObj.setCode(0);
    responseObj.setErrors(new String[]{});
    responseObj.setExceptions(new Exception[]{});
    responseObj.setInformation(new String[]{});
    responseObj.setValidationResults(new ValidationResults[]{});
    daveResponse1.setResponseDto(responseObj);
    TotvDaveResponse daveResponse2 = new TotvDaveResponse();
    ResponseDto responseObj2 = new ResponseDto();
    responseObj2.setCode(1);
    responseObj2.setErrors(new String[]{"trade id not valid"});
    responseObj2.setExceptions(new Exception[]{});
    responseObj2.setInformation(new String[]{});
    responseObj2.setValidationResults(new ValidationResults[]{});
    daveResponse2.setResponseDto(responseObj2);
    daveMockServer.ensureDaveResponse(jacksonObjectMapper.writeValueAsString(daveRequest1), jacksonObjectMapper.writeValueAsString(daveResponse1), jacksonObjectMapper.writeValueAsString(daveRequest2), jacksonObjectMapper.writeValueAsString(daveResponse2));
  }
  private Set<TotvTrade> mockedTotvTradesFromOdc() {
    Set<TotvTrade> totvTrade = new HashSet<>();
    totvTrade.add(new TotvTrade("EZ5MCBS7WYK2", "118428069", ItusTradeSourceSystem.DAVE, "GBLO"));
    totvTrade.add(new TotvTrade("EZ5MCBS7WYK2", "118428070", ItusTradeSourceSystem.DAVE, "GBLO"));
    totvTrade.add(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"));
    totvTrade.add(new TotvTrade("EZ98PRND3G05", "192996010", ItusTradeSourceSystem.ICE, "GBLO"));
    totvTrade.add(new TotvTrade("EZ98PRND3G05", "192994370", ItusTradeSourceSystem.ICE, "GBLO"));
    totvTrade.add(new TotvTrade("EZV7JD6QDWD0", "17355LN024844D", ItusTradeSourceSystem.SYSTEMX, "GBLO"));
    totvTrade.add(new TotvTrade("EZV7JD6QDWD0", "17305LN024728D", ItusTradeSourceSystem.SYSTEMX, "GBLO"));
    totvTrade.add(new TotvTrade("XS1234556A", "N171219A49E0B", ItusTradeSourceSystem.GFX, "GBLO"));
    totvTrade.add(new TotvTrade("XS1234556A", "L171220A40488", ItusTradeSourceSystem.GFX, "GBLO"));

    return totvTrade;
  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request except ICE source system
   *
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and return 5 isins
   *     - ODC will give the trades for the isins fetched from IRS
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testupdateTradesForDateWhenIceIsDown() throws java.lang.Exception {
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedSystemXData();
    iceMockServer.ensureIceServerIsDown();
    mockedGfxData();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenIceIsDown(response, jacksonObjectMapper);
  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request except GFX source system
   *
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and return 5 isins
   *     - ODC will give the trades for the isins fetched from IRS
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testupdateTradesForDateWhenGFXIsDown() throws java.lang.Exception {
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedSystemXData();
    mockedIceData();
    gfxMockServer.ensureGfxServerIsDown();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenGfxIsDown(response, jacksonObjectMapper);
  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request except SystemX source system
   *
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and return 5 isins
   *     - ODC will give the trades for the isins fetched from IRS
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testupdateTradesForDateWhenSystemXIsDown() throws java.lang.Exception {
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedGfxData();
    mockedIceData();
    systemXMockServer.ensureSystemXServerIsDown();
    mockedGfxData();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenSystemXIsDown(response, jacksonObjectMapper);
  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - Request is running on Readonly Mode
   *
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and return 5 isins
   *     - ODC will give the trades for the isins fetched from IRS
   *     - Trades will be segregated based on source system but will not process
   *     - Once all the trades are added to tradeSkipAmend list then the response will be asserted
   * </pre>
   */
  @Test
  public void testupdateTradesForDateWhenReadOnlyEnabled() throws java.lang.Exception {

    jmxProvider.enableReadOnlyMode(true);

    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenReadOnlyEnabled(response, jacksonObjectMapper);

    jmxProvider.enableReadOnlyMode(false);

  }

  /**
   * <pre>
   *     Given:
   *     - IRS system is down
   *     - ODC will give trades for every source system*
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and since it is down, it will give exception
   *     - Response is then again sent back to controller with 0 count
   *     - Response will be asserted
   * </pre>
   */
  @Test
  public void testupdateTradesForDateWhenIrsIsDown() throws java.lang.Exception {
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    irsMockServer.ensureIrsServerIsDown();
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().is5xxServerError())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
  }


  /**
   * <pre>
   *     Given:
   *     - IRS system is returning 0 isins
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and return 0 isins
   *     - ODC will throw exception as no isin to process
   *     - Response will be asserted for 500 status code
   * </pre>
   */
  @Test
  public void testupdateTradesForDateWhenIrsReturnNoIsins() throws java.lang.Exception {
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 22));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = new TotvIrsResponse(Sets.newHashSet(), Lists.newArrayList());
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().is5xxServerError())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
  }

  /**
   * <pre>
   *     Given:
   *     - IRS is up but ODC system internally throws exception
   *
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and return 5 isins
   *     - ODC will throw exception and exception will be logged
   *     - Trade count from odc will be zero. And then response is asserted
   * </pre>
   */
  @Test
  public void testupdateTradesForDateWhenODCIsDown() throws java.lang.Exception {
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 22));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(Sets.newHashSet());
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();

    TotvControllerTestHelper.assertResponseWhenODCIsDown(response, jacksonObjectMapper);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request
   *
   *     When:
   *     - We receive updateTradesForDateNIsins request
   *
   *     Then:
   *     - ODC will give the trades for the isins send through request for the date mentioned in request
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradesOnIsinsWithDate() throws java.lang.Exception {
    Set<String> isinSet = new HashSet<>();
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    TotvInputForDateWithIsins input = new TotvInputForDateWithIsins(isinSet, (LocalDate.of(2017, 12, 21)));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedIceData();
    mockedSystemXData();
    mockedGfxData();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNIsins").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertThatResponseIsCorrect(response, jacksonObjectMapper);
  }

  @Test
  public void testgetTradesForDateNIsins() throws java.lang.Exception {
    Set<String> isinSet = new HashSet<>();
    LocalDate localDate = TotvControllerUtil.convertDatetoLocalDate(date,"dd/MM/yyyy");
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    String request = TotvControllerTestHelper.createRequestFromInput(isinSet, jacksonObjectMapper);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(localDate), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
      String response = this.mockMvc.perform(post("/totv/getTradesForDateNIsins?date="+date +"").contentType(MediaType.APPLICATION_JSON).content(request))
              .andExpect(status().isOk())
              .andExpect(content().contentType("application/json;charset=UTF-8"))
              .andReturn()
              .getResponse()
              .getContentAsString();
    TotvControllerTestHelper.assertThatTotvGetTradesResponseIsCorrect(response, jacksonObjectMapper);
  }

  @Test
  public void testgetIsinsForDate() throws java.lang.Exception {
    LocalDate localDate = TotvControllerUtil.convertDatetoLocalDate(date,"dd/MM/yyyy");
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(localDate);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    String response = this.mockMvc.perform(get("/totv/getIsinsForDate?date="+date +"").param("isDelta","true").contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertThatGetIsinsResponseIsCorrect(response, jacksonObjectMapper);
  }

  @Test
  public void testgetTradesForDate() throws java.lang.Exception {
    Set<String> isinSet = new HashSet<>();
    LocalDate localDate = TotvControllerUtil.convertDatetoLocalDate(date,"dd/MM/yyyy");
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(localDate);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(localDate), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    String response = this.mockMvc.perform(get("/totv/getTradesForDate?date="+date +"").param("isDelta","true").contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertThatTotvGetTradesResponseIsCorrect(response, jacksonObjectMapper);
  }
  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request except DAVE source system
   *
   *     When:
   *     - We receive updateTradesForDateNIsins request
   *
   *     Then:
   *     - ODC will give the trades for the isins send through request for the date mentioned in request
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradesOnIsinsWithDateWhenDaveIsDown() throws java.lang.Exception {
    Set<String> isinSet = new HashSet<>();
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    TotvInputForDateWithIsins input = new TotvInputForDateWithIsins(isinSet, (LocalDate.of(2017, 12, 21)));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    daveMockServer.ensureDaveServerIsDown();
    mockedIceData();
    mockedSystemXData();
    mockedGfxData();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNIsins").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenDaveIsDown(response, jacksonObjectMapper);

  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system for the specified isins
   *     - All mock servers are Up and serves the request except ICE source system
   *
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - ODC will give the trades for the isins send through request for the date mentioned in request
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradesOnIsinsWithDateWhenIceIsDown() throws java.lang.Exception {
    Set<String> isinSet = new HashSet<>();
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    TotvInputForDateWithIsins input = new TotvInputForDateWithIsins(isinSet, (LocalDate.of(2017, 12, 21)));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedSystemXData();
    iceMockServer.ensureIceServerIsDown();
    mockedGfxData();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNIsins").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenIceIsDown(response, jacksonObjectMapper);
  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request except GFX source system
   *
   *     When:
   *     - We receive updateTradesmOnIsin request
   *
   *     Then:
   *     - ODC will give the trades for the isins send through request for the date mentioned in request
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradesOnIsinsWithDateWhenGFXIsDown() throws java.lang.Exception {
    Set<String> isinSet = new HashSet<>();
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    TotvInputForDateWithIsins input = new TotvInputForDateWithIsins(isinSet, (LocalDate.of(2017, 12, 21)));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedSystemXData();
    mockedIceData();
    gfxMockServer.ensureGfxServerIsDown();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNIsins").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenGfxIsDown(response, jacksonObjectMapper);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request except SystemX source system
   *
   *     When:
   *     - We receive updateTradesmOnIsin request
   *
   *     Then:
   *     - ODC will give the trades for the isins send through request for the date mentioned in request
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradesOnIsinsWithDateWhenSystemXIsDown() throws java.lang.Exception {
    Set<String> isinSet = new HashSet<>();
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    TotvInputForDateWithIsins input = new TotvInputForDateWithIsins(isinSet, (LocalDate.of(2017, 12, 21)));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedGfxData();
    mockedIceData();
    systemXMockServer.ensureSystemXServerIsDown();
    mockedGfxData();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNIsins").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenSystemXIsDown(response, jacksonObjectMapper);
  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - Request is running on Readonly Mode
   *
   *
   *     When:
   *     - We receive updateTradesmOnIsin request
   *
   *     Then:
   *     - ODC will give the trades for the isins send through request for the date mentioned in request
   *     - Trades will be segregated based on source system but will not process
   *     - Once all the trades are added to tradeSkipAmend list then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradesOnIsinsWithDateWhenReadOnlyEnabled() throws java.lang.Exception {

    jmxProvider.enableReadOnlyMode(true);
    Set<String> isinSet = new HashSet<>();
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    TotvInputForDateWithIsins input = new TotvInputForDateWithIsins(isinSet, (LocalDate.of(2017, 12, 21)));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNIsins").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenReadOnlyEnabled(response, jacksonObjectMapper);

    jmxProvider.enableReadOnlyMode(false);

  }

  /**
   * <pre>
   *     Given:
   *     - ODC system internally throws exception
   *
   *     When:
   *     - We receive updateTradesForDateNIsins request
   *
   *     Then:
   *     - ODC will throw exception and exception will be logged
   *     - Trade count from odc will be zero. And then response is asserted
   * </pre>
   */
  @Test
  public void testUpdateTradesOnIsinsWithDateWhenODCIsDown() throws java.lang.Exception {
    Set<String> isinSet = new HashSet<>();
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    TotvInputForDateWithIsins input = new TotvInputForDateWithIsins(isinSet, (LocalDate.of(2017, 12, 21)));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(Sets.newHashSet());
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNIsins").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();

    TotvControllerTestHelper.assertResponseWhenODCIsDown(response, jacksonObjectMapper);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - All mock servers are Up and serves the request
   *
   *     When:
   *     - We receive updateTradesSet request
   *
   *     Then:
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradeSet() throws java.lang.Exception {
    String request = TotvControllerTestHelper.createRequestFromInput(totvTradeSetInputRequest(), jacksonObjectMapper);
    mockedDaveDataForTradeSetRequest();
    mockedIceDataForTradeSetRequest();
    mockedSystemXData();
    mockedGfxData();
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade(null, "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesSet").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertThatResponseIsCorrect(response, jacksonObjectMapper);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - All mock servers are Up except dave and serves the request
   *
   *     When:
   *     - We receive updateTradesSet request
   *
   *     Then:
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradeSetWhenDaveIsDown() throws java.lang.Exception {
    String request = TotvControllerTestHelper.createRequestFromInput(totvTradeSetInputRequest(), jacksonObjectMapper);
    mockedIceDataForTradeSetRequest();
    mockedSystemXData();
    mockedGfxData();
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade(null, "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    daveMockServer.ensureDaveServerIsDown();
    String response = this.mockMvc.perform(post("/totv/updateTradesSet").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenDaveIsDown(response, jacksonObjectMapper);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - All mock servers are Up except ICE and serves the request
   *
   *     When:
   *     - We receive updateTradesSet request
   *
   *     Then:
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradeSetWhenIceIsDown() throws java.lang.Exception {
    String request = TotvControllerTestHelper.createRequestFromInput(totvTradeSetInputRequest(), jacksonObjectMapper);
    mockedDaveDataForTradeSetRequest();
    mockedSystemXData();
    mockedGfxData();
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade(null, "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    iceMockServer.ensureIceServerIsDown();
    String response = this.mockMvc.perform(post("/totv/updateTradesSet").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenIceIsDown(response, jacksonObjectMapper);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - All mock servers are Up except GFX and serves the request
   *
   *     When:
   *     - We receive updateTradesSet request
   *
   *     Then:
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradeSetWhenGfxIsDown() throws java.lang.Exception {
    String request = TotvControllerTestHelper.createRequestFromInput(totvTradeSetInputRequest(), jacksonObjectMapper);
    mockedDaveDataForTradeSetRequest();
    mockedSystemXData();
    mockedIceDataForTradeSetRequest();
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade(null, "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    gfxMockServer.ensureGfxServerIsDown();
    String response = this.mockMvc.perform(post("/totv/updateTradesSet").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenGfxIsDown(response, jacksonObjectMapper);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - All mock servers are Up except SystemX and serves the request
   *
   *     When:
   *     - We receive updateTradesSet request
   *
   *     Then:
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradeSetWhenSystemXIsDown() throws java.lang.Exception {
    String request = TotvControllerTestHelper.createRequestFromInput(totvTradeSetInputRequest(), jacksonObjectMapper);
    mockedDaveDataForTradeSetRequest();
    mockedIceDataForTradeSetRequest();
    mockedGfxData();
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade(null, "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    systemXMockServer.ensureSystemXServerIsDown();
    String response = this.mockMvc.perform(post("/totv/updateTradesSet").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenSystemXIsDown(response, jacksonObjectMapper);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - All mock servers are Up and serves the request
   *     - Request is running in readonly mode
   *     When:
   *     - We receive updateTradesSet request
   *
   *     - Trades will be segregated based on source system but will not process
   *     - Once all the trades are added to tradeSkipAmend list then the response will be asserted
   * </pre>
   */
  @Test
  public void testUpdateTradeSetWhenReadOnlyIsEnabled() throws java.lang.Exception {
    jmxProvider.enableReadOnlyMode(true);
    String request = TotvControllerTestHelper.createRequestFromInput(totvTradeSetInputRequest(), jacksonObjectMapper);
    mockedDaveDataForTradeSetRequest();
    mockedIceDataForTradeSetRequest();
    mockedGfxData();
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade(null, "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    mockedSystemXData();
    String response = this.mockMvc.perform(post("/totv/updateTradesSet").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenReadOnlyEnabled(response, jacksonObjectMapper);
    jmxProvider.enableReadOnlyMode(false);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give query for source system specified in the request and fetch trades
   *     - All mock servers are Up and serves the request
   *
   *     When:
   *     - We receive updateTradesForDateForSourceSystems request
   *
   *     Then:
   *     - IRS will be called and return 5 isins
   *     - ODC will give the trades for the isins fetched from IRS
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>;
   */
  @Test
  public void testupdateTradesForDateForSourceSystems() throws java.lang.Exception {
    Set<ItusTradeSourceSystem> sourceSystems = new HashSet<>();
    sourceSystems.add(ItusTradeSourceSystem.DAVE);
    sourceSystems.add(ItusTradeSourceSystem.ICE);
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    TotvTradeSystemsInput tradeSystemsInput = new TotvTradeSystemsInput(input, sourceSystems);
    String request = TotvControllerTestHelper.createRequestFromInput(tradeSystemsInput, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(tradeSystemsInput.getDateInput());
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    totvTrade.removeIf(trade -> !tradeSystemsInput.getSourceSystems().contains(trade.getItusTradeSourceSystem()));
    mockedDaveData();
    mockedIceData();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.eq(tradeSystemsInput.getSourceSystems()), Mockito.anyString())).thenReturn(totvTrade);
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNSourceSystems").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertThatResponseIsCorrectWhenSourceSystemsAreSpecified(response, jacksonObjectMapper);
  }


  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give query for source system specified in the request and fetch trades
   *     - All mock servers are Up and serves the request
   *
   *     When:
   *     - We receive updateTradesForDateForSourceSystemsAndIsins request
   *
   *     Then:
   *     - ODC will give the trades for the isins and the source systems mentioned in the request
   *     - Trades will be segregated based on source system and will process the request
   *     - Once all the request are processed, then the response will be asserted
   * </pre>;
   */
  @Test
  public void testupdateTradesForDateForSourceSystemsAndIsins() throws java.lang.Exception {
    Set<String> isinSet = new HashSet<>();
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    Set<ItusTradeSourceSystem> sourceSystems = new HashSet<>();
    sourceSystems.add(ItusTradeSourceSystem.DAVE);
    sourceSystems.add(ItusTradeSourceSystem.ICE);
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    TotvTradeSourceSystemDateIsinInput tradeSystemsInput = new TotvTradeSourceSystemDateIsinInput(input, sourceSystems, isinSet);
    String request = TotvControllerTestHelper.createRequestFromInput(tradeSystemsInput, jacksonObjectMapper);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    totvTrade.removeIf(trade -> !tradeSystemsInput.getSourceSystems().contains(trade.getItusTradeSourceSystem()));
    mockedDaveData();
    mockedIceData();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(input.getDate()), Mockito.eq(tradeSystemsInput.getSourceSystems()), Mockito.anyString())).thenReturn(totvTrade);
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNSourceSystemsNIsins").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertThatResponseIsCorrectWhenSourceSystemsAreSpecified(response, jacksonObjectMapper);
  }

  /**
   * <pre>
   *     Given:
   *     - Every System Is Up and Running and mocked data for every system is created
   *     - ODC will give trades for every source system
   *     - All mock servers are Up and serves the request
   *
   *     When:
   *     - We receive updateTradesForDate request
   *
   *     Then:
   *     - IRS will be called and return 5 isins
   *     - ODC will give the trades for the isins fetched from IRS
   *     - Trades will be segregated based on source system and will process the request
   *     - Threshold validation takes place
   *     - Once all the request are processed, then the response will be asserted
   * </pre>
   */
  @Test
  public void testupdateTradesForDateWhenDaveThresholdReached() throws java.lang.Exception {
    jmxProvider.setDaveThresholdLimit(0);
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedIceData();
    mockedSystemXData();
    mockedGfxData();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenDaveThresholdReached(response, jacksonObjectMapper);
    jmxProvider.setDaveThresholdLimit(200);
  }

  @Test
  public void testupdateTradesForDateWhenDaveThrReachedWithByPassThrTrue() throws java.lang.Exception {
    jmxProvider.setDaveThresholdLimit(0);
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedIceData();
    mockedSystemXData();
    mockedGfxData();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true").param("byPassThreshold" ,"true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertThatResponseIsCorrect(response, jacksonObjectMapper);
    jmxProvider.setDaveThresholdLimit(200);
  }

  @Test
  public void testupdateTradesForDateWhenAllSystemsThrReached() throws java.lang.Exception {
    jmxProvider.setDaveThresholdLimit(0);
    jmxProvider.setGfxThresholdLimit(1);
    jmxProvider.setIceThresholdLimit(1);
    jmxProvider.setIgnitebondsThresholdLimit(0);
    jmxProvider.setSystemXThresholdLimit(1);
    TotvInstrumentDateInput input = new TotvInstrumentDateInput(LocalDate.of(2017, 12, 21));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    TotvIrsResponse totvIRSResponse = mockedIrsData(input);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedIceData();
    mockedSystemXData();
    mockedGfxData();
    Set<TotvIrsInstrumentIdentifier> identifiers = (totvIRSResponse.getIsins());
    Set<String> instrumentData = new HashSet<>();
    identifiers.forEach(identifier -> instrumentData.add(identifier.getIdentifier()));
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(instrumentData), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDate").contentType(MediaType.APPLICATION_JSON).content(request).param("isDelta", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenAllSystemThrReached(response, jacksonObjectMapper);
    jmxProvider.setDaveThresholdLimit(200);
    jmxProvider.setGfxThresholdLimit(1000);
    jmxProvider.setIceThresholdLimit(200);
    jmxProvider.setIgnitebondsThresholdLimit(1000);
    jmxProvider.setSystemXThresholdLimit(1000);
  }

  @Test
  public void testUpdateTradeSetWhenAllSystemsThrReached() throws java.lang.Exception {
    jmxProvider.setDaveThresholdLimit(0);
    jmxProvider.setGfxThresholdLimit(1);
    jmxProvider.setIceThresholdLimit(1);
    jmxProvider.setIgnitebondsThresholdLimit(0);
    jmxProvider.setSystemXThresholdLimit(1);
    String request = TotvControllerTestHelper.createRequestFromInput(totvTradeSetInputRequest(), jacksonObjectMapper);
    mockedDaveDataForTradeSetRequest();
    mockedIceDataForTradeSetRequest();
    mockedSystemXData();
    mockedGfxData();
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade(null, "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesSet").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenAllSystemThrReached(response, jacksonObjectMapper);
    jmxProvider.setDaveThresholdLimit(200);
    jmxProvider.setGfxThresholdLimit(1000);
    jmxProvider.setIceThresholdLimit(200);
    jmxProvider.setIgnitebondsThresholdLimit(1000);
    jmxProvider.setSystemXThresholdLimit(1000);
  }

  @Test
  public void testUpdateTradeSetWhenAllSystemsThrReachedWithByPassTrue() throws java.lang.Exception {
    jmxProvider.setDaveThresholdLimit(0);
    jmxProvider.setGfxThresholdLimit(1);
    jmxProvider.setIceThresholdLimit(1);
    jmxProvider.setIgnitebondsThresholdLimit(1);
    jmxProvider.setSystemXThresholdLimit(1);
    String request = TotvControllerTestHelper.createRequestFromInput(totvTradeSetInputRequest(), jacksonObjectMapper);
    mockedDaveDataForTradeSetRequest();
    mockedIceDataForTradeSetRequest();
    mockedSystemXData();
    mockedGfxData();
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade(null, "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesSet").contentType(MediaType.APPLICATION_JSON).content(request).param("byPassThreshold", "true"))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertThatResponseIsCorrect(response, jacksonObjectMapper);
    jmxProvider.setDaveThresholdLimit(200);
    jmxProvider.setGfxThresholdLimit(1000);
    jmxProvider.setIceThresholdLimit(200);
    jmxProvider.setIgnitebondsThresholdLimit(1000);
    jmxProvider.setSystemXThresholdLimit(1000);
  }

  @Test
  public void testUpdateTradesOnIsinsWithDateWhenSystemXThrLimitReached() throws java.lang.Exception {
    jmxProvider.setSystemXThresholdLimit(1);
    Set<String> isinSet = new HashSet<>();
    isins.forEach(identifier -> isinSet.add(identifier.getIdentifier()));
    TotvInputForDateWithIsins input = new TotvInputForDateWithIsins(isinSet, (LocalDate.of(2017, 12, 21)));
    String request = TotvControllerTestHelper.createRequestFromInput(input, jacksonObjectMapper);
    Set<TotvTrade> totvTrade = mockedTotvTradesFromOdc();
    mockedDaveData();
    mockedIceData();
    mockedSystemXData();
    mockedGfxData();
    Mockito.when(tradeRetrievalService.retrieveTrades(Mockito.eq(isinSet), Mockito.eq(input.getDate()), Mockito.anySet(), Mockito.anyString())).thenReturn(totvTrade);
    Mockito.doNothing().when(jmsTemplate).send(Mockito.eq(messagingEventTopic), Mockito.eq(mockedIgniteData(new TotvTrade("DE0001030542", "1117588", ItusTradeSourceSystem.IGNITE, "GBLO"))));
    String response = this.mockMvc.perform(post("/totv/updateTradesForDateNIsins").contentType(MediaType.APPLICATION_JSON).content(request))
            .andExpect(status().isOk())
            .andExpect(content().contentType("application/json;charset=UTF-8"))
            .andReturn()
            .getResponse()
            .getContentAsString();
    TotvControllerTestHelper.assertResponseWhenSystemXThrReached(response, jacksonObjectMapper);
    jmxProvider.setSystemXThresholdLimit(1000);
  }

  private Set<TotvTradesInput> totvTradeSetInputRequest() {
    Set<TotvTradesInput> inputSet = new HashSet<>();

    TotvTradesInput totvTradesInput1 = new TotvTradesInput(Sets.newHashSet("118428069", "118428070"), ItusTradeSourceSystem.DAVE, "GBLO");
    TotvTradesInput totvTradesInput2 = new TotvTradesInput(Sets.newHashSet("1117588"), ItusTradeSourceSystem.IGNITE, "GBLO");
    TotvTradesInput totvTradesInput3 = new TotvTradesInput(Sets.newHashSet("192996010", "192994370"), ItusTradeSourceSystem.ICE, "GBLO");
    TotvTradesInput totvTradesInput4 = new TotvTradesInput(Sets.newHashSet("17355LN024844D", "17305LN024728D"), ItusTradeSourceSystem.SYSTEMX, "GBLO");
    TotvTradesInput totvTradesInput5 = new TotvTradesInput(Sets.newHashSet("N171219A49E0B", "L171220A40488"), ItusTradeSourceSystem.GFX, "GBLO");
    inputSet.add(totvTradesInput1);
    inputSet.add(totvTradesInput2);
    inputSet.add(totvTradesInput3);
    inputSet.add(totvTradesInput4);
    inputSet.add(totvTradesInput5);
    return inputSet;
  }


  protected void mockedIceDataForTradeSetRequest() throws JsonProcessingException {
    TotvIceRequest iceRequest1 = new TotvIceRequest();
    iceRequest1.setTransactionIdentifier("192996010");
    iceRequest1.setIsin("XS1234556A");
    TotvIceRequest iceRequest2 = new TotvIceRequest();
    iceRequest2.setTransactionIdentifier("192994370");
    iceRequest2.setIsin("XS1234556A");

    TotvIceResponse iceResponse1 = new TotvIceResponse();
    iceResponse1.setResponseCode("0");
    iceResponse1.setResponseMessage("Processed Successfully");
    iceResponse1.setExceptionMessage("");
    TotvIceResponse iceResponse2 = new TotvIceResponse();
    iceResponse2.setResponseCode("1");
    iceResponse2.setResponseMessage("Processing failed");
    iceResponse2.setExceptionMessage("Invalid transaction id");

    iceMockServer.ensureIceResponse(iceRequest1, jacksonObjectMapper.writeValueAsString(iceResponse1), iceRequest2, jacksonObjectMapper.writeValueAsString(iceResponse2));

  }

  private void mockedDaveDataForTradeSetRequest() throws JsonProcessingException {
    TotvDaveRequest daveRequest1 = new TotvDaveRequest();
    Identifier identifier1 = new Identifier();
    identifier1.setContractId(118428069);
    identifier1.setSiteId("GBLO");
    daveRequest1.setTarget(identifier1);
    daveRequest1.setIsin("");
    TotvDaveRequest daveRequest2 = new TotvDaveRequest();
    Identifier identifier2 = new Identifier();
    identifier2.setContractId(118428070);
    identifier2.setSiteId("GBLO");
    daveRequest2.setTarget(identifier2);
    daveRequest2.setIsin("");
    TotvDaveResponse daveResponse1 = new TotvDaveResponse();
    ResponseDto responseObj = new ResponseDto();
    responseObj.setCode(0);
    responseObj.setErrors(new String[]{});
    responseObj.setExceptions(new Exception[]{});
    responseObj.setInformation(new String[]{});
    responseObj.setValidationResults(new ValidationResults[]{});
    daveResponse1.setResponseDto(responseObj);
    TotvDaveResponse daveResponse2 = new TotvDaveResponse();
    ResponseDto responseObj2 = new ResponseDto();
    responseObj2.setCode(1);
    responseObj2.setErrors(new String[]{"trade id not valid"});
    responseObj2.setExceptions(new Exception[]{});
    responseObj2.setInformation(new String[]{});
    responseObj2.setValidationResults(new ValidationResults[]{});
    daveResponse2.setResponseDto(responseObj2);
    daveMockServer.ensureDaveResponse(jacksonObjectMapper.writeValueAsString(daveRequest1), jacksonObjectMapper.writeValueAsString(daveResponse1), jacksonObjectMapper.writeValueAsString(daveRequest2), jacksonObjectMapper.writeValueAsString(daveResponse2));
  }
}
