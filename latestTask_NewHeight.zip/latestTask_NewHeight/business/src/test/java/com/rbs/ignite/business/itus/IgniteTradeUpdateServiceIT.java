package com.rbs.ignite.business.itus;

import com.rbs.ignite.business.itus.totv.TotvStarter;
import com.rbs.ignite.business.itus.util.configurer.totv.TotvTestConfigurer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { TotvStarter.class, TotvTestConfigurer.class })
@WebAppConfiguration
@DirtiesContext
public class IgniteTradeUpdateServiceIT {

  @Test
  public void implementMe() throws Exception {
    
  }
}