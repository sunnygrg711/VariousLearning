package org.sk.tutorial.jfamily.concurrency.examples.session1_3;

public class ALoop {
        private Object data;

        @Override
        public String toString() {
            return "ALoop{" +
                    "data=" + data +
                    '}';
        }

    public void setData(Object data) {
        this.data = data;
    }
}