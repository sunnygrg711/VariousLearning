package com.rbs.ignite.business.itus.mgmt;

import com.fasterxml.jackson.databind.JsonNode;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import com.rbs.odc.access.ODCFactory;
import com.rbs.odc.access.start.ODCSimpleStart;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;

/**
 * Created by kumaunn on 31/03/2018.
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest(ODCSimpleStart.class)
@PowerMockIgnore("javax.management.*")
public class ODCHealthIndicatorTest {

  @InjectMocks
  private OdcHealthIndicator healthIndicator;

  @Mock JsonNode jsonNode;

  @Mock
  private ODCFactory odcFactory;

  @Before
  public void setup() throws IllegalAccessException, NoSuchFieldException{
    MockitoAnnotations.initMocks(this);
    ReflectionUtil.setPrivateField(OdcHealthIndicator.class, healthIndicator, "odcEnvironment","uat5");
    ReflectionUtil.setPrivateField(OdcHealthIndicator.class, healthIndicator, "odcUser","appuser");
    ReflectionUtil.setPrivateField(OdcHealthIndicator.class, healthIndicator, "odcPassword","appuser");
    ReflectionUtil.setPrivateField(OdcHealthIndicator.class, healthIndicator, "odcInitialisationTimeoutMillis","1000");
    ReflectionUtil.setPrivateField(OdcHealthIndicator.class, healthIndicator, "odcRetryCount","1");
    ReflectionUtil.setPrivateField(OdcHealthIndicator.class, healthIndicator, "odcExecutionTimeoutMillis","1000");
    ReflectionUtil.setPrivateField(OdcHealthIndicator.class, healthIndicator, "odcBlenderEnabled","true");
    ReflectionUtil.setPrivateField(OdcHealthIndicator.class, healthIndicator, "odcOslHost","uat3");
    ReflectionUtil.setPrivateField(OdcHealthIndicator.class, healthIndicator, "odcOslPort","1089");
  }

  @Test
  public void testDoHealthCheckDOWN_ODCNULL() throws Exception{
    PowerMockito.mockStatic(ODCSimpleStart.class);
    PowerMockito.when(ODCSimpleStart.getODCFactory()).thenReturn(odcFactory);
    PowerMockito.when(odcFactory.getAccessLayerInstance(Mockito.anyString(), Mockito.anyString())).thenReturn(null);

    Mockito.when(jsonNode.asText()).thenReturn("DOWN");
    Health.Builder build = new Health.Builder(Status.DOWN);
    healthIndicator.doHealthCheck(build);
    Health health = build.build();
    Assert.assertEquals(Status.DOWN, health.getStatus());
  }
}
