package com.rbs.ignite.domain.itus.trade.totv.dave;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ValidationResults {
  @JsonProperty("Message")
  private String message;
  @JsonProperty("type")
  private ValidationResultType type;

  public String getMessage() {
    return message;
  }
  public ValidationResultType getType() {
    return type;
  }
  public void setMessage(String message) {
    this.message = message;
  }
  public void setType(ValidationResultType type) {
    this.type = type;
  }
  @Override
  public String toString() {
    return "ValidationResults{" +
            "message='" + message + '\'' +
            ", type=" + type +
            '}';
  }
}
