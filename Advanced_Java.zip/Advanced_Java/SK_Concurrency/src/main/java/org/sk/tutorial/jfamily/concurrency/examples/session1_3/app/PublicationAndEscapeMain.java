package org.sk.tutorial.jfamily.concurrency.examples.session1_3.app;

import org.sk.tutorial.jfamily.concurrency.examples.session1_3.DataRegistry;
import org.sk.tutorial.jfamily.concurrency.examples.session1_3.ALoop;
import org.sk.tutorial.jfamily.concurrency.examples.session1_3.PublicationAndEscape;

/**
 * Created by kshekar on 24/04/2018.
 */
public class PublicationAndEscapeMain {


    public static void main(String[] args) {
        DataRegistry dataRegistry=new DataRegistry();
        PublicationAndEscape publicationAndEscape=new PublicationAndEscape(dataRegistry);
        System.out.println(dataRegistry.getiDatas());
        ALoop ALoop =new ALoop();
        dataRegistry.getiDatas().get(0).doAction(ALoop);
        System.out.println(ALoop);
    }
}
