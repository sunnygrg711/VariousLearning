package com.rbs.ignite.business.itus.web.controller.totv.mock;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceRequest;
import org.springframework.boot.test.context.TestComponent;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

public class IceMockServer {

  private int mockServerPort;

  private WireMockServer server;

  private ObjectMapper objectMapper;

  public IceMockServer(String iceUrl) {
    this.mockServerPort = MockServerUtil.getPortNumber(iceUrl);
    server = new WireMockServer(mockServerPort);
  }

  public WireMockServer ensureIceServerIsDown() {
    server.stop();
    MockServerUtil.waitTillServerStops(server, mockServerPort);
    return server;
  }

  public WireMockServer ensureIceResponse(TotvIceRequest request1, String response1, TotvIceRequest request2, String response2) {

    if (server.isRunning()) {
      server.resetAll();
    } else {
      server.start();
      MockServerUtil.waitTillServerStarts(server, mockServerPort);
    }


    try {
      server.stubFor(
              get(urlEqualTo("/trade-stamping/totv-refresh/ICE/" + request1.getTransactionIdentifier() + "/" + request1.getIsin()))
                      .willReturn(
                              aResponse()
                                      .withStatus(HttpStatus.OK.value())
                                      .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                      .withBody(response1)
                      )
      );
      server.stubFor(
              get(urlEqualTo("/trade-stamping/totv-refresh/ICE/" + request2.getTransactionIdentifier() + "/" + request2.getIsin()))
                      .willReturn(
                              aResponse()
                                      .withStatus(HttpStatus.OK.value())
                                      .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                      .withBody(response2)
                      )
      );
      return server;
    } catch (Exception e) {
      throw new RuntimeException(e);
    }

  }
}
