package org.sk.tutorial.jfamily.concurrency.examples.session1_1;

/**
 * Created by kshekar on 07/05/2018.
 */
public class PrintOdd extends Thread {

    private EvenOddFlagger evenOddFlagger;

    public PrintOdd(EvenOddFlagger evenOddFlagger) {
        this.evenOddFlagger = evenOddFlagger;
    }

    @Override
    public void run() {
        int printCounter = 0;
        while (++printCounter <= evenOddFlagger.getCounter()) {
            synchronized (evenOddFlagger) {
                try {
                    sleep(evenOddFlagger.getWaitingTimeInMS());
                    if (!evenOddFlagger.isEvenTerm()) {
                        System.out.println(getName() + "-Odd-" + printCounter);
                        evenOddFlagger.setFlag(true);
                        evenOddFlagger.notify();
                    } else {
                        evenOddFlagger.wait();
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
