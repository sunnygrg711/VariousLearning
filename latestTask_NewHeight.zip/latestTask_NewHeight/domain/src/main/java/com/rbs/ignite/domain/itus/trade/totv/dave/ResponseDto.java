package com.rbs.ignite.domain.itus.trade.totv.dave;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.lang.*;
import java.util.Arrays;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseDto {

  @JsonProperty("Code")
  private Integer code;
  @JsonProperty("ValidationResults")
  private ValidationResults[] validationResults;
  @JsonProperty("Information")
  private String[] information;
  @JsonProperty("Warnings")
  private String[] warnings;
  @JsonProperty("Errors")
  private String[] errors;
  @JsonProperty("Exceptions")
  private Exception[] exceptions;

  public Integer getCode() {
    return code;
  }
  public ValidationResults[] getValidationResults() {
    return validationResults;
  }
  public String[] getInformation() {
    return information;
  }
  public String[] getWarnings() {
    return warnings;
  }
  public String[] getErrors() {
    return errors;
  }
  public Exception[] getExceptions() {
    return exceptions;
  }
  public void setCode(Integer code) {
    this.code = code;
  }
  public void setValidationResults(ValidationResults[] validationResults) {
    this.validationResults = validationResults;
  }
  public void setInformation(String[] information) {
    this.information = information;
  }
  public void setWarnings(String[] warnings) {
    this.warnings = warnings;
  }
  public void setErrors(String[] errors) {
    this.errors = errors;
  }
  public void setExceptions(Exception[] exceptions) {
    this.exceptions = exceptions;
  }
  @Override
  public String toString() {
    return "ResponseDto{" +
            "code=" + code +
            ", validationResults=" + Arrays.toString(validationResults) +
            ", information=" + Arrays.toString(information) +
            ", warnings=" + Arrays.toString(warnings) +
            ", errors=" + Arrays.toString(errors) +
            ", exceptions=" + Arrays.toString(exceptions) +
            '}';
  }
}