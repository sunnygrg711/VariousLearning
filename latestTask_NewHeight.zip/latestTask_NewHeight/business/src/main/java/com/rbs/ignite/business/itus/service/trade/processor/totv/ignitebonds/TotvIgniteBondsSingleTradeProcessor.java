package com.rbs.ignite.business.itus.service.trade.processor.totv.ignitebonds;


import com.google.gson.Gson;
import com.rbs.ignite.api.itus.service.trade.processor.ItusSingleTradeProcessor;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.request.RequestEntity;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds.Event;
import com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds.Identifier;
import com.rbs.ignite.domain.itus.trade.totv.requests.ignitebonds.IgniteRequestEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import javax.jms.Message;
import javax.jms.Session;

/**
 * Created by upadkti on 09/11/2017.
 */
public class TotvIgniteBondsSingleTradeProcessor implements ItusSingleTradeProcessor<TotvTrade> {

  private static final Logger logger = LoggerFactory.getLogger(TotvIgniteBondsSingleTradeProcessor.class);

  private @Value("${totv.ignite.event.type}") String igniteBondsEventType;
  private @Value("${totv.ignite.site.id}") String igniteBondsSiteId;

  private JmsTemplate jmsTemplate;
  private String messagingHeaderKey;
  private String messagingHeaderValue;
  private String messagingEventTopic;

  public TotvIgniteBondsSingleTradeProcessor(JmsTemplate jmsTemplate, String messagingHeaderKey,
                                             String messagingHeaderValue,String messagingEventTopic) {
    this.jmsTemplate = jmsTemplate;
    this.messagingHeaderKey = messagingHeaderKey;
    this.messagingHeaderValue= messagingHeaderValue;
    this.messagingEventTopic = messagingEventTopic;
  }

  @Override
  public TotvTradeStatus processTrade(TotvTrade totvTrade, String requestId) throws ItusException {
    TotvTradeStatus status = new TotvTradeStatus.TotvTradeStatusBuilder(totvTrade, ItusStatus.ACCEPTED, HttpStatus.OK.toString()).message("success").build();;
    try {
      logger.info(requestId+":"+"Sending message to destination: "+messagingEventTopic);
      jmsTemplate.send(messagingEventTopic, createMessage(totvTrade,requestId));
      logger.info(requestId+":"+"Message sent to destination: "+messagingEventTopic);
    } catch(Exception e) {
      logger.warn(requestId+":"+"Exception occured while sending ems message: {}", e);
      status = new TotvTradeStatus.TotvTradeStatusBuilder(totvTrade, ItusStatus.REJECTED, HttpStatus.SERVICE_UNAVAILABLE.toString()).message(e.getMessage()).build();
    }
    return status;
  }

  private MessageCreator createMessage(TotvTrade totvTrade, String requestId) {
    String payload = getStringMessage(totvTrade);
    logger.info(requestId+":"+"Message Created: " + payload);
    MessageCreator messageCreator = (Session arg0) -> {
      Message msg = arg0.createTextMessage(payload);
      msg.setStringProperty(messagingHeaderKey, messagingHeaderValue);
      return msg;
    };
    return messageCreator;
  }

  private String getStringMessage(TotvTrade totvTrade) {
    Identifier identifier = new Identifier(igniteBondsSiteId,totvTrade.getTradeIdentifier());
    Event event = new Event(igniteBondsEventType,totvTrade.getIsin());
    RequestEntity requestEntity = new IgniteRequestEntity(identifier,event);
    return new Gson().toJson(requestEntity);
  }
}
