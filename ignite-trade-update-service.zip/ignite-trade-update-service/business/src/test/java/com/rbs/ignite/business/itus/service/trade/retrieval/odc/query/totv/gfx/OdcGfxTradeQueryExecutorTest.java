package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.gfx;

import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.dave.OdcDaveTradeQueryExecutor;
import com.rbs.ignite.business.itus.totv.TotvStarter;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import com.rbs.odc.access.ODC;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.query.Query;
import com.rbs.odc.dynamicquery.From;
import com.rbs.odc.dynamicquery.TransactionAnd;
import com.rbs.odc.dynamicquery.TransactionWhere;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.LocalDate;
import java.util.Set;

/**
 * Created by upadkti on 11/12/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TotvStarter.class)
public class OdcGfxTradeQueryExecutorTest {
  @Mock
  private ODC odc;
  @Mock
  private From from;
  @Mock
  private Query query;
  @Mock
  private TransactionWhere transactionWhere;
  @Mock
  private TransactionAnd andType;
  @Mock
  private Transaction transaction;
  @Autowired
  @InjectMocks
  private OdcDaveTradeQueryExecutor testObj;

  @Before
  public void setup() throws Exception {
    MockitoAnnotations.initMocks(this);
    ReflectionUtil.setPrivateField(OdcDaveTradeQueryExecutor.class,testObj,"systemInstanceIds","PabFX");
    ReflectionUtil.setPrivateField(OdcDaveTradeQueryExecutor.class,testObj,"tradeStatusStr","Cancelled");
  }

  @Test
  public void executeQuery() {
    Mockito.when(odc.from()).thenReturn(from);
    Mockito.when(from.transaction()).thenReturn(transactionWhere);
    Mockito.when(transactionWhere.complexWhere(Mockito.any())).thenReturn(andType);
    Mockito.when(andType.arrivedBetween(Mockito.any(),Mockito.any())).thenReturn(andType);
    Mockito.when(andType.driveFromLatest()).thenReturn(query);
    Mockito.when(query.execute()).thenReturn(Sets.newSet(transaction).iterator());

    Set<String> input = Sets.newSet("ISIN1234546");
    Set<Transaction> transactions  = testObj.executeQuery(input, LocalDate.of(2017,12,07));

    Assert.assertTrue(transactions != null);
    Assert.assertTrue(transactions.contains(transaction));
  }
}
