package com.rbs.ignite.business.itus.transformer.totv;

import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.odc.access.domain.Transaction;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Set;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.eq;

/**
 * Created by upadkti on 07/12/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class TransactionToTotvTradeTransformerTest {

  @InjectMocks
  private TransactionToTotvTradeTransformer testObj = new TransactionToTotvTradeTransformer();
  @Mock
  ConversionService conversionService;
  @Mock
  private Transaction transaction;

  private TypeDescriptor sourceType;
  private TypeDescriptor targetType;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    sourceType = TypeDescriptor.valueOf(Transaction.class);
    targetType = TypeDescriptor.valueOf(TotvTrade.class);
  }

  @After
  public void tearDown() {
    testObj = null;
  }

  @Test
  public void testTransform() throws ItusTransformException {
    Set<Transaction> input = Sets.newSet(transaction);
    Mockito.when(conversionService.convert(Mockito.anyObject(), eq(sourceType), eq(targetType))).thenReturn(null);
    Set<TotvTrade> outputSet = testObj.transform(input);
    assertTrue(outputSet == null);
  }
}
