package com.rbs.ignite.business.itus.configurer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rbs.rates.foundation.security.SecurityProvider;
import com.rbs.rates.foundation.security.spring.BaseSecurityConfigurer;

/**
 * An implementation of {@link BaseSecurityConfigurer} for the exemplar service. Defines the secured URL pattern and allocates the 
 * {@link SecurityProvider} to the parent so that all authentication and authorization calls for this service are handled by
 * that provider.  
 */
@Component
public class IgniteTradeUpdateServiceSecurityConfigurer extends BaseSecurityConfigurer {

  /**
   * Only apply security to the secure endpoint
   */
  private static final String SECURE_ENDPOINT_ADDRESS_PATTERN = "^/.*";

  @Autowired
  public IgniteTradeUpdateServiceSecurityConfigurer(SecurityProvider securityProvider) {
    super(securityProvider, SECURE_ENDPOINT_ADDRESS_PATTERN);
  }
}