package com.rbs.ignite.domain.itus.odc;

import org.springframework.beans.factory.annotation.Value;

public class OdcConnectionInput {

  private String odcEnvironment;
  private String odcUser;
  private String odcPassword;
  private String odcInitialisationTimeoutMillis;
  private String odcRetryCount;
  private String odcExecutionTimeoutMillis;
  private String odcBlenderEnabled;
  private String odcOslHost;
  private String odcOslPort;

  public OdcConnectionInput(String odcEnvironment, String odcUser, String odcPassword, String odcInitialisationTimeoutMillis, String odcRetryCount, String odcExecutionTimeoutMillis, String odcBlenderEnabled, String odcOslHost , String odcOslPort) {
    this.odcEnvironment = odcEnvironment;
    this.odcUser = odcUser;
    this.odcPassword = odcPassword;
    this.odcInitialisationTimeoutMillis = odcInitialisationTimeoutMillis;
    this.odcRetryCount = odcRetryCount;
    this.odcExecutionTimeoutMillis = odcExecutionTimeoutMillis;
    this.odcBlenderEnabled = odcBlenderEnabled;
    this.odcOslHost = odcOslHost;
    this.odcOslPort = odcOslPort;
  }
  public String getOdcEnvironment() {
    return odcEnvironment;
  }
  public String getOdcUser() {
    return odcUser;
  }
  public String getOdcPassword() {
    return odcPassword;
  }
  public String getOdcInitialisationTimeoutMillis() {
    return odcInitialisationTimeoutMillis;
  }
  public String getOdcRetryCount() {
    return odcRetryCount;
  }
  public String getOdcExecutionTimeoutMillis() {
    return odcExecutionTimeoutMillis;
  }
  public String getOdcBlenderEnabled() {
    return odcBlenderEnabled;
  }

  public String getOdcOslHost() {
    return odcOslHost;
  }

  public String getOdcOslPort() {
    return odcOslPort;
  }

  @Override
  public String toString() {
    return "OdcConnectionInput{" +
            "odcEnvironment='" + odcEnvironment + '\'' +
            ", odcUser='" + odcUser + '\'' +
            ", odcPassword='" + odcPassword + '\'' +
            ", odcInitialisationTimeoutMillis='" + odcInitialisationTimeoutMillis + '\'' +
            ", odcRetryCount='" + odcRetryCount + '\'' +
            ", odcExecutionTimeoutMillis='" + odcExecutionTimeoutMillis + '\'' +
            ", odcOslHost='" + odcOslHost + '\'' +
            ", odcOslPort='" + odcOslPort + '\'' +
            '}';
  }
}
