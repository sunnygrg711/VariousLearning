package com.rbs.ignite.domain.itus.trade;


import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

/**
 * Created by puronaa on 24/08/2017.
 */
public interface ItusTrade {
    String getIsin();

    String getTradeIdentifier();

    ItusTradeSourceSystem getItusTradeSourceSystem();

    String getActualSourceSystem();

    String getVersion();

    String getLocation();
}
