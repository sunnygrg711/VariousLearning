package com.rbs.ignite.business.itus.mgmt;

import com.fasterxml.jackson.databind.JsonNode;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

/**
 * Created by kumaunn on 31/03/2018.
 */

@RunWith(SpringJUnit4ClassRunner.class)
public class IRSHealthIndicatorTest {

  @InjectMocks
  private IrsHealthIndicator healthIndicator;

  @Mock RestTemplate restTemplate;

  @Mock JsonNode jsonNode;

  @Before
  public void setup() {
    Mockito.when(restTemplate.getForObject(Mockito.anyString(), Mockito.any())).thenReturn(jsonNode);
    Mockito.when(jsonNode.get(Mockito.anyString())).thenReturn(jsonNode);
    Mockito.when(jsonNode.asText()).thenReturn("DOWN");

  }

  @Test
  public void testDoHealthCheckDOWN() throws Exception{
    Mockito.when(jsonNode.asText()).thenReturn("DOWN");
    Health.Builder build = new Health.Builder(Status.DOWN);
    healthIndicator.doHealthCheck(build);
    Health health = build.build();
    Assert.assertEquals(Status.DOWN, health.getStatus());
  }

}
