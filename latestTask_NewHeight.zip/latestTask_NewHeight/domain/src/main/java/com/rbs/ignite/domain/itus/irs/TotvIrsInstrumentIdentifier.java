package com.rbs.ignite.domain.itus.irs;

/**
 * Created by upadkti on 01/12/2017.
 */

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TotvIrsInstrumentIdentifier implements Serializable {

  private static final long serialVersionUID = 1L;

  private final String identifier;
  private final String name;
  private final String description;
  private final String identifierType;

  public TotvIrsInstrumentIdentifier(String identifier, String identifierType) {
    this.identifier = identifier.trim();
    this.identifierType = identifierType;
    this.name = null;
    this.description = null;
  }

  @JsonCreator
  public TotvIrsInstrumentIdentifier(@JsonProperty("identifier") String identifier,
                                     @JsonProperty("identifierType") String identifierType, @JsonProperty("name") String name,
                                     @JsonProperty("description") String description) {
    this.identifier = identifier.trim();
    this.name = name;
    this.identifierType = identifierType;
    this.description = description;
  }

  public String getIdentifier() {
    return identifier;
  }

  public String getName() {
    return name;
  }

  public String getDescription() {
    return description;
  }

  public String getIdentifierType() {
    return identifierType;
  }

  @Override
  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }

  @Override
  public boolean equals(Object obj) {
    return EqualsBuilder.reflectionEquals(this, obj);
  }

  @Override
  public String toString() {
    return identifier;
  }
}

