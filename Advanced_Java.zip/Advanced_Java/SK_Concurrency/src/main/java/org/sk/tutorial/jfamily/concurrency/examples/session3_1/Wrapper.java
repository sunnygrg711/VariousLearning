package org.sk.tutorial.jfamily.concurrency.examples.session3_1;// Java program to illustrate
// GC Overhead limit exceeded
import java.util.*;
 
public class Wrapper {
public static void main(String args[]) throws Exception
    {
        Map m = new HashMap();
        m = System.getProperties();
        Random r = new Random();
        while (true) {
            m.put(r.nextInt(), "randomValue");
            System.out.println(m);
        }
    }
}