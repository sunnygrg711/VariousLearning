package org.sk.tutorial.jfamily.concurrency.animation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *  This frame shows the array as it is sorted, together with buttons to single-step the animation
 *  or to run it without interruption.
 * Created by kshekar on 22/03/2018.
 */
public class AnimationFrame extends JFrame {
    private static final int DEFAULT_WIDTH = 300;
    private static final int DEFAULT_HEIGHT = 300;
    private static final int VALUES_LENGTH = 30;

    /**
     * Constructs a new frame that is initially invisible.
     * <p>
     * This constructor sets the component's locale property to the value
     * returned by <code>JComponent.getDefaultLocale</code>.
     *
     * @throws HeadlessException if GraphicsEnvironment.isHeadless()
     *                           returns true.
     * @see GraphicsEnvironment#isHeadless
     * @see Component#setSize
     * @see Component#setVisible
     * @see JComponent#getDefaultLocale
     */
    public AnimationFrame(String name) throws HeadlessException {
        super(name);
        ArrayPanel panel = new ArrayPanel();
        add(panel, BorderLayout.CENTER);

        Double[] values = new Double[VALUES_LENGTH];
        final SorterRunnable sorter = SortingAlgorithmFactory.getInstance().getSortingAlgorithm(values, panel,System.getProperty("sortingAlgo","JAVA_DEFAULT_API"));

        JButton runButton = new JButton("Run");
        runButton.addActionListener(new
                                            ActionListener()
                                            {
                                                public void actionPerformed(ActionEvent event)
                                                {
                                                    sorter.setRun();
                                                }
                                            });

        JButton stepButton = new JButton("Step");
        stepButton.addActionListener(new
                                             ActionListener()
                                             {
                                                 public void actionPerformed(ActionEvent event)
                                                 {
                                                     sorter.setStep();
                                                 }
                                             });

        JPanel buttons = new JPanel();
        buttons.add(runButton);
        buttons.add(stepButton);
        add(buttons, BorderLayout.NORTH);
        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);

        for (int i = 0; i < values.length; i++)
            values[i] = new Double(Math.random());

        Thread t = new Thread(sorter);
        t.start();
    }
}
