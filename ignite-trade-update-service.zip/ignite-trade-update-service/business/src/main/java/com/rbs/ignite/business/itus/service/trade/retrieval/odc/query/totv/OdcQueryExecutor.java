package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv;


import com.google.common.base.Stopwatch;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusQueryExecutor;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusTradeQueryExecutor;
import com.rbs.ignite.business.itus.configurer.totv.SourceSystemToOdcTradeExecutorMapper;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.OdcQueryExecutorHelper;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.OdcQueryInputData;
import com.rbs.ignite.domain.itus.enums.QueryParamName;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.transaction;

/**
 * Created by puronaa on 03/10/2017.
 */
public class OdcQueryExecutor implements ItusQueryExecutor<Set<Transaction>> {

  private static final Logger logger = LoggerFactory.getLogger(OdcQueryExecutor.class);

  @Autowired
  private SourceSystemToOdcTradeExecutorMapper sourceSystemToOdcExecutorMapper;

  @Override
  public Set<Transaction> executeQuery(ConcurrentMap<QueryParamName, Object> parameterMap) {
    //prepare the inputData for query
    OdcQueryInputData odcQueryInputData = OdcQueryExecutorHelper.convertParameterMapToInputData(parameterMap);
    return getTransactionsForIsinSet(odcQueryInputData);
  }

  private Set<Transaction> getTransactionsForIsinSet(OdcQueryInputData odcQueryInputData) {
    Set<Transaction> transactions = new HashSet<>();

    //validate the input parameters
    Set<String> isins = odcQueryInputData.getiSin();
    OdcQueryExecutorHelper.validateInputParam("ISIN", isins);
    Set<ItusTradeSourceSystem> sourceSystems = odcQueryInputData.getSourceSystems();
    OdcQueryExecutorHelper.validateInputParam("SourceSystem",sourceSystems);

    // prepare Odc query and executeQuery to get trades from ODC
    Stopwatch stopwatch = Stopwatch.createStarted();
    sourceSystems.forEach((sourceSystem)->{
      logger.info("Querying ODC to get trades for source system {}: ", sourceSystem);
      Set<Transaction> transactionForSystem = null;

      try {
        ItusTradeQueryExecutor<Transaction> queryExecutor = sourceSystemToOdcExecutorMapper.getExecutor(sourceSystem);
        transactionForSystem = queryExecutor.executeQuery(isins,odcQueryInputData.getBusinessDate());
        // Filter out the trades which are cancelled for IGNITE
        if(transactionForSystem != null && sourceSystem == ItusTradeSourceSystem.IGNITE) {
          Iterator<Transaction> iterator = transactionForSystem.iterator();
          while(iterator.hasNext()) {
            Transaction transaction = iterator.next();
            if(transaction.getTransactionState()==TransactionState.Cancelled) {
              iterator.remove();
            }
          }
        }

        if (logger.isDebugEnabled()) {
          List<String> transactionIds = new ArrayList<>();
          transactionForSystem.forEach((transaction)->{
            transactionIds.add(transaction().getId().getSourceSystemTransactionId());
          });
          logger.debug("Trades for source system {}: {}: ",sourceSystem,transactionIds);
        }
      } catch(RuntimeException ex) {
        logger.error("Error occurred while querying trades for source system {}, skipping...", sourceSystem, ex);
      }

      if(transactionForSystem != null) {
        transactions.addAll(transactionForSystem);
      }
    });

    stopwatch.stop();
    logger.info("ODC query completed, found {} records in {} ms", transactions.size(), stopwatch.elapsed(TimeUnit.MILLISECONDS));
    return transactions;
  }
}