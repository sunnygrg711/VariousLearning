package org.sk.tutorial.jfamily.concurrency.examples.session3_1;


import java.util.Random;
import java.util.concurrent.Phaser;
import java.util.concurrent.TimeUnit;

public class FloorConstructor implements Runnable {
    private Phaser constructionPhaser;

    public FloorConstructor(Phaser constructionPhaser) {
        this.constructionPhaser = constructionPhaser;
        this.constructionPhaser.register();
    }

    @Override
    public void run() {
        String threadName = Thread.currentThread().getName();
        System.out.println("Arrive and await advance:" + threadName);
        constructionPhaser.arriveAndAwaitAdvance();
        int finishingCounter = 100 + new Random().nextInt(5000);
        long startTime = System.currentTimeMillis();
        try {
            TimeUnit.MILLISECONDS.sleep(finishingCounter);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        constructionPhaser.arriveAndDeregister();
        System.out.println(threadName + " is de-registered and total time taken in second:" + (System.currentTimeMillis() - startTime) / 1000);

    }
}
