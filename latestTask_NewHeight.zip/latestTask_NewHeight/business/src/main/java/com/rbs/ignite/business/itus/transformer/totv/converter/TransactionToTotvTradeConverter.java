package com.rbs.ignite.business.itus.transformer.totv.converter;


import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.SourceSystemToOdcSystemInstaceIdMapper;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.converter.Converter;

import java.util.Collection;

/**
 * Created by puronaa on 19/09/2017.
 */
public class TransactionToTotvTradeConverter implements Converter<Transaction, TotvTrade> {
  private static final Logger logger = LoggerFactory.getLogger(TransactionToTotvTradeConverter.class);

  @Override
  public TotvTrade convert(Transaction transaction) {
    String isin = null;
    Collection<RegulatoryRegimeImpact> txnLegSet = transaction.getRegulatoryRegimeImpact();
    for (RegulatoryRegimeImpact regimeImpact : txnLegSet) {
      Collection<ReportableInstrument> reportableInstruments = regimeImpact.getReportableInstruments();
      if (reportableInstruments == null) {
        continue;
      }
      for (ReportableInstrument reportableInstrument : reportableInstruments) {
        isin = reportableInstrument.getInstrumentId();

      }
    }

    String tradeId = transaction.getId().getSourceSystemTransactionId();
    SystemInstanceId actualSourceSystem = transaction.getId().getSourceSystemId();
    String location = null;
    if (transaction.getLocation() == null) {
      logger.warn("Location is null for transaction {}", tradeId);
    } else {
      location = transaction.getLocation().javaName();
    }
    ItusTradeSourceSystem itusTradeSourceSystem;
    if (SourceSystemToOdcSystemInstaceIdMapper.DAVE.getSystemInstanceIds().contains(actualSourceSystem)) {
      itusTradeSourceSystem = ItusTradeSourceSystem.DAVE;
    } else if (SourceSystemToOdcSystemInstaceIdMapper.GFX.getSystemInstanceIds().contains(actualSourceSystem)) {
      itusTradeSourceSystem = ItusTradeSourceSystem.GFX;
    } else if (SourceSystemToOdcSystemInstaceIdMapper.SYSTEMX.getSystemInstanceIds().contains(actualSourceSystem)) {
      itusTradeSourceSystem = ItusTradeSourceSystem.SYSTEMX;
    } else if (SourceSystemToOdcSystemInstaceIdMapper.ICE.getSystemInstanceIds().contains(actualSourceSystem)) {
      itusTradeSourceSystem = ItusTradeSourceSystem.ICE;
    } else if (SourceSystemToOdcSystemInstaceIdMapper.IGNITE.getSystemInstanceIds().contains(actualSourceSystem)) {
      itusTradeSourceSystem = ItusTradeSourceSystem.IGNITE;
    } else {
      throw new ItusFatalErrorException(actualSourceSystem + " is not supported.");
    }

    return new TotvTrade(isin, tradeId, itusTradeSourceSystem, location);
  }
}
