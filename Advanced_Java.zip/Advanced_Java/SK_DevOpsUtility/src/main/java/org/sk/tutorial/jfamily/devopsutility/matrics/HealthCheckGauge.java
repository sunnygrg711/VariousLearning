package org.sk.tutorial.jfamily.devopsutility.matrics;

import com.codahale.metrics.Gauge;
import org.apache.commons.lang3.tuple.Pair;
import sun.misc.SharedSecrets;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class collects following stats related to JVM memory using inbuilt Mbeans.
 * <p>
 * Number of minor or major cycles and spent time since last collection.
 * Direct buffer usages (Native)
 * Heap used and availability
 * <p>
 * Created by sharmra on 28/03/2017.
 */
public class HealthCheckGauge implements Gauge<Pair<String, ?>[]> {
    private static final int MB = 1024 * 1024;
    private static final int GB = 1024 * MB;
    private static final int KPI_LIST_SIZE = 20;

    private Map<String, CollectionGC> memoryMBeans;

    private List<GarbageCollectorMXBean> garbageCollectorMXBeans = ManagementFactory.getGarbageCollectorMXBeans();
    //private OperatingSystemMXBean operatingSystemMXBean = ManagementFactory.getPlatformMXBean(OperatingSystemMXBean.class);
    
    /**
     * To initialise post construction
     */
    public void init() {
        CollectionGC majorGC = null;
        memoryMBeans = new HashMap<>();
        for (final GarbageCollectorMXBean tmpGC : garbageCollectorMXBeans) {
            final CollectionGC collectionGC = new CollectionGC();
            collectionGC.renameKeys(tmpGC.getName());
            // trying to find if memory pool contains Perm string then it uses major/minor name with metrics keys.
            // in case it doesn't find Perm anywhere then it will use GC names as metrics keys.
            if (isMajorCollector(tmpGC.getMemoryPoolNames())) {
                majorGC = collectionGC;
            }
            memoryMBeans.put(tmpGC.getName(), collectionGC);
        }
        if (majorGC != null) {
            renameMetricKeys(majorGC);
        }
    }


    @Override
    public Pair<String, ?>[] getValue() {
        collect();
        List<Pair<String, ?>> listKPIs = new ArrayList<>(KPI_LIST_SIZE);
        //logSystemKPI(listKPIs);
        logCollectionCycles(listKPIs);
        logNativeMemory(listKPIs);

        Pair<String, ?>[] kpiArray = new Pair[listKPIs.size()];
        listKPIs.toArray(kpiArray);
        return kpiArray;
    }

    private void collect() {
        // GC details
        for (final GarbageCollectorMXBean tmpGC : garbageCollectorMXBeans) {
            final CollectionGC lastCollection = memoryMBeans.get(tmpGC.getName());
            lastCollection.update(tmpGC.getCollectionCount(), tmpGC.getCollectionTime());
        }
    }


    private String formatDecimal(double value) {
        return String.format("%.2f", value);
    }

    private void logNativeMemory(List<Pair<String, ?>> listKPIs) {
        long totalMemory = Runtime.getRuntime().totalMemory();
        long freeMemory = Runtime.getRuntime().freeMemory();
        listKPIs.add(Pair.of("Heap.Memory.Used", (totalMemory - freeMemory) / MB + " MB"));
        listKPIs.add(Pair.of("Heap.Memory.Max", totalMemory / MB + " MB"));
        listKPIs.add(Pair.of("Heap.Memory.Free", freeMemory / MB + " MB"));
        listKPIs.add(Pair.of("Native.DFPool.Count", SharedSecrets.getJavaNioAccess().getDirectBufferPool().getCount()));
        listKPIs.add(Pair.of("Native.DFPool.Capacity", SharedSecrets.getJavaNioAccess().getDirectBufferPool().getTotalCapacity() / MB + " MB"));
        listKPIs.add(Pair.of("Native.DFPool.MemoryUsed", SharedSecrets.getJavaNioAccess().getDirectBufferPool().getMemoryUsed() / MB + " MB"));
    }

    private void logCollectionCycles(List<Pair<String, ?>> listKPIs) {
        for (final Map.Entry<String, CollectionGC> collection : memoryMBeans.entrySet()) {
            final CollectionGC lastCollection = collection.getValue();
            listKPIs.add(Pair.of(lastCollection.getCountKey(), lastCollection.getDifferenceOfCount()));
            listKPIs.add(Pair.of(lastCollection.getTimeKey(), lastCollection.getDifferenceOfTime()));
        }
    }


    private void renameMetricKeys(final CollectionGC majorGC) {
        for (final CollectionGC collectionGC : memoryMBeans.values()) {
            String collectionType = "MinorGC";
            if (majorGC == collectionGC) {
                collectionType = "MajorGC";
            }
            collectionGC.renameKeys(collectionType);
        }
    }

    private static boolean isMajorCollector(final String[] pools) {
        for (final String pool : pools) {
            if (pool.contains("Perm") || !pool.contains("New")) {
                return true;
            }
        }
        return false;
    }

    public static class CollectionGC {
        private String timeKey;
        private String countKey;

        private long lastGCCount;
        private long lastGCTime;

        private long differenceOfTime;
        private long differenceOfCount;

        private void renameKeys(final String aName) {
            countKey = aName + ".Count";
            timeKey = aName + ".Time";
        }

        private void update(final long nowCount, final long nowTime) {
            if (lastGCCount == nowCount) {
                // it mean no change
                differenceOfTime = 0;
                differenceOfCount = 0;
            } else {
                differenceOfTime = nowTime - lastGCTime;
                differenceOfCount = nowCount - lastGCCount;
                lastGCCount = nowCount;
                lastGCTime = nowTime;
            }
        }

        private String getTimeKey() {
            return timeKey;
        }

        private String getCountKey() {
            return countKey;
        }

        private long getDifferenceOfTime() {
            return differenceOfTime;
        }

        private long getDifferenceOfCount() {
            return differenceOfCount;
        }

    }
}
