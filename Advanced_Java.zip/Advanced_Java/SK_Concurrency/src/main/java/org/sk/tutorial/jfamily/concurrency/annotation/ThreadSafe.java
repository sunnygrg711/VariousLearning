package org.sk.tutorial.jfamily.concurrency.annotation;


public @interface ThreadSafe {
}
