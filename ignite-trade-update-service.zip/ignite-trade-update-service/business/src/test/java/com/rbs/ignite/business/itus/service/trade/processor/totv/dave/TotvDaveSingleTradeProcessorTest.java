package com.rbs.ignite.business.itus.service.trade.processor.totv.dave;

import com.rbs.gbm.rates.core.auth.security.SsoTokenProviderService;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.dave.ResponseDto;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveRequest;
import com.rbs.ignite.domain.itus.trade.totv.dave.TotvDaveResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;


@RunWith(MockitoJUnitRunner.class)
public class TotvDaveSingleTradeProcessorTest {

  @InjectMocks
  private TotvDaveSingleTradeProcessor testObj = new TotvDaveSingleTradeProcessor("url", TotvDaveResponse.class, Mockito.mock(SsoTokenProviderService.class));
  @Mock
  private ItusTransformer totvTradeToDaveReqTransformer;

  @Mock
  private RestTemplate restTemplate;
  @Mock
  private TotvTrade totvTrade;
  private TotvDaveRequest tradeInput;

  private TotvDaveResponse totvSuccessDaveResponse;
  private TotvDaveResponse totvFailedDaveResponse;
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    String[] informationData = new String[]{"Info-1", "Info-2"};
    totvSuccessDaveResponse = new TotvDaveResponse();
    totvSuccessDaveResponse.setResponseDto(new ResponseDto());
    totvSuccessDaveResponse.getResponseDto().setCode(0);
    totvSuccessDaveResponse.getResponseDto().setInformation(informationData);
    totvFailedDaveResponse = new TotvDaveResponse();
    totvFailedDaveResponse.setResponseDto(new ResponseDto());
    totvFailedDaveResponse.getResponseDto().setCode(1);
    com.rbs.ignite.domain.itus.trade.totv.dave.Exception exception = new com.rbs.ignite.domain.itus.trade.totv.dave.Exception();
    exception.setMessage("not a valid trade");
    totvFailedDaveResponse.getResponseDto().setExceptions(new com.rbs.ignite.domain.itus.trade.totv.dave.Exception[]{exception});

  }

  @Test
  public void testProcessTrade() throws Exception {
    Mockito.when(totvTradeToDaveReqTransformer.transform(Mockito.any(TotvTrade.class))).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(totvSuccessDaveResponse);
    status = testObj.processTrade(totvTrade);
    assertEquals("0", status.getServiceResponseCode());
    assertEquals("ACCEPTED", status.getStatus().name());

    Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(totvFailedDaveResponse);
    status = testObj.processTrade(totvTrade);
    assertEquals("1", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }

  @Test
  public void testProcessTradeException() throws Exception {
    Mockito.when(totvTradeToDaveReqTransformer.transform(Mockito.any(TotvTrade.class))).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    Mockito.doThrow(Exception.class).when(restTemplate).postForObject(Mockito.anyString(), Mockito.any(), Mockito.any());
    status = testObj.processTrade(totvTrade);
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());

  }

  @Test
  public void testProcessTradeWhenNullResponse() throws Exception {
    Mockito.when(totvTradeToDaveReqTransformer.transform(Mockito.any(TotvTrade.class))).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(null);
    status = testObj.processTrade(totvTrade);
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());

  }

  @After
  public void tearDown() {
    testObj = null;
  }

}
