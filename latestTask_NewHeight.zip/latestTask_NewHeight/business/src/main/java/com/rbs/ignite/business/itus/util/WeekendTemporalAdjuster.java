package com.rbs.ignite.business.itus.util;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;

public class WeekendTemporalAdjuster implements TemporalAdjuster {
  private int days;
  private DateDirection direction;

  public WeekendTemporalAdjuster(int days, DateDirection direction) {
    this.days = days;
    this.direction = direction;
  }

  @Override
  public Temporal adjustInto(Temporal temporal) {
    LocalDateTime targetDate;
    if(DateDirection.BACKWARD.equals(direction)) {
      targetDate = subtractBusinessDays(days, temporal);
    }else{
      targetDate = addBusinessDays(days, temporal);
    }
    return targetDate;
  }

  public static LocalDateTime addBusinessDays(int days, Temporal temporal) {
    LocalDateTime targetDate;
    LocalDateTime currentDateTime = LocalDateTime.from(temporal);
    if (currentDateTime.getDayOfWeek().equals(DayOfWeek.SATURDAY) || currentDateTime.getDayOfWeek().equals(DayOfWeek.SUNDAY)){
      currentDateTime = currentDateTime.plusDays(1);
    }
    targetDate = LocalDateTime.from(temporal).plus(days,
      ChronoUnit.DAYS);
    // loop through date range checking if the date
    // is Saturday or Sunday.
    // if it is, add one day to account for the business day
    for (LocalDateTime startDate = currentDateTime; startDate.isEqual(targetDate) || startDate
      .isBefore(targetDate); startDate = startDate.plusDays(1)) {

      if (startDate.getDayOfWeek().equals(DayOfWeek.SATURDAY) || startDate.getDayOfWeek().equals(DayOfWeek.SUNDAY)) {
        targetDate = targetDate.plusDays(1);
      }
    }
    return targetDate;
  }

  public static LocalDateTime subtractBusinessDays(int days, Temporal temporal) {
    LocalDateTime targetDate;
    LocalDateTime currentDateTime = LocalDateTime.from(temporal);
    if (currentDateTime.getDayOfWeek().equals(DayOfWeek.SATURDAY) || currentDateTime.getDayOfWeek().equals(DayOfWeek.SUNDAY)){
      currentDateTime = currentDateTime.minusDays(1);
    }
    targetDate = LocalDateTime.from(temporal).minus(days,
      ChronoUnit.DAYS);
    // loop through date range checking if the date
    // is Saturday or Sunday.
    // if it is, subtract one day to account for the business day
    for (LocalDateTime startDate = currentDateTime; startDate.isEqual(targetDate) || startDate
      .isAfter(targetDate); startDate = startDate.minusDays(1)) {

      if (startDate.getDayOfWeek().equals(DayOfWeek.SATURDAY) || startDate.getDayOfWeek().equals(DayOfWeek.SUNDAY)) {
        targetDate = targetDate.minusDays(1);
      }
    }
    return targetDate;
  }

  public static enum DateDirection {
    FORWARD("FORWARD"), BACKWARD("BACKWARD");

    private String name;

    DateDirection(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }

    @Override
    public String toString() {
      return "DateDirection{" +
        "name='" + name + '\'' +
        '}';
    }
  }
}
