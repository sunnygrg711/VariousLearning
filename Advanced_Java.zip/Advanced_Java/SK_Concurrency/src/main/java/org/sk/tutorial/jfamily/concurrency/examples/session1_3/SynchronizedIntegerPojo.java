package org.sk.tutorial.jfamily.concurrency.examples.session1_3;

import org.sk.tutorial.jfamily.concurrency.annotation.GuardedBy;
import org.sk.tutorial.jfamily.concurrency.annotation.NotThreadSafe;
import org.sk.tutorial.jfamily.concurrency.annotation.ThreadSafe;

/**
 * Created by kshekar on 23/04/2018.
 */
@ThreadSafe
public class SynchronizedIntegerPojo {

    @GuardedBy(name = "This")
    private int value;

    public synchronized int getValue() {
        return value;
    }

    public synchronized void setValue(int value) {
        this.value = value;
    }
}
