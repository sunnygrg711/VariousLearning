package com.rbs.ignite.domain.itus.instrument.totv;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.Maps;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TotvResponse {

  private String statusCode;
  private String statusMessage;
  private Integer totalCount;
  private Map<ItusTradeSourceSystem, SystemSpecificResponse> result;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvResponse that = (TotvResponse) o;

    if (!statusCode.equals(that.statusCode)) return false;
    if (!statusMessage.equals(that.statusMessage)) return false;
    if (!totalCount.equals(that.totalCount)) return false;
    return result.equals(that.result);

  }

  @Override
  public int hashCode() {
    int result1 = statusCode.hashCode();
    result1 = 31 * result1 + statusMessage.hashCode();
    result1 = 31 * result1 + totalCount.hashCode();
    result1 = 31 * result1 + result.hashCode();
    return result1;
  }

  public String getStatusCode() {
    return statusCode;
  }

  public String getStatusMessage() {
    return statusMessage;
  }

  public Integer getTotalCount() {
    return totalCount;
  }

  public Map<ItusTradeSourceSystem, SystemSpecificResponse> getResult() {
    return result;
  }

  public TotvResponse(@JsonProperty("statusCode") String statusCode,
                      @JsonProperty("statusMessage") String statusMessage,
                      @JsonProperty("total") Integer totalCount,
                      @JsonProperty("result") Map<ItusTradeSourceSystem, SystemSpecificResponse> result) {
    this.statusCode = statusCode;
    this.statusMessage = statusMessage;
    this.totalCount = totalCount;
    this.result = result;
  }

  public static class SystemSpecificResponse {
    Map<ItusStatus, List<String>> statusWiseTradeIdentifiers;

    public SystemSpecificResponse() {
      this.statusWiseTradeIdentifiers = Maps.newHashMap();
    }

    public SystemSpecificResponse(Map<ItusStatus, List<String>> result) {
      this.statusWiseTradeIdentifiers = result;
    }

    public Map<ItusStatus, List<String>> getTradeIdentifiers() {
      return statusWiseTradeIdentifiers;
    }

    public List<String> getTradeIdentifiersForStatus(ItusStatus status) {
      return statusWiseTradeIdentifiers.get(status);
    }

    public Integer getAcceptedCount() {
      return getTradeIdentifiersForStatus(ItusStatus.ACCEPTED) != null ? getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).size():0;
    }

    public Integer getRejectedCount() {
      return getTradeIdentifiersForStatus(ItusStatus.REJECTED) != null ? getTradeIdentifiersForStatus(ItusStatus.REJECTED).size():0;
    }

    public Integer getAmendSkippedCount() {
      return getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED) != null ? getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED).size():0;
    }

    public Integer getThresholdReachedCount() {
      return getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED) != null ? getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED).size():0;
    }

    @Override
    public String toString() {
      return "SystemSpecificResponse{"+
        " totalAccepted="+(getTradeIdentifiersForStatus(ItusStatus.ACCEPTED) != null ?
        getTradeIdentifiersForStatus(ItusStatus.ACCEPTED).size():"0")+
        ", totalRejected="+(getTradeIdentifiersForStatus(ItusStatus.REJECTED) != null ?
        getTradeIdentifiersForStatus(ItusStatus.REJECTED).size():"0")+
        ", totalSkipped="+(getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED) != null ?
        getTradeIdentifiersForStatus(ItusStatus.TRADE_AMEND_SKIPPED).size():"0")+
        ", totalThresholdReached="+(getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED) != null ?
        getTradeIdentifiersForStatus(ItusStatus.THRESHOLD_BREACHED).size():"0")+
        ", TradeIdentifiers="+statusWiseTradeIdentifiers+'}';
    }
  }
}
