package org.sk.tutorial.jfamily.concurrency.locks;

/**
 * Created by kshekar on 22/03/2018.
 */
public interface Transferable {

    /**
     * Transfers money from one account to another.
     * @param fromBankAccountId the account to transfer from
     * @param toBankAccountId the account to transfer to
     * @param amount the amount to transfer
     * @throws InterruptedException
     */
      void transfer(int fromBankAccountId, int toBankAccountId, double amount) throws InterruptedException;
}
