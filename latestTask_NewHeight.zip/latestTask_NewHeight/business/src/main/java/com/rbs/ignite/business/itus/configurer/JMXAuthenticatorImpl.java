package com.rbs.ignite.business.itus.configurer;

import com.google.common.collect.ImmutableSet;
import com.rbs.rates.foundation.security.SecurityProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import javax.management.remote.JMXAuthenticator;
import javax.management.remote.JMXPrincipal;
import javax.security.auth.Subject;
import java.util.Set;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.rbs.ignite.business.itus.util.CommonConstantsUtil.WRITE_ROLE_NAME;
import static com.rbs.ignite.business.itus.util.SecurityUtil.toRoleNames;

public class JMXAuthenticatorImpl implements JMXAuthenticator {

  private static final Logger logger = LoggerFactory.getLogger(JMXAuthenticatorImpl.class);
  private static final int USER = 0;
  private static final int PASSWORD = 1;

  private final SecurityProvider securityProvider;

  public JMXAuthenticatorImpl(SecurityProvider securityProvider) {
    this.securityProvider = securityProvider;
  }

  @Override
  public Subject authenticate(Object credentials) {
    String[] credentialsTokens = validateCredentials(credentials);

    final String username = credentialsTokens[USER];
    final String password = credentialsTokens[PASSWORD];

    try {
      Authentication authentication = securityProvider.authenticate(new UsernamePasswordAuthenticationToken(username, password));

      Subject subject = createSubject(username, toRoleNames(authentication.getAuthorities()));
      logger.info("JMX authentication successful for user: {}", username);
      return subject;
    } catch (Exception e) {
      logger.info("JMX authentication failed for user: {} with message: {}", username, e.getMessage());
      throw new SecurityException(e.getMessage(), e);
    }
  }

  private String[] validateCredentials(Object credentials) {
    try {
      checkNotNull(credentials,
          "You must supply credentials in the form of a String[] with the first element being the username and the second element being the password!");
      checkArgument(credentials instanceof String[], "Invalid statement of credentials, they must be supplied as a String[]!");
      return (String[]) credentials;
    } catch (Exception e) {
      throw new SecurityException(e.getMessage(), e);
    }
  }

  private Subject createSubject(String username, Set<String> roleNames) {
    boolean readOnly = !roleNames.contains(WRITE_ROLE_NAME);

    Subject subject = new Subject(readOnly, ImmutableSet.of(new JMXPrincipal(username)), ImmutableSet.of(), ImmutableSet.of());

    logger.debug("Created subject for JMX authentication: {}", subject);

    return subject;
  }
}