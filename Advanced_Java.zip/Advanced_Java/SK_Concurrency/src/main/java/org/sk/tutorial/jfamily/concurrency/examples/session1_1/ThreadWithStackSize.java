package org.sk.tutorial.jfamily.concurrency.examples.session1_1;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Created by kshekar on 07/05/2018.
 */
public class ThreadWithStackSize {

    static void recursion(){
        System.out.println(Thread.currentThread()+"Date:"+new Date());
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        recursion();

    }
    public static void main(String[] args) {
        ThreadGroup threadGroup=new ThreadGroup("MyThreadGroup");
        Thread myThread=new Thread(threadGroup,() -> recursion(),"MyThread",0);
        myThread.start();
    }
}
