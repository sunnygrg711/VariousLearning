package org.sk.tutorial.jfamily.concurrency.examples.session2_2;

import org.sk.tutorial.jfamily.concurrency.annotation.ThreadSafe;

import java.util.concurrent.atomic.AtomicBoolean;

@ThreadSafe
class MySimpleLockWithAtomic {
    private AtomicBoolean locked = new AtomicBoolean(false);

    public boolean lock() {
        return locked.compareAndSet(false, true);
    }
}