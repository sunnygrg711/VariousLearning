package com.rbs.ignite.business.itus.mgmt;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;


/**
 * Created by kumaunn on 31/03/2018.
 */

@RunWith(SpringJUnit4ClassRunner.class)
public class DaveHealthIndicatorTest {

  @InjectMocks
  private DaveHealthIndicator healthIndicator;

  @Mock RestTemplate restTemplate;

  @Mock ResponseEntity responseEntity;

  @Before
  public void setup() {
    Mockito.when(restTemplate.getForEntity(Mockito.anyString(), Mockito.any())).thenReturn(responseEntity);
    Mockito.when(responseEntity.getStatusCode()).thenReturn(HttpStatus.NOT_FOUND);

  }

  @Test
  public void testDoHealthCheck() throws Exception{
    Health.Builder build = new Health.Builder(Status.DOWN);
    healthIndicator.doHealthCheck(build);
    Health health = build.build();
    Assert.assertEquals(Status.DOWN, health.getStatus());
  }
}
