package org.sk.tutorial.jfamily.devopsutility.model;

/**
 * Created by kshekar on 03/04/2018.
 */
public class ClassesInfo {
    private int currentLoaded;
    private long totalLoaded;
    private long unloaded;

    public int getCurrentLoaded() {
        return currentLoaded;
    }

    public void setCurrentLoaded(int currentLoaded) {
        this.currentLoaded = currentLoaded;
    }

    public long getTotalLoaded() {
        return totalLoaded;
    }

    public void setTotalLoaded(long totalLoaded) {
        this.totalLoaded = totalLoaded;
    }

    public long getUnloaded() {
        return unloaded;
    }

    public void setUnloaded(long unloaded) {
        this.unloaded = unloaded;
    }
}
