package com.rbs.ignite.domain.itus.trade.totv;


import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;


public class TotvTradeStatus implements ItusTradeStatus {
  private TotvTrade trade;
  private ItusStatus status;
  private String responseCode;
  private String message;
  private String exceptions;


  private TotvTradeStatus(TotvTradeStatusBuilder builder) {
    this.trade = builder.trade;
    this.status = builder.status;
    this.responseCode = builder.responseCode;
    this.message = builder.message;
    this.exceptions = builder.exceptions;
  }

  @Override
  public ItusTrade getTrade() {
    return trade;
  }

  @Override
  public ItusStatus getStatus() {
    return status;
  }

  @Override
  public String getServiceResponseCode() {
    return responseCode;
  }

  @Override
  public String getServiceResponseMessage() {
    return message;
  }

  @Override
  public String getServiceExceptionMessage() {
    return exceptions;
  }
  public static class TotvTradeStatusBuilder {
    private TotvTrade trade;
    private ItusStatus status;
    private String responseCode;
    private String message;
    private String exceptions;

    public TotvTradeStatusBuilder(TotvTrade trade, ItusStatus status, String serviceResponseCode) {
      this.responseCode = serviceResponseCode;
      this.status = status;
      this.trade = trade;
    }

    public TotvTradeStatusBuilder exceptions(String exceptions) {
      this.exceptions = exceptions;
      return this;
    }

    public TotvTradeStatusBuilder message(String message) {
      this.message = message;
      return this;
    }

    public TotvTradeStatus build() {
      return new TotvTradeStatus(this);
    }
  }

  @Override
  public String toString() {
    return "TotvTradeStatus{" +
            "trade=" + trade +
            ", status=" + status +
            ", responseCode='" + responseCode + '\'' +
            ", message='" + message + '\'' +
            ", exceptions='" + exceptions + '\'' +
            '}';
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvTradeStatus that = (TotvTradeStatus) o;

    if (trade != null ? !trade.equals(that.trade) : that.trade != null) return false;
    if (status != that.status) return false;
    if (responseCode != null ? !responseCode.equals(that.responseCode) : that.responseCode != null) return false;
    if (message != null ? !message.equals(that.message) : that.message != null) return false;
    return exceptions != null ? exceptions.equals(that.exceptions) : that.exceptions == null;
  }

  @Override
  public int hashCode() {
    int result = trade != null ? trade.hashCode() : 0;
    result = 31 * result + (status != null ? status.hashCode() : 0);
    result = 31 * result + (responseCode != null ? responseCode.hashCode() : 0);
    result = 31 * result + (message != null ? message.hashCode() : 0);
    result = 31 * result + (exceptions != null ? exceptions.hashCode() : 0);
    return result;
  }
}