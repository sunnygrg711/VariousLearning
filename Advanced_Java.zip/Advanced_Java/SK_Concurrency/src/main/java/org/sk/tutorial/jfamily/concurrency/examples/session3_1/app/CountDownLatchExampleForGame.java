package org.sk.tutorial.jfamily.concurrency.examples.session3_1.app;

import org.sk.tutorial.jfamily.concurrency.examples.session3_1.GameRunner;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class CountDownLatchExampleForGame {

    public static void main(String[] args) throws InterruptedException {
        CountDownLatch timer = new CountDownLatch(5);

        List<GameRunner> runners = Arrays.asList(
                new GameRunner("Tom", timer),
                new GameRunner("Stephen", timer),
                new GameRunner("James", timer),
                new GameRunner("Ram", timer),
                new GameRunner("Bolt", timer),
                new GameRunner("Jack", timer),
                new GameRunner("Jill", timer),
                new GameRunner("Gaurav", timer),
                new GameRunner("Shaurav", timer));
        runners.parallelStream().forEach(gameRunner -> gameRunner.start());
        long countVal = timer.getCount();
        while (countVal > 0) {
            TimeUnit.SECONDS.sleep(1);
            System.out.println(countVal);
            if (countVal == 1) {
                System.out.println("Start");
            }
            timer.countDown();
            countVal = timer.getCount();
        }
    }
}
