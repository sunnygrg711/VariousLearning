package com.rbs.ignite.domain.itus.trade.totv;



import com.rbs.ignite.domain.itus.trade.ItusTradeHolder;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import java.util.Collections;
import java.util.Set;

public class TotvTradeHolder implements ItusTradeHolder {

    private ItusTradeSourceSystem tradeSourceSystem;

    private Set<TotvTrade> tradeSet;

    @Override
    public ItusTradeSourceSystem getTradeSourceSystem() {
        return tradeSourceSystem;
    }

    @Override
    public Set<TotvTrade> getTradeSet() {
        return tradeSet;
    }

    public TotvTradeHolder(ItusTradeSourceSystem tradeSourceSystem, Set<TotvTrade> tradeSet) {
        this.tradeSourceSystem = tradeSourceSystem;
        this.tradeSet = Collections.unmodifiableSet(tradeSet);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TotvTradeHolder)) return false;

        TotvTradeHolder that = (TotvTradeHolder) o;

        if (tradeSourceSystem != that.tradeSourceSystem) return false;
        return tradeSet.equals(that.tradeSet);
    }

    @Override
    public int hashCode() {
        int result = tradeSourceSystem.hashCode();
        result = 31 * result + tradeSet.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "TotvTradeHolder{" +
                "tradeSourceSystem=" + tradeSourceSystem +
                ", tradeSet=" + tradeSet +
                '}';
    }
}
