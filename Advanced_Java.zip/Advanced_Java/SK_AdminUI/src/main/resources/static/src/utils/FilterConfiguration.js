define([

        'd3',
        'text!./FilterConfiguration.html',
        'mediator-js'

    ], function(
        d3,
        filterConfigurationTmpl
    ){

        /*
            This method is reponsible to show a modal popup
            for filter configuration
        */
        function FilterConfiguration(scope){
            Mediator.call(this);

            $('body').append(filterConfigurationTmpl);
            this.$scope = scope;
           var filters = scope.genericData.filters;   // STR Filters

            appendFilters(filters);

            chooseFilter();

            sortFilter();

            // A simple method to close the modal on click of any element with [data-dismiss] attribute
            $('[data-dismiss]').on('click', function(e){
                e.preventDefault();
                closeModal($(this));
            });

            // This method will re-init the grid with original data ignoring all users configuration
            $('.column-chooser-reset').on('click', function(){
                filters = this.$scope.genericData.resetFilters;
                appendFilters(filters);
            }.bind(this));

            this.updateScope();

        }

        FilterConfiguration.prototype = Object.create(Mediator.prototype);

        FilterConfiguration.prototype.constructor = FilterConfiguration;

        FilterConfiguration.prototype.updateScope = function(){
            $('.updateData').on('click', function(){
                var updatedFilters = {
                    "visibleFilters" : {

                    },
                    "hiddenFilters" : {

                    }
                };
                updatedFilters.hiddenFilters = getUpdatedObject('.column-chooser-additional li');
                updatedFilters.visibleFilters = getUpdatedObject('.column-chooser-visible li');
                closeModal($('.updateData'));
                this.publish('updatedFilters', updatedFilters);
                this.$scope.safeApply(function() {
                     this.$scope.genericData.showFilters.bool = true;
                }.bind(this));


            }.bind(this));
        };

        // Simply removing the modal from DOM
        function closeModal(e){
            e.parents('.modal-alt').remove();
        }

        // This method is appending the HTML in DOM
        function appendFilters(filters){

            var filterConfigurationWrapper =  $('#filterConfiguration');
            filterConfigurationWrapper.find('.column-chooser-additional-count').text(Object.keys(filters.hiddenFilters).length);
            filterConfigurationWrapper.find('.column-chooser-visible-count').text(Object.keys(filters.visibleFilters).length);
            filterConfigurationWrapper.find('.column-chooser-additional').html(generateFilters(filters.hiddenFilters));
            filterConfigurationWrapper.find('.column-chooser-visible').html(generateFilters(filters.visibleFilters));
        }

        // This method is construcing the filters DOM by looping through the object
        function generateFilters(filter){
            var returnNodes = '';

            for (var i in filter){
                returnNodes = returnNodes+'<li class="platform-list-item"><p class="label-or-id" data-id="'+i+'">'+filter[i]+'</p></li>';
            }

            return returnNodes;
        }

        // This method is used to select/deselect the filters on users action
        function chooseFilter(){
            $('.platform-list').on('click', 'li', function(e){
                var elem = $(this);
                if(e.ctrlKey !== true){
                    elem.parents().find('li').removeClass('is-selected');
                }
                elem.addClass('is-selected');

                // This method allows to enable and disable buttons like moving/sorting the filters
                disableEnableButtons();

            });

            $('.column-chooser-show-selected').on('click', function(){
                var parentElem = $(this).parents('.modal-body');
                // this is responsible to move filters from additional to visible group
                moveFilter(parentElem.find('.column-chooser-additional li'), parentElem.find('.column-chooser-visible'));
            });

            $('.column-chooser-hide-selected').on('click', function(){
                var parentElem = $(this).parents('.modal-body');
                // this is responsible to move filters from visible to additional group
                moveFilter(parentElem.find('.column-chooser-visible li'), parentElem.find('.column-chooser-additional'));
            });
        }

        function disableEnableButtons(wrapper, button){

            var hideButton = $('.column-chooser-hide-selected'),
                showButton = $('.column-chooser-show-selected'),
                sortButtons = $('.column-chooser-sort-buttons button'),
                visibleSelected = $('.column-chooser-visible li.is-selected').length;

            if($('.column-chooser-additional li.is-selected').length > 0){
                hideButton.prop('disabled', true);
            }else{
                hideButton.prop('disabled', false);
            }

            /*
                This condition is checking whether any item is selected then enable the
                move button else disable it and also checking whether exactly one item is selected then
                enable the sort button else disable it
            */
            if(visibleSelected > 0){
                showButton.prop('disabled', true);
                if(visibleSelected === 1){
                    sortButtons.prop('disabled', false);
                }else{
                    sortButtons.prop('disabled', true);
                }
            }else{
                showButton.prop('disabled', false);
                sortButtons.prop('disabled', true);
            }

        }

        // This method is used to move selected elements to visible or additional filters bucket
        function moveFilter(elem, arrayToMove){
            var addToFilter = '',
                filterConfigurationWrapper =  $('#filterConfiguration');
            elem.each(function(){
                var elem = $(this);
                if(elem.hasClass('is-selected')){
                    addToFilter = addToFilter+'<li class="platform-list-item">'+elem.html()+'</li>';
                    elem.remove();
                }
            });
            arrayToMove.append(addToFilter);
            filterConfigurationWrapper.find('.column-chooser-additional-count').text(filterConfigurationWrapper.find('.column-chooser-additional li').length);
            filterConfigurationWrapper.find('.column-chooser-visible-count').text(filterConfigurationWrapper.find('.column-chooser-visible li').length);
            $('.column-chooser-show-hide-buttons button').prop('disabled', true);

        }

        // This method is used to move filters up and down in visible filters bucket
        function sortFilter(){

            $('.column-chooser-sort-buttons').on('click', 'button', function(){
                var elem = $(this),
                    selectedObj = $('.column-chooser-visible li.is-selected');
                if(elem.hasClass('column-chooser-move-before')){
                    if(selectedObj.index() > 0){
                        selectedObj.insertBefore(selectedObj.prev());
                    }else{
                        selectedObj.insertAfter($('.column-chooser-visible li:last'));
                    }
                }else{
                    if(selectedObj.index() === $('.column-chooser-visible li').length-1){
                        selectedObj.insertBefore($('.column-chooser-visible li:first'));
                    }else{
                        selectedObj.insertAfter(selectedObj.next());
                    }
                }
            });

        }

        function updateScope(scope){

            $('.updateData').on('click', function(){
                var updatedFilters = {
                    "visibleFilters" : {

                    },
                    "hiddenFilters" : {

                    }
                };
                updatedFilters.hiddenFilters = getUpdatedObject('.column-chooser-additional li');
                updatedFilters.visibleFilters = getUpdatedObject('.column-chooser-visible li');
                closeModal($(this));
                scope.filters = updatedFilters;

            }.bind(this));

        }

        function getUpdatedObject(objectToLoop){

            var objToAppend = {};

            $(objectToLoop).each(function(){
                var elem = $(this).find('p');

                objToAppend[elem.data('id')] = elem.text();
            });
            return objToAppend;

        }
        return FilterConfiguration;
    });
