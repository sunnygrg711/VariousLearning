package com.rbs.ignite.domain.itus.instrument;

import java.time.LocalDate;

public interface ItusInstrumentDateInput extends ItusInstrumentInput {
    LocalDate getDate();
}
