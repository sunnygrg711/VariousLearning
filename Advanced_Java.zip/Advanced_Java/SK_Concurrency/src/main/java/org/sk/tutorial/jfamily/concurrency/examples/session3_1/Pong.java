package org.sk.tutorial.jfamily.concurrency.examples.session3_1;

import java.util.concurrent.Exchanger;
import java.util.concurrent.TimeUnit;

public class Pong implements Runnable {

    private Exchanger<String> exchanger;

    public Pong(Exchanger<String> exchanger) {
        this.exchanger = exchanger;
    }

    @Override
    public void run() {
        try {
            int counter=5;
            while (--counter>0) {
                TimeUnit.MILLISECONDS.sleep(1000);
                System.out.println(Thread.currentThread().getName() + "::" + exchanger.exchange("Pong-"+counter));

            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
