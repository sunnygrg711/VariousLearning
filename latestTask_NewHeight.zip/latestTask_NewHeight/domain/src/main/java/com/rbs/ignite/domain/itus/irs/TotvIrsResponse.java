package com.rbs.ignite.domain.itus.irs;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TotvIrsResponse {

  private final Set<TotvIrsInstrumentIdentifier> isins;
  private List<String> errors;

  public TotvIrsResponse(@JsonProperty("identifiers") Set<TotvIrsInstrumentIdentifier> isins
          , @JsonProperty("exceptionMessages") List<String> exceptionMessages) {
    this.isins = isins;
    this.errors= exceptionMessages;
  }
  public Set<TotvIrsInstrumentIdentifier> getIsins() {
    return isins;
  }

  public List<String> getErrors() {
    return errors;
  }
  @Override
  public String toString() {
    return "TotvIrsResponse{" +
            "isins=" + isins +
            ", errors=" + errors +
            '}';
  }
}
