package com.rbs.ignite.business.itus.service.trade.processor.totv.dave;

import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTask;
import com.rbs.ignite.api.itus.service.trade.task.ItusTradeTaskCallable;
import com.rbs.ignite.business.itus.jmx.TotvJmxProvider;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.totv.OdcTradeRetrievalService;
import com.rbs.ignite.business.itus.service.trade.task.totv.TotvTradeTask;
import com.rbs.ignite.business.itus.totv.TotvStarter;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import com.rbs.ignite.business.itus.util.configurer.totv.TotvTestConfigurer;
import com.rbs.ignite.domain.itus.exception.ItusFatalErrorException;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeHolder;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatusHolder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(classes = { TotvStarter.class, TotvTestConfigurer.class })
public class TotvDaveTradeProcessorTest {

  @InjectMocks
  private TotvDaveTradeProcessor daveTradeProcessorObj = new TotvDaveTradeProcessor(Executors.newWorkStealingPool(), Mockito.mock(TotvDaveSingleTradeProcessor.class));
  @Mock
  private Future<ItusTradeStatus> future;
  @Mock
  private ApplicationContext context;
  @Mock
  private TotvDaveSingleTradeProcessor totvDaveSingleTradeProcessor;
  @Mock
  private TotvJmxProvider totvJmxProvider;

  private TotvTradeHolder tradeHolder;
  private TotvTrade vaildTrade;
  private Set tradeSet = new HashSet<TotvTrade>();

  @Before
  public void setup(){
    MockitoAnnotations.initMocks(this);
    vaildTrade = new TotvTrade("US75405RAA14", "113092118", ItusTradeSourceSystem.DAVE, "GDSLDN");
    tradeSet.add(vaildTrade);
    tradeHolder = new TotvTradeHolder(ItusTradeSourceSystem.DAVE, tradeSet);
  }

  @Test
  public void testProcessTrade() throws Exception {
    ItusTradeTask itusTradeTask = new TotvTradeTask(vaildTrade, totvDaveSingleTradeProcessor, Long.valueOf(1),"<EMPTY>");
    Mockito.when(context.getBean(Mockito.eq("itusTradeTask"), Mockito.anyObject(), Mockito.anyObject(), Mockito.anyObject(),Mockito.anyObject())).thenReturn(itusTradeTask);
    TotvTradeStatus status = new TotvTradeStatus.TotvTradeStatusBuilder(vaildTrade, ItusStatus.ACCEPTED, "0").build();
    ItusTradeTaskCallable callable = new ItusTradeTaskCallable(itusTradeTask,"<EMPTY>");
    Mockito.when(context.getBean(Mockito.eq("itusTradeTaskCallable"), Mockito.any(TotvTradeTask.class),Mockito.anyObject())).thenReturn(callable);
    Mockito.when(totvJmxProvider.getDaveThresholdLimit()).thenReturn((long) 200);
    Mockito.when(totvDaveSingleTradeProcessor.processTrade(Mockito.any(TotvTrade.class),Mockito.anyObject())).thenReturn(status);
    TotvTradeStatusHolder tradeStatusHolder = daveTradeProcessorObj.processTrades(tradeHolder,"<EMPTY>", true);
    assertEquals("DAVE", tradeStatusHolder.getTradeSourceSystem().getName());
    assertEquals(1, tradeStatusHolder.getTradeStatusSet().size());
  }

  @Test
  public void testProcessTradeWhenLimitBreached() throws Exception {
    ItusTradeTask itusTradeTask = new TotvTradeTask(vaildTrade, totvDaveSingleTradeProcessor, Long.valueOf(1),"<EMPTY>");
    Mockito.when(context.getBean(Mockito.eq("itusTradeTask"), Mockito.anyObject(), Mockito.anyObject(), Mockito.anyObject(),Mockito.anyObject())).thenReturn(itusTradeTask);
    TotvTradeStatus status = new TotvTradeStatus.TotvTradeStatusBuilder(vaildTrade, ItusStatus.THRESHOLD_BREACHED, "-1").build();
    ItusTradeTaskCallable callable = new ItusTradeTaskCallable(itusTradeTask,"<EMPTY>");
    Mockito.when(context.getBean(Mockito.eq("itusTradeTaskCallable"), Mockito.any(TotvTradeTask.class),Mockito.anyObject())).thenReturn(callable);
    Mockito.when(totvJmxProvider.getDaveThresholdLimit()).thenReturn((long) 0);
    TotvTradeStatusHolder tradeStatusHolder = daveTradeProcessorObj.processTrades(tradeHolder,"<EMPTY>", false);
    assertEquals("DAVE", tradeStatusHolder.getTradeSourceSystem().getName());
    assertEquals(1, tradeStatusHolder.getTradeStatusSet().size());
    assertTrue( tradeStatusHolder.getTradeStatusSet().contains(status));
  }

  @Test(expected = ItusFatalErrorException.class)
  public void testProcessTradeWhenException() throws Exception {

    tradeHolder = new TotvTradeHolder(ItusTradeSourceSystem.GFX, tradeSet);
    daveTradeProcessorObj.processTrades(tradeHolder,"<EMPTY>", false);
  }

  @Test
  public void testEmptyProcessTrade() throws Exception {
    tradeHolder= new TotvTradeHolder(ItusTradeSourceSystem.DAVE,new HashSet<>());
    TotvTradeStatusHolder tradeStatusHolder = daveTradeProcessorObj.processTrades(tradeHolder,"<EMPTY>", true);
    assertEquals(0,tradeStatusHolder.getTradeStatusSet().size());
  }
}
