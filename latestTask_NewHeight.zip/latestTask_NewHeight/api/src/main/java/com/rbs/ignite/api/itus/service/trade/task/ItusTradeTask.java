package com.rbs.ignite.api.itus.service.trade.task;


import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.ItusTrade;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;

/**
 * Created by puronaa on 29/09/2017.
 */
public interface ItusTradeTask<Trade extends ItusTrade, TradeStatus extends ItusTradeStatus> {
    TradeStatus execute() throws ItusException;
    Trade getTrade();
}
