package com.rbs.ignite.api.itus.service.trade.retrieval.query;

import java.time.LocalDate;
import java.util.Set;

/**
 * Created by upadkti on 08/12/2017.
 */
public interface ItusTradeQueryExecutor<T> {
  Set<T> executeQuery(Set<String> isins, LocalDate businessDate);
}