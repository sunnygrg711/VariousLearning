package com.rbs.ignite.business.itus.service.trade.totv;

import com.google.common.collect.Sets;
import com.google.common.util.concurrent.Futures;
import com.rbs.ignite.api.itus.service.instrument.ItusInstrumentService;
import com.rbs.ignite.api.itus.service.trade.processor.ItusTradeProcessingService;
import com.rbs.ignite.api.itus.service.trade.retrieval.ItusTradeRetrievalService;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.instrument.ItusInstrumentInput;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentData;
import com.rbs.ignite.domain.itus.instrument.totv.TotvInstrumentInput;
import com.rbs.ignite.domain.itus.trade.ItusTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.Set;
import java.util.concurrent.*;

import static org.mockito.Matchers.any;

/**
 * Created by upadkti on 15/11/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class TotvTradeUpdateServiceTest {

  @InjectMocks
  private TotvTradeUpdateService totvTradeUpdateService = new TotvTradeUpdateService();
  @Mock
  private ItusInstrumentInput itusInstrumentInput;
  @Mock
  private TotvInstrumentData totvInstrumentData;
  @Mock
  private ItusInstrumentService itusInstrumentService;
  @Mock
  private ItusTradeRetrievalService itusTradeRetrievalService;
  @Mock
  private ItusTradeProcessingService itusTradeProcessingService;
  @Mock
  private TotvTrade totvTrade;
  @Mock
  private TotvTradeStatus itusTradeStatus;
  @Mock
  private ExecutorService executorService;

  @Before
  public void setup(){
    MockitoAnnotations.initMocks(this);
    try {
      Field executorService = totvTradeUpdateService.getClass().getDeclaredField("executorService");
      executorService.setAccessible(true);
      executorService.set(totvTradeUpdateService, Executors.newCachedThreadPool());
    } catch (Exception e) { }
  }

  @Test
  public void testUpdateTrades() throws ItusException {
    Set<TotvInstrumentData> dataSet = Sets.newHashSet();
    dataSet.add(totvInstrumentData);
    TotvInstrumentInput instrumentInput = new TotvInstrumentInput(dataSet, LocalDate.now());
    Mockito.when(itusInstrumentService.getInstrumentData(itusInstrumentInput)).thenReturn(dataSet);

    Set<TotvTrade> tradeSet = Sets.newHashSet(totvTrade);
    Mockito.when(itusTradeRetrievalService.retrieveTrades(instrumentInput.getIsinDataSet(),instrumentInput.getDate())).thenReturn(tradeSet);
    Mockito.when(itusTradeProcessingService.processTrades(tradeSet)).thenReturn(Sets.newHashSet(itusTradeStatus));
    Mockito.when(executorService.submit(any(Callable.class))).thenReturn(CompletableFuture.completedFuture(Sets.newHashSet(itusTradeStatus)));
    Set<TotvTradeStatus> statusSet = totvTradeUpdateService.updateForInstrumentInput(itusInstrumentInput);
    Assert.assertTrue(statusSet != null && statusSet.size() == 1);
    Assert.assertTrue(statusSet.contains(itusTradeStatus));
  }

  @Test
  public void testUpdateTrades_GetInstrumentDataThrowsException() throws ItusException {
    Set<TotvInstrumentData> dataSet = Sets.newHashSet();
    dataSet.add(totvInstrumentData);
    Mockito.when(itusInstrumentService.getInstrumentData(itusInstrumentInput)).thenThrow(new ItusException());
    Set<TotvTradeStatus> statusSet = totvTradeUpdateService.updateForInstrumentInput(itusInstrumentInput);
    Assert.assertTrue(statusSet != null && statusSet.size() == 0);
  }

  @Test
  public void testUpdateTrades_GetTradeFromODCThrowsException() throws ItusException {
    Set<TotvInstrumentData> dataSet = Sets.newHashSet();
    dataSet.add(totvInstrumentData);
    TotvInstrumentInput instrumentInput = new TotvInstrumentInput(dataSet, LocalDate.now());
    Mockito.when(itusInstrumentService.getInstrumentData(itusInstrumentInput)).thenReturn(dataSet);
    Set<TotvTrade> tradeSet = Sets.newHashSet(totvTrade);
    Mockito.when(itusTradeRetrievalService.retrieveTrades(instrumentInput.getIsinDataSet(),instrumentInput.getDate())).thenThrow(new ItusException());

    Set<TotvTradeStatus> statusSet = totvTradeUpdateService.updateForInstrumentInput(itusInstrumentInput);
    Assert.assertTrue(statusSet != null && statusSet.size() == 0);
  }

  @Test
  public void testUpdateTrades_ThrowsException() throws ItusException {
    Set<TotvInstrumentData> dataSet = Sets.newHashSet();
    dataSet.add(totvInstrumentData);
    TotvInstrumentInput instrumentInput = new TotvInstrumentInput(dataSet, LocalDate.now());
    Mockito.when(itusInstrumentService.getInstrumentData(itusInstrumentInput)).thenReturn(dataSet);
    Set<TotvTrade> tradeSet = Sets.newHashSet(totvTrade);
    Mockito.when(itusTradeRetrievalService.retrieveTrades(instrumentInput.getIsinDataSet(),instrumentInput.getDate())).thenReturn(tradeSet);
    Mockito.when(itusTradeProcessingService.processTrades(tradeSet)).thenThrow(new ItusException());
    Mockito.when(executorService.submit(any(Callable.class))).thenReturn(CompletableFuture.completedFuture(Sets.newHashSet()));
    Set<TotvTradeStatus> statusSet = totvTradeUpdateService.updateForInstrumentInput(itusInstrumentInput);
    Assert.assertTrue(statusSet != null && statusSet.size() == 0);
  }
}
