package org.sk.tutorial.jfamily.devopsutility.model;

/**
 * Created by kshekar on 03/04/2018.
 */
public class MemoryDetail {
    private long heapUsedMemoryPercentage;
    private long initialHeap;
    private long maximumHeap;
    private long nonHeapUsedMemoryPercentage;
    private long initialNonHeap;
    private long maximumNonHeap;



    public long getInitialHeap() {
        return initialHeap;
    }

    public void setInitialHeap(long initialHeap) {
        this.initialHeap = initialHeap;
    }

    public long getMaximumHeap() {
        return maximumHeap;
    }

    public void setMaximumHeap(long maximumHeap) {
        this.maximumHeap = maximumHeap;
    }

    public long getHeapUsedMemoryPercentage() {
        return heapUsedMemoryPercentage;
    }

    public void setHeapUsedMemoryPercentage(long heapUsedMemoryPercentage) {
        this.heapUsedMemoryPercentage = heapUsedMemoryPercentage;
    }

    public long getNonHeapUsedMemoryPercentage() {
        return nonHeapUsedMemoryPercentage;
    }

    public void setNonHeapUsedMemoryPercentage(long nonHeapUsedMemoryPercentage) {
        this.nonHeapUsedMemoryPercentage = nonHeapUsedMemoryPercentage;
    }

    public long getInitialNonHeap() {
        return initialNonHeap;
    }

    public void setInitialNonHeap(long initialNonHeap) {
        this.initialNonHeap = initialNonHeap;
    }

    public long getMaximumNonHeap() {
        return maximumNonHeap;
    }

    public void setMaximumNonHeap(long maximumNonHeap) {
        this.maximumNonHeap = maximumNonHeap;
    }
}
