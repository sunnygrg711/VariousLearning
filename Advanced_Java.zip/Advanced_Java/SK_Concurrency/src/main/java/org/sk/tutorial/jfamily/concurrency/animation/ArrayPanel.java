package org.sk.tutorial.jfamily.concurrency.animation;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;

/**
 *  This panel draws an array and marks two elements in the array.
 * Created by kshekar on 22/03/2018.
 */
public class ArrayPanel extends JPanel {

    private Double marked1;
    private Double marked2;
    private Double[] values;

    /**
     * Sets values to be painted
     * @param values the array of values to display
     * @param marked1 the first marked element
     * @param marked2 the second marked element
     */
    public void setValues(Double[] values, Double marked1, Double marked2)
    {
        this.values = values;
        this.marked1 = marked1;
        this.marked2 = marked2;
        repaint();
    }

    /**
     * check paintComponent of Supper class
     * @param g
     */
    public void paintComponent(Graphics g)
    {
        if (values == null) return;
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        int width = getWidth() / values.length;
        for (int i = 0; i < values.length; i++)
        {
            double height = values[i] * getHeight();

            Rectangle2D bar = new Rectangle2D.Double(width * i, 10, width, height);
            g2.drawString(String.valueOf(Math.round(100*values[i])),(int)(bar.getX()+width/2),(int)bar.getY());
            g2.drawString(String.valueOf(Math.round(100*values[i])),(int)(bar.getX()+width/2),(int)(bar.getY()+height));
            if (values[i] == marked1 || values[i] == marked2)
                g2.fill(bar);
            else
                g2.draw(bar);
        }
    }
}
