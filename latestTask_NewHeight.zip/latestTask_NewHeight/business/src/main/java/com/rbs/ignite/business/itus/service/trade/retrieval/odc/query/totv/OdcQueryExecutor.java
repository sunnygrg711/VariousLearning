package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv;


import com.google.common.base.Stopwatch;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusQueryExecutor;
import com.rbs.ignite.api.itus.service.trade.retrieval.query.ItusTradeQueryExecutor;
import com.rbs.ignite.business.itus.configurer.totv.SourceSystemToOdcTradeExecutorMapper;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.OdcQueryExecutorHelper;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.OdcQueryInputData;
import com.rbs.ignite.domain.itus.enums.QueryParamName;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.transaction;

/**
 * Created by puronaa on 03/10/2017.
 */
public class OdcQueryExecutor implements ItusQueryExecutor<Set<Transaction>> {

  private static final Logger logger = LoggerFactory.getLogger(OdcQueryExecutor.class);

  @Autowired
  private SourceSystemToOdcTradeExecutorMapper sourceSystemToOdcExecutorMapper;

  @Override
  public Set<Transaction> executeQuery(ConcurrentMap<QueryParamName, Object> parameterMap) {
    //prepare the inputData for query
    OdcQueryInputData odcQueryInputData = OdcQueryExecutorHelper.convertParameterMapToInputData(parameterMap);
    return getTransactionsForIsinSet(odcQueryInputData,(String)parameterMap.get(QueryParamName.REQUEST_ID));
  }

  private Set<Transaction> getTransactionsForIsinSet(OdcQueryInputData odcQueryInputData,String requestId) {
    Set<Transaction> transactions = new HashSet<>();

    //validate the input parameters
    Set<String> isins = odcQueryInputData.getiSin();
    OdcQueryExecutorHelper.validateInputParam("ISIN", isins);
    Set<ItusTradeSourceSystem> sourceSystems = odcQueryInputData.getSourceSystems();
    OdcQueryExecutorHelper.validateInputParam("SourceSystem",sourceSystems);

    // prepare Odc query and executeQuery to get trades from ODC
    Stopwatch stopwatch = Stopwatch.createStarted();
    sourceSystems.forEach((sourceSystem)->{
      logger.info(requestId+":"+"Querying ODC to get trades for {}: ", sourceSystem.getName());
      Set<Transaction> transactionForSystem = null;

      long startTime = System.currentTimeMillis();
      try {
        ItusTradeQueryExecutor<Transaction> queryExecutor = sourceSystemToOdcExecutorMapper.getExecutor(sourceSystem);
        transactionForSystem = queryExecutor.executeQuery(isins,odcQueryInputData.getBusinessDate(),requestId);


        if (logger.isDebugEnabled()) {
          List<String> transactionIds = new ArrayList<>();
          transactionForSystem.forEach((transaction)->{
            transactionIds.add(transaction().getId().getSourceSystemTransactionId());
          });
          logger.debug(requestId+":"+"Trades for {}: {}: ",sourceSystem,transactionIds);
        }
      } catch(RuntimeException ex) {
        logger.error(requestId+":"+"Error occurred while querying trades for {}, skipping...", sourceSystem, ex);
      }

      logger.info(requestId+":"+"ODC query completed for {},found {} trades in {} ms",
        sourceSystem.getName(),(transactionForSystem==null?"0":transactionForSystem.size()),(System.currentTimeMillis()-startTime));
      if(transactionForSystem != null) {
        transactions.addAll(transactionForSystem);
      }
    });

    stopwatch.stop();
    logger.info(requestId+":"+"ODC query completed, found {} trades in {} ms", transactions.size(), stopwatch.elapsed(TimeUnit.MILLISECONDS));
    return transactions;
  }
}