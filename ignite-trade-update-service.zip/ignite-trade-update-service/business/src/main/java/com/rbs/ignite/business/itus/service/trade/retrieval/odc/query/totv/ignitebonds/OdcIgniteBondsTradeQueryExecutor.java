package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.ignitebonds;

import com.rbs.ignite.business.itus.service.trade.retrieval.odc.helper.OdcQueryExecutorHelper;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.AbstractOdcTradeQueryExecutor;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.ODC;
import com.rbs.odc.access.domain.AlternateInstrumentId;
import com.rbs.odc.access.domain.InstrumentId;
import com.rbs.odc.access.domain.RegimeImpactType;
import com.rbs.odc.access.domain.SecurityInstrumentIdentifierClassificationScheme;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.TransactionState;
import com.rbs.odc.dynamicquery.lang.FilterLanguage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import static com.rbs.odc.access.domain.SecurityInstrumentIdentifierClassificationScheme.ISIN;
import static com.rbs.odc.access.domain.SecurityInstrumentIdentifierClassificationScheme.Rdx_Series_Id;
import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.collection;
import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.instrument;
import static com.rbs.odc.dynamicquery.lang.BaseQueryObjects.transaction;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.and;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.or;
import static com.rbs.odc.dynamicquery.lang.FilterLanguage.valueOf;

/**
 * Created by upadkti on 08/12/2017.
 */
public class OdcIgniteBondsTradeQueryExecutor extends AbstractOdcTradeQueryExecutor {
  private static final Logger logger = LoggerFactory.getLogger(OdcIgniteBondsTradeQueryExecutor.class);
  private static final ItusTradeSourceSystem SOURCE_SYSTEM = ItusTradeSourceSystem.IGNITE;
  private @Value("${totv.odc.ignite.system.instance.ids}") String systemInstanceIds;
  private @Value("${totv.odc.ignite.exclude.trade.status}") String tradeStatusStr;

  @Override
  public FilterLanguage createQuery(Set<String> isinSet) {
    Set<SystemInstanceId> systemInstanceIdSet = getSystemInstanceIdsFromString(systemInstanceIds, SOURCE_SYSTEM);
    Set<TransactionState> tradeStatuses = getTransactionStatesFromString(tradeStatusStr, SOURCE_SYSTEM);

    // As Ignite trades may not be mapped with ISIN, need to fetch then based on rdxSeriesId, Firstly fetch all rdxSeriesId for given isins
    Set<String> rdxSeriesIds = getRdxSeriesIdForGivenIsins(isinSet);

    // Create filter inputs for ODC query criteria
    Set<InstrumentId> isinCriteria = OdcQueryExecutorHelper.getQueryCriteriaForIgniteUnionQuery(ISIN,isinSet);
    Set<InstrumentId> rdxSeriesIdCriteria = OdcQueryExecutorHelper.getQueryCriteriaForIgniteUnionQuery(Rdx_Series_Id,rdxSeriesIds);

    FilterLanguage whereClause  = and
      (
        valueOf(transaction().getId().getSourceSystemId()).in(systemInstanceIdSet),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType())
          .notEqualTo(com.rbs.odc.access.domain.RegimeImpactType.Post_Trade_Transparency),
        valueOf(collection(transaction().getReportableTransactionStates()).getRegimeImpactType()).notEqualTo(RegimeImpactType.Transaction_Reporting),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Transaction Reporting"),
        valueOf(collection(collection(transaction().getRegulatoryRegimeImpact()).getTransactionRegimeImpactTypes()).
          getRegimeImpactType()).notEqualTo("Post Trade Transparency"),
        or(
          valueOf(collection(transaction().getTransactionLegs()).getInstrumentId()).in(isinCriteria),
          valueOf(collection(transaction().getTransactionLegs()).getInstrumentId()).in(rdxSeriesIdCriteria))
      );

    return  whereClause;
  }

  private Set<String> getRdxSeriesIdForGivenIsins(Set<String> isinSet) {
    Set<AlternateInstrumentId> alternativeIds = OdcQueryExecutorHelper.getRdxSeriesQueryCriteria(isinSet);
    Iterator<String> rdxSeriesIdIterator = odc.from().instrument().complexWhere(and(
      valueOf(instrument().getId().getInstrumentScheme()).equalTo(Rdx_Series_Id),
      valueOf(collection(instrument().getAlternativeIdentifiers())).in(alternativeIds))).select(instrument().getId().getInstrumentId()).execute();

    Set<String> rdxSeriesId = new HashSet<>();
    while(rdxSeriesIdIterator.hasNext()){
      rdxSeriesId.add(rdxSeriesIdIterator.next());
    }

    logger.info("RDX series IDs {} for ISINs {}", rdxSeriesId, isinSet);
    return rdxSeriesId;
  }
}
