package org.sk.tutorial.jfamily.devopsutility.model;

/**
 * Created by kshekar on 03/04/2018.
 */
public class JVMInfo {
    private int availableProcessors;
    private String cpuName;
    private String osName;
    private String osVersion;
    private ClassesInfo classesInfo;
    private ThreadsInfo threadsInfo;
    private double systemLoadAverage;

    public int getAvailableProcessors() {
        return availableProcessors;
    }

    public String getCpuName() {
        return cpuName;
    }

     public String getOsName() {
        return osName;
    }

    public void setOsName(String osName) {
        this.osName = osName;
    }

    public ClassesInfo getClassesInfo() {
        return classesInfo;
    }

    public void setClassesInfo(ClassesInfo classesInfo) {
        this.classesInfo = classesInfo;
    }

    public ThreadsInfo getThreadsInfo() {
        return threadsInfo;
    }

    public void setThreadsInfo(ThreadsInfo threadsInfo) {
        this.threadsInfo = threadsInfo;
    }

    public void setAvailableProcessors(int availableProcessors) {
        this.availableProcessors = availableProcessors;
    }

    public void setCpuName(String cpuName) {
        this.cpuName = cpuName;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public double getSystemLoadAverage() {
        return systemLoadAverage;
    }

    public void setSystemLoadAverage(double systemLoadAverage) {
        this.systemLoadAverage = systemLoadAverage;
    }
}
