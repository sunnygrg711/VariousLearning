package com.rbs.ignite.domain.itus.trade.totv.ice;

/**
 * Created by upadkti on 04/12/2017.
 */
public class TotvIceRequest {

  private String transactionIdentifier;
  private String isin;
  public String getTransactionIdentifier() {
    return transactionIdentifier;
  }

  public String getIsin() {
    return isin;
  }
  public void setIsin(String isin) {
    this.isin = isin;
  }
  public void setTransactionIdentifier(String transactionIdentifier) {
    this.transactionIdentifier = transactionIdentifier;
  }
  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvIceRequest that = (TotvIceRequest) o;

    if (!transactionIdentifier.equals(that.transactionIdentifier)) return false;
    return isin.equals(that.isin);
  }
  @Override
  public int hashCode() {
    int result = transactionIdentifier.hashCode();
    result = 31 * result + isin.hashCode();
    return result;
  }
  @Override
  public String toString() {
    return "TotvIceRequest{" +
            "transactionIdentifier='" + transactionIdentifier + '\'' +
            ", isin='" + isin + '\'' +
            '}';
  }
}
