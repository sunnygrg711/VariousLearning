package com.rbs.ignite.domain.itus.instrument.totv;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;

import javax.validation.constraints.NotNull;
import java.util.Set;

public class TotvTradeSourceSystemDateIsinInput {

  @NotNull
  private TotvInstrumentDateInput dateInput;
  @NotNull
  private Set<ItusTradeSourceSystem> sourceSystems;
  @NotNull
  private Set<String> isinSet;

  public TotvTradeSourceSystemDateIsinInput(@JsonProperty("dateInput") TotvInstrumentDateInput dateInput, @JsonProperty("sourceSystems") Set<ItusTradeSourceSystem> sourceSystems, @JsonProperty("isinSet") Set<String> isins) {
    this.dateInput = dateInput;
    this.sourceSystems = sourceSystems;
    this.isinSet = isins;
  }
  public TotvInstrumentDateInput getDateInput() {
    return dateInput;
  }
  public Set<ItusTradeSourceSystem> getSourceSystems() {
    return sourceSystems;
  }
  public Set<String> getIsinSet() { return isinSet; }


  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    TotvTradeSourceSystemDateIsinInput that = (TotvTradeSourceSystemDateIsinInput) o;

    if (!dateInput.equals(that.dateInput)) return false;
    if (!sourceSystems.equals(that.sourceSystems)) return false;
    return isinSet.equals(that.isinSet);
  }
  @Override
  public int hashCode() {
    int result = dateInput.hashCode();
    result = 31 * result + sourceSystems.hashCode();
    result = 31 * result + isinSet.hashCode();
    return result;
  }
  @Override
  public String toString() {
    return "TotvTradeSourceSystemDateIsinInput{" +
            "dateInput=" + dateInput +
            ", sourceSystems=" + sourceSystems +
            ", isinSet=" + isinSet +
            '}';
  }
}
