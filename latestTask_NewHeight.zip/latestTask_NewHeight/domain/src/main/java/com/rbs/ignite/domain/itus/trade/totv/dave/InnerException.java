package com.rbs.ignite.domain.itus.trade.totv.dave;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "Message",
        "InnerException"
})
public class InnerException {

  @JsonProperty("Message")
  private String message;
  @JsonProperty("InnerException")
  private InnerException innerException;
  public String getMessage() {
    return message;
  }
  public void setMessage(String message) {
    this.message = message;
  }
  public InnerException getInnerException() {
    return innerException;
  }
  public void setInnerException(InnerException innerException) {
    this.innerException = innerException;
  }
  @Override
  public String toString() {
    return "InnerException{" +
            "message='" + message + '\'' +
            ", innerException=" + innerException +
            '}';
  }
}