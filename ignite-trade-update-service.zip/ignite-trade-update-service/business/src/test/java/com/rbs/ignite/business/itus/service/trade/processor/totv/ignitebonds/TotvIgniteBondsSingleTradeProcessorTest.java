package com.rbs.ignite.business.itus.service.trade.processor.totv.ignitebonds;

import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by upadkti on 22/11/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class TotvIgniteBondsSingleTradeProcessorTest {

  private TotvIgniteBondsSingleTradeProcessor testObj;
  @Mock
  private JmsTemplate jmsTemplate;
  @Mock
  private TotvTrade totvTrade;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    testObj = new TotvIgniteBondsSingleTradeProcessor(jmsTemplate,"","","");
  }

  @Test
  public void processTrades_Success() throws ItusException{
    TotvTradeStatus tradeStatus = testObj.processTrade(totvTrade);
    Assert.assertTrue(tradeStatus != null);
    Assert.assertTrue(tradeStatus.getStatus() == ItusStatus.ACCEPTED);
    Assert.assertEquals(tradeStatus.getServiceResponseCode(), HttpStatus.OK.toString());
  }

  @Test
  public void processTrades_Exception() throws ItusException{
    Mockito.when(totvTrade.getIsin()).thenThrow(Exception.class);
    TotvTradeStatus tradeStatus = testObj.processTrade(totvTrade);
    Assert.assertTrue(tradeStatus != null);
    Assert.assertTrue(tradeStatus.getStatus() == ItusStatus.REJECTED);
    Assert.assertEquals(tradeStatus.getServiceResponseCode(), HttpStatus.SERVICE_UNAVAILABLE.toString());
    Assert.assertEquals(tradeStatus.getTrade(), totvTrade);
  }
}
