package com.rbs.ignite.business.itus.transformer.ice;

import com.rbs.ignite.domain.itus.exception.ItusTransformException;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceRequest;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.eq;

@RunWith(SpringJUnit4ClassRunner.class)
public class TotvTradeToIceReqTransformerTest {

  @InjectMocks
  private TotvTradeToIceRequestTransformer totvTradeToIceRequestTransformer;
  @Mock
  ConversionService conversionService;
  @Mock
  private TotvTrade totvTrade;
  private TotvIceRequest totvIceRequest;
  private TypeDescriptor sourceType;
  private TypeDescriptor targetType;


  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    totvIceRequest = new TotvIceRequest();
    totvIceRequest.setTransactionIdentifier("IceTradeIdentifier");
    sourceType = TypeDescriptor.valueOf(TotvTrade.class);
    targetType = TypeDescriptor.valueOf(TotvIceRequest.class);
  }

  @After
  public void tearDown() {
    totvTradeToIceRequestTransformer = null;
  }

  @Test
  public void testTransform() throws ItusTransformException {

    Mockito.when(conversionService.convert(Mockito.anyObject(), eq(sourceType), eq(targetType))).thenReturn(totvIceRequest);
    TotvIceRequest iceRequest = totvTradeToIceRequestTransformer.transform(totvTrade);
    assertEquals("IceTradeIdentifier", iceRequest.getTransactionIdentifier());
  }

}
