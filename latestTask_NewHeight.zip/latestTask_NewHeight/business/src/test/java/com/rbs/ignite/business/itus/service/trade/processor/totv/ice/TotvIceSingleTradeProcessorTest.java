package com.rbs.ignite.business.itus.service.trade.processor.totv.ice;

import com.rbs.gbm.rates.core.auth.security.TokenProviderService;
import com.rbs.ignite.api.itus.transformer.ItusTransformer;
import com.rbs.ignite.business.itus.totv.TotvStarter;
import com.rbs.ignite.business.itus.util.configurer.totv.TotvTestConfigurer;
import com.rbs.ignite.domain.itus.trade.totv.TotvTrade;
import com.rbs.ignite.domain.itus.trade.totv.TotvTradeStatus;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceRequest;
import com.rbs.ignite.domain.itus.trade.totv.ice.TotvIceResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by kumaunn on 13/11/2017.
 */

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(classes = { TotvStarter.class, TotvTestConfigurer.class })
public class TotvIceSingleTradeProcessorTest {

  @Mock
  private TokenProviderService tokenProviderService;

  @InjectMocks
  private TotvIceSingleTradeProcessor totvIceSingleTradeProcessor = new TotvIceSingleTradeProcessor("url", TotvIceResponse.class, tokenProviderService);

  @Mock
  private ItusTransformer totvTradeToIceRequestTransformer;

  @Mock
  private RestTemplate restTemplate;

  @Mock
  TotvTrade totvTrade;

  private HttpHeaders headers = new HttpHeaders();
  private TotvIceRequest tradeInput = new TotvIceRequest();

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testProcessTradeException() throws Exception {
    tradeInput.setTransactionIdentifier("systemXIdentifier");

    Mockito.when(totvTradeToIceRequestTransformer.transform(totvTrade)).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    when(restTemplate.exchange(Mockito.anyString(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(Class.class))
    )
            .thenThrow(Exception.class);

    status = totvIceSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }

  @Test
  public void testProcessTradeWhenTotvIceRequestNull() throws Exception {

    Mockito.when(totvTradeToIceRequestTransformer.transform(totvTrade)).thenReturn(null);
    TotvTradeStatus status = null;
    status = totvIceSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }

  @Test
  public void testProcessTradeFailure() throws Exception {
    tradeInput.setTransactionIdentifier("");
    Mockito.when(totvTradeToIceRequestTransformer.transform(totvTrade)).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    status = totvIceSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }

  @Test
  public void testProcessTrade() throws Exception {
    TotvIceResponse res = new TotvIceResponse();
    tradeInput.setTransactionIdentifier("Identifier");
    res.setResponseCode("0");
    res.setResponseMessage("Successfully processed");

    ResponseEntity<TotvIceResponse> responseEntity = new ResponseEntity(res, HttpStatus.OK);
    Mockito.when(totvTradeToIceRequestTransformer.transform(Mockito.any())).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    Mockito.when(restTemplate.exchange(Mockito.anyString(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(Class.class)
       )
    )
            .thenReturn(responseEntity);

    status = totvIceSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("0", status.getServiceResponseCode());
    assertEquals("ACCEPTED", status.getStatus().name());

    res.setResponseCode("1");
    res.setExceptionMessage("error while processing request");

    responseEntity = new ResponseEntity(res, HttpStatus.OK);
    Mockito.when(totvTradeToIceRequestTransformer.transform(Mockito.any())).thenReturn(tradeInput);
    status = null;
    Mockito.when(restTemplate.exchange(Mockito.anyString(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(Class.class))
    )
            .thenReturn(responseEntity);

    status = totvIceSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("1", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());
  }

  @Test
  public void testProcessTradeWithNullResponse() throws Exception {
    TotvIceResponse res = new TotvIceResponse();
    tradeInput.setTransactionIdentifier("Identifier");
    res.setResponseCode("0");
    res.setResponseMessage("Successfully processed");

    ResponseEntity<TotvIceResponse> responseEntity = new ResponseEntity(null, HttpStatus.OK);
    Mockito.when(totvTradeToIceRequestTransformer.transform(Mockito.any())).thenReturn(tradeInput);
    TotvTradeStatus status = null;
    Mockito.when(restTemplate.exchange(Mockito.anyString(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(Class.class)
            )
    )
            .thenReturn(responseEntity);

    status = totvIceSingleTradeProcessor.processTrade(totvTrade,"<EMPTY>");
    assertEquals("503", status.getServiceResponseCode());
    assertEquals("REJECTED", status.getStatus().name());

  }

  @After
  public void tearDown() {
    totvIceSingleTradeProcessor = null;
  }
}
