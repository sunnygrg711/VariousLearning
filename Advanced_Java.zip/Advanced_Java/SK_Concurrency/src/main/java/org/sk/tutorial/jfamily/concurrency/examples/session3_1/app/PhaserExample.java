package org.sk.tutorial.jfamily.concurrency.examples.session3_1.app;

import org.sk.tutorial.jfamily.concurrency.examples.session3_1.FloorConstructor;

import java.util.concurrent.*;

/**
 * Created by kshekar on 09/05/2018.
 */
public class PhaserExample {

    public static void main(String[] args) {
        //(0<<32|1<<16|1)
        Phaser phaser = new Phaser(1);
        int floorCount = 4;
        constructFloor(floorCount, phaser);
        phaser.arriveAndAwaitAdvance();
        System.out.println("########################### Completed Phase ::" + phaser.getPhase()+" ###########################");


        floorCount = 2;
        constructFloor(floorCount, phaser);
        phaser.arriveAndAwaitAdvance();
        System.out.println("########################### Completed Phase ::" + phaser.getPhase()+" ###########################");


        floorCount = 1;
        constructFloor(floorCount, phaser);
        phaser.arriveAndAwaitAdvance();
        System.out.println("########################### Completed Phase ::" + phaser.getPhase()+" ###########################");

    }

    private static void constructFloor(int floorCount, Phaser phaser) {
        ThreadFactory threadFactory = r -> new Thread(r);
        for (int i = 0; i < floorCount; i++) {
            threadFactory.newThread(new FloorConstructor(phaser)).start();
        }
    }
}
