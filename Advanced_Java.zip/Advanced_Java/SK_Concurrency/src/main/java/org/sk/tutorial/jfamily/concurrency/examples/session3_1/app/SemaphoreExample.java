package org.sk.tutorial.jfamily.concurrency.examples.session3_1.app;

import org.sk.tutorial.jfamily.concurrency.examples.session3_1.PersonThread;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Semaphore;

public class SemaphoreExample {

    public static void main(String[] args) {
        Semaphore atmRoom=new Semaphore(3);
        List<PersonThread> personThreadList= Arrays.asList(new PersonThread("Tom",atmRoom),
        new PersonThread("Stephen",atmRoom),
        new PersonThread("James",atmRoom),
        new PersonThread("Jack",atmRoom),
        new PersonThread("Jill",atmRoom),
        new PersonThread("Gaurav",atmRoom),
        new PersonThread("Shaurav",atmRoom));
        personThreadList.forEach(personThread -> personThread.start());

    }
}
