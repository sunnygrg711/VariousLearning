package com.rbs.ignite.domain.itus.trade;


import com.rbs.ignite.domain.itus.trade.enums.ItusStatus;

/**
 * Created by puronaa on 26/09/2017.
 */
public interface ItusTradeStatus {
    ItusTrade getTrade();
    ItusStatus getStatus();
    String getServiceResponseCode();
    String getServiceResponseMessage();
    String getServiceExceptionMessage();
}
