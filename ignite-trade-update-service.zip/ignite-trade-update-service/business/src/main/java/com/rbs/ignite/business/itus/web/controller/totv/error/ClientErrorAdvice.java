package com.rbs.ignite.business.itus.web.controller.totv.error;

import com.rbs.ignite.business.itus.web.controller.totv.ItusClientController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice(assignableTypes = { ItusClientController.class })
public class ClientErrorAdvice {
  private static final Logger LOGGER = LoggerFactory.getLogger(ClientErrorAdvice.class);

  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  @ExceptionHandler(value = Exception.class)
  @ResponseBody
  public ErrorMessage restErrorHandler(HttpServletRequest req, Exception e) {
    LOGGER.error(String.format("Request: %s from user: %s failed!", req.getRequestURL(), getCurrentUser()), e);
    return new ErrorMessage(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getLocalizedMessage());
  }

  private String getCurrentUser() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    return authentication != null ? authentication.getName() : "UNKNOWN";
  }
}