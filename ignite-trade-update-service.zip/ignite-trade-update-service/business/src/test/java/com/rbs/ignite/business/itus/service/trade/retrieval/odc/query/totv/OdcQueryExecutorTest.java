package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv;

import com.rbs.ignite.business.itus.configurer.totv.SourceSystemToOdcTradeExecutorMapper;
import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.dave.OdcDaveTradeQueryExecutor;
import com.rbs.ignite.domain.itus.enums.QueryParamName;
import com.rbs.ignite.domain.itus.exception.ItusException;
import com.rbs.ignite.domain.itus.trade.enums.ItusTradeSourceSystem;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionState;
import com.rbs.odc.access.query.Query;
import com.rbs.odc.dynamicquery.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.LocalDate;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Created by upadkti on 20/11/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class OdcQueryExecutorTest {

  @InjectMocks
  private OdcQueryExecutor testObj = new OdcQueryExecutor();
  @Mock
  private From from;
  @Mock
  private Query query;
  @Mock
  private TransactionWhere transactionWhere;
  @Mock
  private TransactionAnd andType;
  @Mock
  private Transaction transaction;
  @Mock
  private WhereWithUnderlyingRaw whereWithUnderlyingRaw;
  @Mock
  private SingularGroupBy singularGroupBy;
  @Mock
  private SourceSystemToOdcTradeExecutorMapper sourceSystemToOdcExecutorMapper;
  @Mock
  private OdcDaveTradeQueryExecutor odcDaveTradeQueryExecutor;
  @Rule
  public ExpectedException thrown = ExpectedException.none();

  @Before
  public void setup() throws Exception {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testExecuteQuery() throws ItusException {
    ConcurrentMap<QueryParamName, Object> paramaterMap = new ConcurrentHashMap<>();
    Set<String> input = Sets.newSet("ISIN123456");
    paramaterMap.put(QueryParamName.ISINSET, input);
    paramaterMap.put(QueryParamName.SOURCE_SYSTEM, Sets.newSet(ItusTradeSourceSystem.DAVE));
    paramaterMap.put(QueryParamName.ELIGIBLE, false);
    paramaterMap.put(QueryParamName.TRANSACTION_STATE, TransactionState.Cancelled);
    paramaterMap.put(QueryParamName.BUSINESS_DATE, LocalDate.of(2017,12,07));
    Mockito.when(sourceSystemToOdcExecutorMapper.getExecutor(ItusTradeSourceSystem.DAVE)).thenReturn(odcDaveTradeQueryExecutor);
    Mockito.when(odcDaveTradeQueryExecutor.executeQuery(input, LocalDate.of(2017,12,07))).thenReturn(Sets.newSet(transaction));

    Set<Transaction> transactions = testObj.executeQuery(paramaterMap);

    Assert.assertTrue(transactions.size()==1);
    Assert.assertTrue(transactions.contains(transaction));
  }

  @Test
  public void testExecuteQueryForIgnite() throws ItusException {
    ConcurrentMap<QueryParamName, Object> paramaterMap = new ConcurrentHashMap<>();
    Set<String> input = Sets.newSet("ISIN123456");
    paramaterMap.put(QueryParamName.ISINSET, input);
    paramaterMap.put(QueryParamName.SOURCE_SYSTEM, Sets.newSet(ItusTradeSourceSystem.IGNITE));
    paramaterMap.put(QueryParamName.ELIGIBLE, false);
    paramaterMap.put(QueryParamName.TRANSACTION_STATE, TransactionState.Cancelled);
    paramaterMap.put(QueryParamName.BUSINESS_DATE, LocalDate.of(2017,12,07));
    Mockito.when(sourceSystemToOdcExecutorMapper.getExecutor(ItusTradeSourceSystem.IGNITE)).thenReturn(odcDaveTradeQueryExecutor);
    Mockito.when(odcDaveTradeQueryExecutor.executeQuery(input,LocalDate.of(2017,12,07))).thenReturn(Sets.newSet(transaction));
    Set<Transaction> transactions = testObj.executeQuery(paramaterMap);

    Assert.assertTrue(transactions.size()==1);
    Assert.assertTrue(transactions.contains(transaction));
  }

  @Test
  public void testExecuteQueryForIgniteWithTransactionStateCancelled() throws ItusException {
    ConcurrentMap<QueryParamName, Object> paramaterMap = new ConcurrentHashMap<>();
    Set<String> input = Sets.newSet("ISIN123456");
    paramaterMap.put(QueryParamName.ISINSET, input);
    paramaterMap.put(QueryParamName.SOURCE_SYSTEM, Sets.newSet(ItusTradeSourceSystem.IGNITE));
    paramaterMap.put(QueryParamName.ELIGIBLE, false);
    paramaterMap.put(QueryParamName.TRANSACTION_STATE, TransactionState.Cancelled);

    Mockito.when(sourceSystemToOdcExecutorMapper.getExecutor(ItusTradeSourceSystem.IGNITE)).thenReturn(odcDaveTradeQueryExecutor);
    Mockito.when(odcDaveTradeQueryExecutor.executeQuery(input,LocalDate.of(2017,12,07))).thenReturn(Sets.newSet(transaction));
    Mockito.when(transaction.getTransactionState()).thenReturn(TransactionState.Cancelled);
    Set<Transaction> transactions = testObj.executeQuery(paramaterMap);

    Assert.assertTrue(transactions.size()==0);
    Assert.assertTrue(!transactions.contains(transaction));
  }

  @Test
  public void testExecuteQueryWithException() throws ItusException {
    ConcurrentMap<QueryParamName, Object> paramaterMap = new ConcurrentHashMap<>();
    Set<String> input = Sets.newSet("ISIN123456");
    paramaterMap.put(QueryParamName.ISINSET, input);
    paramaterMap.put(QueryParamName.SOURCE_SYSTEM, Sets.newSet(ItusTradeSourceSystem.IGNITE));
    paramaterMap.put(QueryParamName.ELIGIBLE, false);
    paramaterMap.put(QueryParamName.TRANSACTION_STATE, TransactionState.Cancelled);

    Mockito.when(sourceSystemToOdcExecutorMapper.getExecutor(ItusTradeSourceSystem.DAVE)).thenReturn(odcDaveTradeQueryExecutor);
    Mockito.when(odcDaveTradeQueryExecutor.executeQuery(input,LocalDate.of(2017,12,07))).thenReturn(Sets.newSet(transaction));

    Set<Transaction> transactions = testObj.executeQuery(paramaterMap);

    Assert.assertTrue(transactions.size()==0);
    Assert.assertTrue(!transactions.contains(transaction));
  }
}