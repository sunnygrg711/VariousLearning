package org.sk.tutorial.jfamily.concurrency.examples.session3_1;

import java.util.Arrays;
import java.util.concurrent.LinkedBlockingQueue;

public class LinkedBlockingQueueTest {
    public static void main(String[] args) {
        LinkedBlockingQueue linkedBlockingQueue=new LinkedBlockingQueue(Arrays.asList("A","B",null));
        System.out.println(linkedBlockingQueue);
    }
}
