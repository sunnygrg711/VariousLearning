package org.sk.tutorial.jfamily.concurrency.examples.session2_2;

public class MonitorObject{
}