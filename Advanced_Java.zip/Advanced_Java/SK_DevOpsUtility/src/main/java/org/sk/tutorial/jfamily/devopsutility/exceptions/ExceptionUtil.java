package org.sk.tutorial.jfamily.devopsutility.exceptions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

/**
 * Handles common methods for exceptions.
 */
public class ExceptionUtil {
    protected static final Logger LOGGER = LoggerFactory.getLogger(ExceptionUtil.class);

    /**
     * It wraps exception into run time exception.
     *
     * @param template
     * @return
     */
    public static void uncheckedNoReturn(final ExceptionNoResultAction template,
                                         Consumer<Exception> exceptionConsumer) {
        try {
            template.doAction();
        } catch (Exception ex) {
            exceptionConsumer.accept(ex);
        }
    }


    public static void executeToThrowOnlyCE(final ExceptionNoResultAction template,
                                            Consumer<Exception> exceptionConsumer) {
        try {
            template.doAction();
        } catch (Exception ex) {
            LOGGER.error("Oops - Unexpected exception occurred {} ", ex);
            exceptionConsumer.accept(ex);
        }
    }

    /**
     * It wraps exception into run time exception.
     *
     * @param template
     * @return
     */
    public static void uncheckedNoReturn(final ExceptionNoResultAction template) {
        try {
            template.doAction();
        } catch (Exception ex) {
            logAndThrowCollateralException(ex);
        }
    }

    /**
     * It wraps exception into run time exception.
     *
     * @param template
     * @param <T>
     * @return
     */
    public static <T> T unchecked(final ExceptionAction<T> template) {
        T results = null;
        try {
            results = template.doAction();
        } catch (Exception ex) {
            logAndThrowCollateralException(ex);
        }
        return results;
    }

    /**
     * It wraps exception into run time exception.
     *
     * @param template
     * @param <T>
     * @return
     */
    public static <T> T unchecked(final ExceptionAction<T> template, Consumer<Exception> exceptionConsumer) {
        T results = null;
        try {
            results = template.doAction();
        } catch (Exception ex) {
            exceptionConsumer.accept(ex);
        }
        return results;
    }

    /**
     * It executes an exception bearing action.
     *
     * @param template
     * @param <T>
     * @return
     */
    public static <T> T execute(final ExceptionAction<T> template) {
        return execute(template, null);
    }

    /**
     * It executes an exception bearing action.
     *
     * @param template
     * @param nullObj
     * @param <T>
     * @return
     */
    public static <T> T execute(final ExceptionAction<T> template, Object nullObj) {
        T results = null;
        try {
            results = template.doAction();
        } catch (Exception ex) {
            // don't throw any exception back to client, client won't be able to
            // recover from it. Client will get null/no records.
            LOGGER.error("Oops - Operation failed", ex);
            LOGGER.error("Oops - Error Log {} ", template.toString());
        }
        return results == null ? (T) nullObj : results;
    }

    /**
     * It executes an exception bearing action.
     *
     * @param template
     * @return
     */
    public static void execute(final ExceptionNoResultAction template) {

        try {
            template.doAction();
        } catch (Exception ex) {
            LOGGER.error("Oops - Error Log {} ", template.toString());
        }

    }

    public static void logAndThrowCollateralException(Throwable cause) {
        LOGGER.error("Oops - Unexpected exception occured {} ", cause);
    }
}
