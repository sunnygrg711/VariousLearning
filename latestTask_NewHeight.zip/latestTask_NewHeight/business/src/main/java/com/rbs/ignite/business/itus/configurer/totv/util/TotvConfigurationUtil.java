package com.rbs.ignite.business.itus.configurer.totv.util;

import com.rbs.ignite.domain.itus.odc.OdcConnectionInput;
import com.rbs.odc.access.ODC;
import com.rbs.odc.access.start.ODCSimpleStart;
import com.rbs.odc.core.util.ODCProperties;
import com.rbs.odc.core.util.PropertiesConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.rbs.odc.core.util.ODCProperties.CYCLE_RETRIES;

public class TotvConfigurationUtil {

  private static final Logger logger = LoggerFactory.getLogger(TotvConfigurationUtil.class);

  public static ODC getOdcObject(OdcConnectionInput odcConnectionInput){

    logger.debug("Instantiating odc");
    logger.debug("odcEnvironment:" + odcConnectionInput.getOdcEnvironment());
    logger.debug("odcUser:" + odcConnectionInput.getOdcUser());
    System.setProperty(ODCProperties.ENVIRONMENT, odcConnectionInput.getOdcEnvironment());
    System.setProperty("odc.blender.enabled", odcConnectionInput.getOdcBlenderEnabled());
    // ODC UAT5 specific properties
    System.setProperty("odc.osl.http.host", odcConnectionInput.getOdcOslHost());
    System.setProperty("odc.osl.http.port", odcConnectionInput.getOdcOslPort());
    PropertiesConfiguration.INSTANCE.loadSystemPropertiesForEnvironmentAndProcess(odcConnectionInput.getOdcEnvironment(), PropertiesConfiguration.PROCESS_CLIENT);
/*            Note that the retry count is for each possible server connection – it tries each possible connection up to the retry limit
            and only once all have failed will it throw. This means that for ODC configuration with 46 servers (the current prod
            configuration) a retry count of 2 will actually try each of 46 servers twice, so 92 connection attempts will be logged
             before the exception is thrown.*/
    System.setProperty(CYCLE_RETRIES, String.valueOf(odcConnectionInput.getOdcRetryCount()));
    ODC odc = ODCSimpleStart.getODCFactory().getAccessLayerInstance(odcConnectionInput.getOdcUser(), odcConnectionInput.getOdcPassword());
    logger.debug("Instantiated odc");
    return odc;
  }
}
