package org.sk.tutorial.jfamily.concurrency.examples.session1_3.app;

import org.sk.tutorial.jfamily.concurrency.examples.session1_3.ThreadIdGenerator;

import java.util.concurrent.ThreadFactory;

/**
 * Created by kshekar on 07/05/2018.
 */
public class ThreadIdGeneratorMain {

    public static void main(String[] args) {
        for(int i=0;i<10;i++){
            ThreadFactory threadFactory=r -> new Thread(r);
            threadFactory.newThread(() -> System.out.println(Thread.currentThread()+"::"+ThreadIdGenerator.get()))
.start();
        }
    }
}
