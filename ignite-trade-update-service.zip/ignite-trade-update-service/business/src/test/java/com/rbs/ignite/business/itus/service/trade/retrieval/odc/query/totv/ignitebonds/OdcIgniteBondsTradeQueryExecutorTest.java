package com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.ignitebonds;

import com.rbs.ignite.business.itus.service.trade.retrieval.odc.query.totv.dave.OdcDaveTradeQueryExecutor;
import com.rbs.ignite.business.itus.totv.TotvStarter;
import com.rbs.ignite.business.itus.util.ReflectionUtil;
import com.rbs.odc.access.ODC;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.query.Query;
import com.rbs.odc.core.domain.BusinessDateImpl;
import com.rbs.odc.dynamicquery.From;
import com.rbs.odc.dynamicquery.SingularGroupBy;
import com.rbs.odc.dynamicquery.TransactionAnd;
import com.rbs.odc.dynamicquery.TransactionWhere;
import com.rbs.odc.dynamicquery.WhereWithUnderlyingRaw;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.collections.Sets;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.time.LocalDate;
import java.util.Set;

/**
 * Created by upadkti on 11/12/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TotvStarter.class)
public class OdcIgniteBondsTradeQueryExecutorTest {
  @Mock
  private ODC odc;
  @Mock
  private From from;
  @Mock
  private Query query;
  @Mock
  private TransactionWhere transactionWhere;
  @Mock
  private Transaction transaction;
  @Mock
  private TransactionAnd andType;
  @Mock
  private WhereWithUnderlyingRaw whereWithUnderlyingRaw;
  @Mock
  private SingularGroupBy singularGroupBy;
  @Autowired
  @InjectMocks
  private OdcIgniteBondsTradeQueryExecutor testObj;

  @Before
  public void setup() throws Exception {
    MockitoAnnotations.initMocks(this);
    ReflectionUtil.setPrivateField(OdcDaveTradeQueryExecutor.class,testObj,"systemInstanceIds","GDS GBLO");
    ReflectionUtil.setPrivateField(OdcDaveTradeQueryExecutor.class,testObj,"tradeStatusStr","Validated");
  }

  @Ignore
  @Test
  public void executeQuery() {
    Mockito.when(odc.from()).thenReturn(from);
    Mockito.when(from.transaction()).thenReturn(transactionWhere);
    Mockito.when(from.instrument()).thenReturn(whereWithUnderlyingRaw);
    Mockito.when(whereWithUnderlyingRaw.complexWhere(Mockito.any())).thenReturn(andType);
    Mockito.when(transactionWhere.complexWhere(Mockito.any())).thenReturn(andType);
    Mockito.when(andType.arrivedBetween(Mockito.any(),Mockito.any())).thenReturn(andType);
    Mockito.when(andType.driveFromLatest()).thenReturn(query);
    Mockito.when(andType.select(Mockito.anyString())).thenReturn(singularGroupBy);
    Mockito.when(singularGroupBy.execute()).thenReturn(Sets.newSet(transaction).iterator());
    Mockito.when(query.execute()).thenReturn(Sets.newSet(transaction).iterator());

    Set<String> input = Sets.newSet("ISIN1234546");
    Set<Transaction> transactions  = testObj.executeQuery(input, LocalDate.of(2017,12,07));

    Assert.assertTrue(transactions != null);
    Assert.assertTrue(transactions.contains(transaction));
  }
}
