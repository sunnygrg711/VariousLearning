package org.sk.tutorial.jfamily.adminui.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.lang.management.ManagementFactory;


/**
 * Created by kshekar on 02/04/2018.
 */
@Component
public class Application {
    @Value("${application.name}")
    private String applicationName;
    private String processId;
    @Value("${application.description}")
    private String description;
    private String hostName;
    @Value("${server.port}")
    private Integer port;

    private State state=State.RUNNING;

    @Autowired
    public  Application(){
        String[] applicationNames= ManagementFactory.getRuntimeMXBean().getName().split("@");
        setProcessId(applicationNames[0]);
         setHostName(applicationNames[1]);
    }
    public String getApplicationName() {
        return applicationName;
    }

    public String getProcessId() {
        return processId;
    }

    public String getDescription() {
        return description;
    }

    public String getHostName() {
        return hostName;
    }

    public Integer getPort() {
        return port;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }


    @Override
    public String toString() {
        return "Application{" +
                "applicationName='" + applicationName + '\'' +
                ", processId='" + processId + '\'' +
                ", description='" + description + '\'' +
                ", hostName='" + hostName + '\'' +
                ", port='" + port + '\'' +
                ", state=" + state +
                '}';
    }
}
