package org.sk.tutorial.jfamily.concurrency.examples.session3_1.app;

import java.lang.management.ManagementFactory;
import java.util.concurrent.TimeUnit;

public class DeadLockCodeExample {

    public static void main(String[] args) {
      final   Object left=new Object();
        final Object right=new Object();
        System.out.println(ManagementFactory.getRuntimeMXBean().getName());
        new Thread(()->process(left,right,10)).start();
        new Thread(()->process(right,left,10)).start();
        System.out.println("No Deadlock");
    }
    public static void process(Object first,Object second, int amount)  {
        try {
            synchronized (first){
                TimeUnit.SECONDS.sleep(1);
                synchronized (second){
                    TimeUnit.SECONDS.sleep(2);
                    System.out.println("done!");
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }
}
