package com.rbs.ignite.config.validation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This test class compare the .properties/.cfg keys with in a componenet i.e.
 * keeps ldn.prod and .default as baseline and compare these two with rest of
 * cfg/properties files respectively.
 * 
 * Also compare the values same way, if value for a key need not be compared
 * then it has to be part of exlcusion list else it should be same across
 * properties/cfg files.
 * 
 * This is done to minimize/avoid configuration issues while doing deployment or
 * using application.
 */
public class BuildValidationOfPropsTest {
	
	private Logger logger = LoggerFactory.getLogger(getClass());

	private static List<File> envPropsFiles = new ArrayList<File>();
	private static List<File> envCfgFiles = new ArrayList<File>();
	private static List<File> baseLineProp = new ArrayList<File>();
	private static List<File> baseLineCfg = new ArrayList<File>();
	
	private static Set<String> exclusionPropsList  = new HashSet<>();	
	private static Set<String> exclusionCfgList  = new HashSet<>();
	
	@BeforeClass
	public static void setup() throws IOException {
		
		 exclusionPropsList.add("server.port");

		// TODO cfg file exclusion list
		// exclusionCfgList.add("");

		File envDataDirectory = new File("./target/classes/config");
		envPropsFiles = Arrays.asList(envDataDirectory
				.listFiles(new FilenameFilter() {

					public boolean accept(File dir, String name) {
						if (name.contains(".properties")
								&& !name.contains(".dev")
								&& !name.contains(".local"))
							return true;
						else {
							return false;
						}
					}
				}));
		Assert.assertNotNull(envPropsFiles);
		Assert.assertTrue("File list should be greater than 0",
				envPropsFiles.size() > 0);

		for (File file : envPropsFiles) {
			if (file.getName().contains("ldn.prod")
					|| file.getName().contains(".default")) {
				baseLineProp.add(file);
			}
		}
		Assert.assertTrue(baseLineProp.size() == 2);

		envCfgFiles = Arrays.asList(envDataDirectory
				.listFiles(new FilenameFilter() {

					public boolean accept(File dir, String name) {
						if (name.contains(".cfg") && !name.contains(".dev")
								&& !name.contains(".local"))
							return true;
						else
							return false;
					}
				}));
		Assert.assertNotNull(envCfgFiles);
		Assert.assertTrue("File list should be greater than 0",
				envCfgFiles.size() > 0);

		for (File file : envCfgFiles) {
			if (file.getName().contains("ldn.prod")
					|| file.getName().contains(".default")) {
				baseLineCfg.add(file);
			}
		}
		Assert.assertTrue(baseLineCfg.size() == 2);
	}

	/**
	 * This test case takes 'ldn.prod'/default file as baseline and compares it with
	 * rest of properties files. If any difference from either side then it
	 * fails.
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	@Test
	public void testProperties() throws FileNotFoundException, IOException {
		logger.info("**********Running .properties files comparison, with baseline as 'ldn.prod and default property files'**********");		
		Properties baseLineProperties = new Properties();
		File defaultProperties = null;
		for (File file : baseLineProp) {
			baseLineProperties.load(new FileInputStream(file));
			if(file.getName().contains(".default")){
				defaultProperties = file;
			}
		}
		for (File file : envPropsFiles) {
			if (file.getName().contains("ldn.prod")
					|| file.getName().contains("default"))
				continue;
			Properties properties = new Properties();
			properties.load(new FileInputStream(file));
			properties.load(new FileInputStream(defaultProperties));
			boolean assertFail = false;
			Set<String> props = new HashSet<>();
			for (Object key : properties.keySet()) {
				if (!baseLineProperties.containsKey(key)) {
					props.add(key.toString());
					assertFail = true;
					if (props.size() == 1) {
						logger.info("File="
										+ "ldn.prod and default property files does not contain below properties.");
						logger.info(key.toString());
					} else if (props.size() > 1) {
						logger.info(key.toString());
					}
				} else if (baseLineProperties.containsKey(key)) {
					String baseLineVal = baseLineProperties.getProperty(key.toString());
					String currentPropertyVal = properties.getProperty(key.toString());
				}
			}

			props = new HashSet<>();
			for (Object key : baseLineProperties.keySet()) {
				if (!properties.containsKey(key)) {
					props.add(key.toString());
					assertFail = true;
					if (props.size() == 1) {
						logger.info("File=" + file.getName()
								+ " does not contain below properties.");
						logger.info(key.toString());
					} else if (props.size() > 1) {
						logger.info(key.toString());
					}
				}
			}
			if (assertFail) {
				Assert.fail();
			}
		}
		
		logger.info("**********Completed .properties files comparison, with baseline as 'ldn.prod and default property files'**********");
	}

	/**
	 * This test case takes 'ldn.prod'/default file as baseline and compares it with
	 * rest of .cfg files. If any difference from either side then it fails.
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	@Test
	public void testCfg() throws FileNotFoundException, IOException {
		logger.info("**********Running .cfg files comparison, with baseline as 'ldn.prod and default property files'**********");
		Properties baseLineCfgs = new Properties();
		File defaultProperties = null;
		for (File file : baseLineCfg) {
			baseLineCfgs.load(new FileInputStream(file));
			if(file.getName().contains(".default")){
				defaultProperties = file;
			}
		}
		for (File file : envCfgFiles) {
			if (file.getName().contains("ldn.prod")
					|| file.getName().contains("default"))
				continue;
			Properties properties = new Properties();
			properties.load(new FileInputStream(file));
			properties.load(new FileInputStream(defaultProperties));
			boolean assertFail = false;
			Set<String> props = new HashSet<>();
			for (Object key : properties.keySet()) {
				if (!baseLineCfgs.containsKey(key)) {
					props.add(key.toString());
					assertFail = true;
					if (props.size() == 1) {
						logger.info("File="
										+ "ldn.prod and default property files does not contain below properties.");
						System.out.println(key);
					} else if (props.size() > 1) {
						logger.info(key.toString());
					}
				}
			}

			props = new HashSet<>();
			for (Object key : baseLineCfgs.keySet()) {
				if (!properties.containsKey(key)) {
					props.add(key.toString());
					assertFail = true;
					if (props.size() == 1) {
						logger.info("File=" + file.getName()
								+ " does not contain below properties.");
						logger.info(key.toString());
					} else if (props.size() > 1) {
						logger.info(key.toString());
					}
				}  else if (baseLineCfgs.containsKey(key)) {
					String baseLineVal = baseLineCfgs.getProperty(key
							.toString());
					String currentPropertyVal = properties.getProperty(key
							.toString());
				}
			}
			if (assertFail) {
				Assert.fail();
			}
		}		
		
		logger.info("**********Completed .cfg files comparison, with baseline as 'ldn.prod and default property files'**********");

	}

}
