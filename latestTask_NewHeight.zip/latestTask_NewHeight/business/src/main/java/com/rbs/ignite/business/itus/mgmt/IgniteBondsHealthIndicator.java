package com.rbs.ignite.business.itus.mgmt;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.jms.Connection;
import javax.jms.JMSException;

@Component
public class IgniteBondsHealthIndicator extends AbstractHealthIndicator {

  @Autowired
  private ApplicationContext context;
  private @Value("${totv.ignitebonds.messaging.server.url}") String messagingServerURL;
  private @Value("${totv.ignitebonds.messaging.username}") String messagingUsername;
  private @Value("${totv.ignitebonds.messaging.password}") String messagingPassword;

  @Override
  protected void doHealthCheck(Health.Builder builder) throws Exception {

    try {
      JmsTemplate jmsTemplate = (JmsTemplate) context.getBean("jmsTemplate", messagingServerURL, messagingUsername, messagingPassword);
      jmsTemplate.getConnectionFactory().createConnection();
      builder.withDetail("Env " ,messagingServerURL).status(Status.UP);
    }catch (JMSException e){
      builder.withDetail(e.getMessage() ,"Ignite").status(Status.DOWN);

    }
  }
}
