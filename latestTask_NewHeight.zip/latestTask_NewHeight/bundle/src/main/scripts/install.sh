#!/bin/bash
configPath=""
envRoot=""
application="${project.parent.artifactId}"
overrideConfig=false

#resolve absolute path
cd $(dirname $0)/..
versionPath=$(pwd)
cd - 1> /dev/null 2>&1
echo "INFO : Code bundle to deploy - ${versionPath}"

usageError() {
	echo "USAGE ERROR" >&2
	echo "usage : $0 -c <config build's path> -e <environment's root path>" >&2
	exit 1
}
while getopts c:e:o opt; do
	case ${opt} in
		c) configPath=$OPTARG
		;;
		e) envRoot=$OPTARG
		;;
		o) overrideConfig=true
		;;
		?) usageError
		;;
	esac
done

[[ ${envRoot} == "" ]] || [[ ${configPath} == "" ]] && usageError

envName=`basename ${envRoot}`
regionRoot=`dirname ${envRoot}`
regionName=`basename ${regionRoot}`
uatEnv=${regionName}.${envName}

if [[ ! -d  ${envRoot} ]]; then 
	echo "ERROR : Environment Root ${envRoot} not a directory"
	exit 1
fi
#resolve absolute path
cd ${envRoot}
envRoot=$(pwd)
cd - 1> /dev/null 2>&1

if [[ ! -d ${configPath} ]]; then
	echo "ERROR : Path to configuration bundle ${configPath} not a directory"
	exit 1
fi
#resolve absolute path
cd ${configPath}
configPath=$(pwd)
echo "INFO : Config bundle to deploy - ${configPath}"
cd - 1> /dev/null 2>&1

installDir=${envRoot}/$(basename ${versionPath})
if [[ -d ${installDir} ]]; then
  if (${overrideConfig}); then
    echo "Updating configs for Installation: ${installDir}"
    existingConfig=`readlink ${installDir}/etc`
    echo "Existing path of config: ${existingConfig}" 
    echo "New path of config: ${configPath}"
    if [[ -e ${installDir}/etc ]]; then
      unlink ${installDir}/etc
      if (( $? != 0 )); then
        echo "ERROR : Unable to unlink ${installDir}/etc, please investigate"
        exit 1
      fi
    fi
    ln -s ${configPath} ${installDir}/etc
    exit 0
  else
    echo "ERROR : Installation already exists - ${installDir}." 
    echo "SUGGESTTION: If your aim is to override the existing config for deployed component, please run the command again with additional -o switch."
    exit 1
  fi
fi

ENV_LOGS="/apps/IRDvar/rsu/${regionName}/${envName}/${project.parent.artifactId}"
if [[ ! -d ${ENV_LOGS} ]]; then
	echo "ERROR : Logging location - ${ENV_LOGS} not a directory"
	exit 1
fi

# application installation
mkdir -p ${installDir}
mkdir -p ${installDir}/bin
mkdir -p ${installDir}/overrides/config
touch ${installDir}/overrides/config/${project.parent.artifactId}.overrides.properties
touch ${installDir}/overrides/config/${project.parent.artifactId}.overrides.cfg

sed "s|\%%ENV_VALUE%%|${uatEnv}|g" ${versionPath}/bin/control.sh > ${installDir}/bin/control.sh
chmod 775 ${installDir}/bin/control.sh

ln -s ${configPath} ${installDir}/etc
ln -s ${versionPath} ${installDir}/opt
ln -s ${ENV_LOGS} ${installDir}/logs
ln -s bin/control.sh ${installDir}/app

chmod 775 ${installDir}/overrides/

echo " "
echo "======================================================================================"
echo "INSTALLATION COMPLETE"
echo " "
echo "Details:" 
echo "- Component installed to dir: ${installDir}"
echo "======================================================================================"
echo " "
exit 0
