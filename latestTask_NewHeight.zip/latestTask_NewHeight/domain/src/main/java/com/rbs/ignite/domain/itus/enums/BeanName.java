package com.rbs.ignite.domain.itus.enums;

public enum BeanName {
  ITUS_TRADE_TASK("itusTradeTask"), ITUS_TRADE_TASK_CALLABLE("itusTradeTaskCallable");

  private String name;

  BeanName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
